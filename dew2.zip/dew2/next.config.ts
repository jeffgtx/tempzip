import type { NextConfig } from "next";
import { loadContent } from "./src/content/load";

// Invalid content fails `next build` and `next dev` before anything else runs.
loadContent();

const nextConfig: NextConfig = {
  agentRules: false,
  // The room is shared on screen, so Next's badge stays off it.
  devIndicators: false,
  // Bundling breaks how PGlite finds its WebAssembly files.
  serverExternalPackages: ["@electric-sql/pglite"],
};

export default nextConfig;
