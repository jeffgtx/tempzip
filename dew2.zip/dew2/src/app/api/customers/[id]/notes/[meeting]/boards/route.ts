import { z } from "zod";
import { currentUser } from "@/auth/current";
import { meetingBoards } from "@/notes/data";

// The boards the meeting touched as the room showed them, for its pack.
export async function GET(_: Request, { params }: RouteContext<"/api/customers/[id]/notes/[meeting]/boards">) {
  const user = await currentUser();
  const { id, meeting } = await params;
  if (!z.uuid().safeParse(id).success || !z.uuid().safeParse(meeting).success) return new Response(null, { status: 400 });
  const boards = await meetingBoards(user.id, id, meeting);
  return boards ? Response.json({ boards }) : new Response(null, { status: 404 });
}
