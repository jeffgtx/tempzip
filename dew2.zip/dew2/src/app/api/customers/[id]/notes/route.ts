import { z } from "zod";
import { currentUser } from "@/auth/current";
import { getCustomer } from "@/customers/data";
import { customerMeetings, meetingNotes } from "@/notes/data";

const query = z.object({
  meeting: z.uuid().optional(),
  // The SE's time zone, which dates the notes.
  tz: z.string().max(100),
});

// The customer's meetings, and the notes of the one asked for, else of the latest, which is the one running if any.
export async function GET(request: Request, { params }: RouteContext<"/api/customers/[id]/notes">) {
  const user = await currentUser();
  const { id } = await params;
  const options = query.safeParse(Object.fromEntries(new URL(request.url).searchParams));
  if (!z.uuid().safeParse(id).success || !options.success) return new Response(null, { status: 400 });
  if (!(await getCustomer(user.id, id))) return new Response(null, { status: 404 });
  const meetings = await customerMeetings(user.id, id);
  const shown = options.data.meeting ?? meetings[0]?.id;
  return Response.json({ meetings, notes: shown ? await meetingNotes(user.id, id, shown, options.data.tz) : null });
}
