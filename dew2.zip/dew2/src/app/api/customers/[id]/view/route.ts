import { z } from "zod";
import { currentUser } from "@/auth/current";
import { FOCUS } from "@/board/view";
import { setView } from "@/meetings/data";

const body = z.object({
  boardId: z.uuid().nullable(),
  pane: z.number().int().min(0).max(99),
  focus: z.string().regex(FOCUS).nullable().default(null),
  held: z.boolean(),
});

export async function POST(request: Request, { params }: RouteContext<"/api/customers/[id]/view">) {
  const user = await currentUser();
  const { id } = await params;
  const parsed = body.safeParse(await request.json().catch(() => null));
  if (!z.uuid().safeParse(id).success || !parsed.success) return new Response(null, { status: 400 });
  return new Response(null, { status: (await setView(user.id, id, parsed.data)) ? 204 : 404 });
}
