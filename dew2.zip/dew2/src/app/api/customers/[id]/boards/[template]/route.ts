import { z } from "zod";
import { currentUser } from "@/auth/current";
import { FOCUS, customerBoardView } from "@/board/view";
import { getCustomer } from "@/customers/data";

const query = z.object({
  pane: z.coerce.number().int().min(0).max(99),
  // The entry a zoom board belongs to.
  entry: z.uuid().optional(),
  diagram: z.uuid().optional(),
  // The flow picked on the summary, which the export lights.
  focus: z.string().regex(FOCUS).optional(),
});

// A board as the room would show it, for the preview panel and PNG export.
export async function GET(request: Request, { params }: RouteContext<"/api/customers/[id]/boards/[template]">) {
  const user = await currentUser();
  const { id, template } = await params;
  const options = query.safeParse(Object.fromEntries(new URL(request.url).searchParams));
  if (!z.uuid().safeParse(id).success || !options.success) return new Response(null, { status: 400 });
  const view = (await getCustomer(user.id, id)) && (await customerBoardView(user.id, id, template, options.data, { entryId: options.data.entry, diagramId: options.data.diagram }));
  return view ? Response.json(view) : new Response(null, { status: 404 });
}
