import { messages } from "@electric-sql/pglite";
import { DrizzleQueryError } from "drizzle-orm";
import { after } from "next/server";
import { z } from "zod";
import { currentUser } from "@/auth/current";
import { type CommitResult, commitIn } from "@/board/data";
import { commitSchema } from "@/board/model";
import { getCustomer } from "@/customers/data";
import { db } from "@/db";
import { refreshEndedNotes } from "@/notes/data";

const body = z.object({ commits: z.array(z.object({ id: z.string() }).loose()).min(1).max(50) });

// The database refuses bad data (SQLSTATE classes 22 and 23), such as a NUL in text, on every replay,
// which would hold up every commit queued behind it. Anything else, such as a server error, is
// worth a retry.
const refusal = (error: unknown) =>
  error instanceof DrizzleQueryError && error.cause instanceof messages.DatabaseError && /^2[23]/.test(error.cause.code ?? "")
    ? error.cause.message
    : null;

// Commits arrive in the order they were made, including ones queued while offline. Each lands in a
// transaction of its own, so the room shows it without waiting for the rest of the batch, and one bad
// commit doesn't cost the rest.
export async function POST(request: Request, { params }: RouteContext<"/api/customers/[id]/commits">) {
  const user = await currentUser();
  const { id } = await params;
  if (!z.uuid().safeParse(id).success || !(await getCustomer(user.id, id))) return new Response(null, { status: 404 });
  const parsed = body.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: z.prettifyError(parsed.error) }, { status: 400 });
  const results: CommitResult[] = [];
  const meetingIds = new Set<string>();
  for (const raw of parsed.data.commits) {
    const commit = commitSchema.safeParse(raw);
    if (!commit.success) {
      results.push({ id: raw.id, rejected: z.prettifyError(commit.error) });
      continue;
    }
    const result = await db
      .transaction((tx) => commitIn(tx, user.id, id, commit.data))
      .catch((error: unknown): CommitResult => {
        const rejected = refusal(error);
        if (!rejected) throw error;
        console.error("Commit refused", error);
        return { id: raw.id, rejected };
      });
    results.push(result);
    if (commit.data.meetingId && "seq" in result) meetingIds.add(commit.data.meetingId);
  }
  after(() => refreshEndedNotes(user.id, [...meetingIds]));
  return Response.json({ results });
}
