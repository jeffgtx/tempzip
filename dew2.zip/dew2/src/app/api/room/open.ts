import { meetingForCode } from "@/meetings/data";

export async function openRoom(request: Request) {
  const code = new URL(request.url).searchParams.get("code") ?? "";
  const meeting = await meetingForCode(code);
  if (!meeting) return { error: new Response(null, { status: 404 }) };
  return { meetingId: meeting.id };
}
