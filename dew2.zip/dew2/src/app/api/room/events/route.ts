import { roomSnapshot, roomVersion } from "@/meetings/room";
import { openRoom } from "../open";

// Each open room checks this often, so it is as slow as the 1-second target allows.
const POLL_MS = 500;
// A named event, not a comment, so the room can tell a live stream from a stalled one.
const PING_MS = 15_000;

// Sends a snapshot whenever the meeting's version changes. The event id is the
// version, so a reconnecting room gets nothing it already has.
export async function GET(request: Request) {
  const room = await openRoom(request);
  if (room.error) return room.error;
  const encoder = new TextEncoder();
  let sent = request.headers.get("last-event-id");

  const stream = new ReadableStream({
    async start(controller) {
      const write = (text: string) => controller.enqueue(encoder.encode(text));
      let pinged = Date.now();
      // A dropped stream should come back at once, not after the browser's default wait.
      write("retry: 250\n\n");
      try {
        while (!request.signal.aborted) {
          const version = await roomVersion(room.meetingId);
          if (version === null) {
            write("event: end\ndata: {}\n\n");
            break;
          }
          if (version !== sent) {
            const snapshot = await roomSnapshot(room.meetingId);
            if (snapshot) {
              write(`id: ${snapshot.version}\ndata: ${JSON.stringify(snapshot)}\n\n`);
              sent = snapshot.version;
            }
          } else if (Date.now() - pinged > PING_MS) {
            write("event: ping\ndata: {}\n\n");
            pinged = Date.now();
          }
          await new Promise((resolve) => setTimeout(resolve, POLL_MS));
        }
      } finally {
        controller.close();
      }
    },
  });
  return new Response(stream, {
    headers: { "content-type": "text/event-stream", "cache-control": "no-cache, no-transform" },
  });
}
