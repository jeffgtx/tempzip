import { roomSnapshot, roomVersion } from "@/meetings/room";
import { openRoom } from "./open";

// The polling fallback: the current snapshot, or 204 if the room already has it. The version is checked first,
// since it takes one small query and building the snapshot takes the whole board.
export async function GET(request: Request) {
  const room = await openRoom(request);
  if (room.error) return room.error;
  const version = await roomVersion(room.meetingId);
  if (version && version === new URL(request.url).searchParams.get("version")) return new Response(null, { status: 204 });
  const snapshot = version && (await roomSnapshot(room.meetingId));
  if (!snapshot) return new Response(null, { status: 404 });
  return Response.json(snapshot);
}
