"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { IconBuilding, IconCheck, IconPalette, IconPhoto, IconX } from "@tabler/icons-react";
import { cn } from "cn";
import { type ReactNode, useState, useTransition } from "react";
import { Controller, useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { type CustomerInput, LOGO_TYPES, customerInput, logoProblem } from "@/customers/input";
import { createCustomerAction, updateCustomerAction } from "./actions";
import type { ClusterOption } from "./cluster-chips";

const EMPTY: CustomerInput = { name: "", accent: null, clusters: [] };

export function CustomerDialog({
  clusters,
  customer,
  children,
}: {
  clusters: ClusterOption[];
  customer?: CustomerInput & { id: string; logoUrl: string | null };
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [logo, setLogo] = useState<{ file: File | null; url: string | null }>({ file: null, url: null });
  const [pending, startTransition] = useTransition();
  const form = useForm<CustomerInput>({
    resolver: zodResolver(customerInput),
    defaultValues: customer ?? EMPTY,
  });
  const { errors } = form.formState;

  const submit = form.handleSubmit((data) =>
    startTransition(async () => {
      const files = new FormData();
      if (logo.file) files.set("logo", logo.file);
      else if (customer?.logoUrl && !logo.url) files.set("removeLogo", "1");
      try {
        const result = customer
          ? await updateCustomerAction(customer.id, data, files)
          : await createCustomerAction(data, files);
        if (result?.error) form.setError("root", { message: result.error });
        else setOpen(false);
      } catch {
        form.setError("root", { message: "Those details couldn't be saved. Try again." });
      }
    }),
  );

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (next) {
          form.reset(customer ?? EMPTY);
          setLogo({ file: null, url: customer?.logoUrl ?? null });
        }
        setOpen(next);
      }}
    >
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent aria-describedby={undefined} className="sm:max-w-md">
        <DialogTitle className="sr-only">{customer ? "Edit customer" : "New customer"}</DialogTitle>
        <form onSubmit={submit} className="flex flex-col gap-4">
          <div className="flex items-center gap-2 pr-8">
            <Controller
              control={form.control}
              name="accent"
              render={({ field }) => <AccentPicker value={field.value} onChange={field.onChange} />}
            />
            <LogoPicker
              url={logo.url}
              onChange={(file) => {
                // Checked here as well: an oversized upload fails before the action can explain why.
                const problem = file && logoProblem(file);
                if (problem) return form.setError("root", { message: problem });
                form.clearErrors("root");
                setLogo({ file, url: file ? URL.createObjectURL(file) : null });
              }}
            />
            <div className="relative flex-1">
              <IconBuilding className="absolute top-2 left-2.5 size-4 text-muted-foreground" />
              <Input
                {...form.register("name")}
                aria-label="Name"
                aria-invalid={Boolean(errors.name)}
                maxLength={120}
                autoComplete="off"
                autoFocus
                className="pl-8"
              />
            </div>
          </div>
          <Controller
            control={form.control}
            name="clusters"
            render={({ field }) => (
              <div role="group" aria-label="Clusters" className="flex flex-wrap gap-2">
                {clusters.map((c) => {
                  const on = field.value.includes(c.id);
                  const locked = customer?.clusters.includes(c.id);
                  return (
                    <Button
                      key={c.id}
                      type="button"
                      variant={on ? "default" : "outline"}
                      aria-pressed={on}
                      disabled={locked}
                      onClick={() =>
                        field.onChange(on ? field.value.filter((id) => id !== c.id) : [...field.value, c.id])
                      }
                      className={cn(errors.clusters && "border-destructive")}
                    >
                      {c.name}
                    </Button>
                  );
                })}
              </div>
            )}
          />
          {errors.root && (
            <p role="alert" className="text-sm text-destructive">
              {errors.root.message}
            </p>
          )}
          <Button type="submit" disabled={pending} aria-label="Save" className="self-end">
            <IconCheck />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function AccentPicker({ value, onChange }: { value: string | null; onChange: (value: string | null) => void }) {
  return (
    <div className="flex items-center">
      <label
        title="Accent colour"
        className={cn(
          "relative grid size-8 cursor-pointer place-items-center overflow-hidden rounded-full border-2 has-focus-visible:ring-3 has-focus-visible:ring-ring/50",
          !value && "border-dashed text-muted-foreground",
        )}
        style={value ? { background: value, borderColor: value } : undefined}
      >
        {!value && <IconPalette className="size-4" />}
        <input
          type="color"
          aria-label="Accent colour"
          value={value ?? "#22d3ee"}
          onChange={(e) => onChange(e.target.value)}
          className="absolute inset-0 cursor-pointer opacity-0"
        />
      </label>
      {value && (
        <Button type="button" variant="ghost" size="icon-xs" aria-label="No accent colour" onClick={() => onChange(null)}>
          <IconX />
        </Button>
      )}
    </div>
  );
}

function LogoPicker({ url, onChange }: { url: string | null; onChange: (file: File | null) => void }) {
  return (
    <div className="flex items-center">
      <label
        title="Logo"
        className={cn(
          "relative grid size-8 cursor-pointer place-items-center overflow-hidden rounded-md border-2 has-focus-visible:ring-3 has-focus-visible:ring-ring/50",
          !url && "border-dashed text-muted-foreground",
        )}
      >
        {url ? (
          // eslint-disable-next-line @next/next/no-img-element -- a local preview or a data URL
          <img src={url} alt="" className="size-full object-contain" />
        ) : (
          <IconPhoto className="size-4" />
        )}
        <input
          type="file"
          accept={LOGO_TYPES.join(",")}
          aria-label="Logo"
          onChange={(e) => onChange(e.target.files?.[0] ?? null)}
          className="absolute inset-0 cursor-pointer opacity-0"
        />
      </label>
      {url && (
        <Button type="button" variant="ghost" size="icon-xs" aria-label="No logo" onClick={() => onChange(null)}>
          <IconX />
        </Button>
      )}
    </div>
  );
}
