"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { notFound, redirect } from "next/navigation";
import { z } from "zod";
import { requireUser } from "@/auth/current";
import { getContent } from "@/content/load";
import { createCustomer, deleteCustomer, getCustomer, updateCustomer } from "@/customers/data";
import { type CustomerInput, customerInput, logoProblem } from "@/customers/input";
import { logoDataUrl } from "@/customers/logo";

function parse(data: CustomerInput) {
  const parsed = customerInput.safeParse(data);
  const clusters = new Set(getContent().clusters.map((c) => c.id));
  return parsed.success && parsed.data.clusters.every((c) => clusters.has(c)) ? parsed.data : null;
}

const isId = (id: string) => z.uuid().safeParse(id).success;

// The logo travels as FormData: "logo" is a new file, "removeLogo" clears the current one.
type LogoChange = { file: File; problem: string | null } | { remove: boolean };

function logoChange(form: FormData): LogoChange {
  const file = form.get("logo");
  if (file instanceof File && file.size) return { file, problem: logoProblem(file) };
  return { remove: form.has("removeLogo") };
}

// The logo to save: a data URL, null to clear it or undefined to keep it.
async function logoUrl(change: LogoChange) {
  if (!("file" in change)) return change.remove ? null : undefined;
  return logoDataUrl(change.file);
}

export async function createCustomerAction(data: CustomerInput, form: FormData) {
  const user = await requireUser();
  const input = parse(data);
  const logo = logoChange(form);
  if (!input) return { error: "Those details couldn't be saved." };
  if ("problem" in logo && logo.problem) return { error: logo.problem };
  const id = randomUUID();
  await createCustomer(user.id, { ...input, id, logoUrl: await logoUrl(logo) });
  revalidatePath("/");
  redirect(`/customers/${id}`);
}

export async function updateCustomerAction(id: string, data: CustomerInput, form: FormData) {
  const user = await requireUser();
  const input = parse(data);
  const logo = logoChange(form);
  if (!input) return { error: "Those details couldn't be saved." };
  if ("problem" in logo && logo.problem) return { error: logo.problem };
  if (!isId(id) || !(await updateCustomer(user.id, id, { ...input, logoUrl: await logoUrl(logo) }))) notFound();
  revalidatePath("/", "layout");
}

export async function deleteCustomerAction(id: string, typedName: string) {
  const user = await requireUser();
  const customer = isId(id) ? await getCustomer(user.id, id) : null;
  if (!customer) notFound();
  if (typedName.trim() !== customer.name) return { error: "The name doesn't match." };
  await deleteCustomer(user.id, id);
  revalidatePath("/", "layout");
  redirect("/");
}
