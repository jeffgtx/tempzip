"use client";

import { IconTrash } from "@tabler/icons-react";
import { unstable_rethrow } from "next/navigation";
import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { deleteCustomerAction } from "./actions";

export function DeleteCustomerDialog({ id, name }: { id: string; name: string }) {
  const [typed, setTyped] = useState("");
  const [error, setError] = useState<string>();
  const [pending, startTransition] = useTransition();

  return (
    <Dialog
      onOpenChange={() => {
        setTyped("");
        setError(undefined);
      }}
    >
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Delete customer" title="Delete customer">
          <IconTrash />
        </Button>
      </DialogTrigger>
      <DialogContent aria-describedby={undefined} className="sm:max-w-sm">
        <DialogTitle className="sr-only">Delete {name}</DialogTitle>
        <form
          className="flex flex-col gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            startTransition(async () => {
              try {
                setError((await deleteCustomerAction(id, typed))?.error);
              } catch (e) {
                unstable_rethrow(e);
                setError("That couldn't be deleted. Try again.");
              }
            });
          }}
        >
          <p className="pr-8 text-sm">
            Type <strong>{name}</strong> to delete it and everything captured for it. This can&apos;t be undone.
          </p>
          <Input aria-label="Customer name" autoComplete="off" value={typed} onChange={(e) => setTyped(e.target.value)} />
          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          <Button
            type="submit"
            variant="destructive"
            disabled={pending || typed.trim() !== name}
            aria-label="Delete"
            className="self-end"
          >
            <IconTrash />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
