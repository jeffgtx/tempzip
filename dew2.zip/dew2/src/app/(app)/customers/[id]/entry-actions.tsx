"use client";

import { IconEraser, IconTrash, IconZoomIn, IconZoomInArea } from "@tabler/icons-react";
import Link from "next/link";
import type { Entry } from "@/board/model";
import { Button } from "@/components/ui/button";
import type { CockpitActions, Slot } from "./cockpit";

// What a selected entry can do from where it sits: open its zoom, add or remove it, and leave or come back.
// An entry whose row stays when it goes, such as a template concern, is cleared instead.
export function EntryActions(props: {
  slot: Slot;
  entry: Entry;
  zoomHref?: string | null;
  clears?: boolean;
  actions: CockpitActions;
}) {
  const { slot, entry, actions } = props;
  const zoomAdded = entry.attrs.zoom === true;
  return (
    <span className="flex items-center" onClick={(e) => e.stopPropagation()}>
      {props.zoomHref && (
        <Button asChild variant="ghost" size="icon-xs">
          <Link href={props.zoomHref} aria-label="Open zoom" title="Open zoom">
            <IconZoomIn />
          </Link>
        </Button>
      )}
      {slot.zoomOnRequest && (
        <Button
          variant={zoomAdded ? "default" : "ghost"}
          size="icon-xs"
          aria-pressed={zoomAdded}
          aria-label="Zoom"
          title={zoomAdded ? "Remove zoom" : "Add zoom"}
          onClick={() => actions.zoom(entry)}
        >
          <IconZoomInArea />
        </Button>
      )}
      <Button
          variant="ghost"
          size="icon-xs"
          aria-label={props.clears ? "Clear" : "Remove"}
          title={props.clears ? "Clear" : "Remove"}
          onClick={() => actions.remove(slot, entry)}
          className="hover:text-destructive"
        >
          {props.clears ? <IconEraser /> : <IconTrash />}
        </Button>
    </span>
  );
}
