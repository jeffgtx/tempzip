"use client";

import {
  IconAdjustmentsHorizontal,
  IconBoxAlignLeft,
  IconBoxAlignRight,
  IconBoxMargin,
  IconPlus,
  IconX,
} from "@tabler/icons-react";
import { cn } from "cn";
import { useEffect, useRef, useState } from "react";
import { type ConnectionField, connectionProducts, countName } from "@/board/architecture";
import { ownRecords } from "@/board/attributes";
import { type Entry, sameValue } from "@/board/model";
import type { CatalogOption } from "@/catalog/match";
import type { BoardTemplate } from "@/content/schema";
import { Button } from "@/components/ui/button";
import type { Slot } from "./cockpit";
import { DraftInput } from "./draft-input";

type Attribute = BoardTemplate["slots"][number]["attributes"][number];
type Scalar = Exclude<Attribute, { type: "records" }>;
type Row = { id: string } & Record<string, unknown>;
type Refs = (slots: string[]) => { id: string; label: string }[];
// The entry's own records a field can point at, such as a cloud's networks.
type RecordsOf = (key: string) => { id: string; name: string }[];
type Connections = {
  // The types that join the entry to a target, or with null, those that need none.
  types: (to: string | null) => string[];
  fields: (type: string | null | undefined) => ConnectionField[];
};

const control = "h-8 w-full min-w-0 truncate rounded-lg border bg-transparent px-2 text-sm";

// In the order the zoom reads, left to right.
const PLACES: Record<NonNullable<Attribute["at"]>, { Icon: typeof IconBoxMargin; name: string }> = {
  left: { Icon: IconBoxAlignLeft, name: "Left of the box" },
  box: { Icon: IconBoxMargin, name: "In the box" },
  right: { Icon: IconBoxAlignRight, name: "Right of the box" },
};

// Numbers the server accepts.
const bounded = (n: number) => (Number.isFinite(n) ? Math.min(1e9, Math.max(0, n)) : null);

// A cleared field leaves the record rather than staying as an empty value.
const withField = (row: Row, key: string, value: unknown): Row => {
  const next: Row = { ...row };
  if (value === null || value === "") delete next[key];
  else next[key] = value;
  return next;
};

// The slot's attributes for one entry.
export function FieldsEditor(props: {
  slot: Slot;
  entry: Entry;
  catalog: (CatalogOption & { category: string })[];
  refs: Refs;
  connections?: Connections;
  onSet: (key: string, value: unknown) => void;
}) {
  const { entry } = props;
  const item = props.catalog.find((o) => o.id === entry.itemId);
  const counts = countName(item?.category);
  const attributes = props.slot.attributes
    // A field the entry already holds stays, so the SE can clear it.
    .filter((a) => !a.for || (!!entry.itemId && a.for.includes(entry.itemId)) || !sameValue(entry.attrs[a.key], null))
    .map((a) => (a.key === "count" && counts ? { ...a, name: counts } : a));
  const basic = attributes.filter((a) => !a.advanced);
  const advanced = attributes.filter((a) => a.advanced);
  const [open, setOpen] = useState(() => advanced.some((a) => !sameValue(entry.attrs[a.key], null)));
  // An empty name shows what the entry goes by without one.
  const own = entry.text ?? item?.name;
  const records: RecordsOf = (key) => ownRecords(props.slot, entry.attrs, key);
  const field = (a: Attribute) => (
    <div key={a.key} data-field={a.key} className="flex flex-col gap-1">
      <span className="text-xs text-muted-foreground">{a.name}</span>
      {a.type === "records" ? (
        <Records attribute={a} value={(entry.attrs[a.key] as Row[] | undefined) ?? []} {...props} records={records} />
      ) : (
        <Field
          attribute={a}
          hint={a.key === "name" ? own : undefined}
          value={entry.attrs[a.key]}
          {...props}
          records={records}
          onSet={(v) => props.onSet(a.key, v)}
        />
      )}
    </div>
  );
  return (
    <div className="flex flex-col gap-3">
      {basic.filter((a) => !a.at).map(field)}
      {Object.entries(PLACES).map(([at, { Icon, name }]) => {
        const here = basic.filter((a) => a.at === at);
        return (
          here.length > 0 && (
            <div key={at} role="group" aria-label={name} className="flex flex-col gap-3">
              <div title={name} className="flex items-center gap-2 pt-1 text-muted-foreground">
                <Icon className="size-4 shrink-0" />
                <span className="h-px flex-1 bg-border" />
              </div>
              {here.map(field)}
            </div>
          )
        );
      })}
      {advanced.length > 0 && (
        <Button
          variant={open ? "secondary" : "ghost"}
          size="icon-xs"
          aria-label="Advanced"
          title="Advanced"
          aria-expanded={open}
          className="self-start"
          onClick={() => setOpen((o) => !o)}
        >
          <IconAdjustmentsHorizontal />
        </Button>
      )}
      {open && advanced.map(field)}
    </div>
  );
}

type Sources = { catalog: (CatalogOption & { category: string })[]; refs: Refs; records?: RecordsOf };

// What a pick or reference offers. A saved pick the list no longer offers stays, so the field never shows blank.
function optionsOf(a: Scalar, value: unknown, sources: Sources) {
  if (a.type === "ref") return sources.refs(a.slots);
  if (a.type === "record") return (sources.records?.(a.of) ?? []).map((r) => ({ id: r.id, label: r.name }));
  if (a.type !== "pick") return [];
  const options = (
    a.items?.flatMap((id) => sources.catalog.filter((o) => o.id === id)) ??
    sources.catalog.filter((o) => a.categories.includes(o.category))
  ).map((o) => ({ id: o.id, label: o.name }));
  return typeof value === "string" && !options.some((o) => o.id === value)
    ? [...options, { id: value, label: sources.catalog.find((o) => o.id === value)?.name ?? value }]
    : options;
}

// A pick of a single item is a toggle, such as a capability's In place.
const toggles = (a: Scalar, value: unknown, sources: Sources) => a.type === "pick" && optionsOf(a, value, sources).length === 1;

// In a record a list takes the whole line, since half the tray's one width cuts off options such as Guest or unmanaged.
// Numbers and text sit two to a line, an odd one out taking the whole line, and a toggle takes only its own width.
const wrap = "flex min-w-0 flex-1 flex-wrap items-center gap-1.5";
const half = "min-w-0 grow basis-[calc(50%-0.375rem)]";
const widthOf = (f: Scalar, toggle: boolean) => (toggle ? undefined : f.type === "number" || f.type === "text" ? half : "basis-full");

function Field(
  props: {
    attribute: Scalar;
    // Records show no field names above their fields, so the empty field shows its name.
    hint?: string;
    value: unknown;
    onSet: (value: unknown) => void;
  } & Sources,
) {
  const { attribute: a, value } = props;
  const label = a.name;
  switch (a.type) {
    case "number":
    case "text": {
      const shown = value === undefined || value === null ? "" : String(value);
      return (
        <DraftInput
          key={shown}
          aria-label={label}
          type={a.type === "number" ? "number" : "text"}
          min={0}
          maxLength={200}
          placeholder={props.hint}
          value={shown}
          onCommit={(v) => props.onSet(v.trim() === "" ? null : a.type === "number" ? bounded(Number(v)) : v.trim())}
          className="h-8"
        />
      );
    }
    case "pick":
    case "ref":
    case "record": {
      const options = optionsOf(a, value, props);
      if (toggles(a, value, props)) {
        const on = value === options[0].id;
        return (
          <Button
            size="xs"
            variant={on ? "default" : "outline"}
            aria-pressed={on}
            className="w-fit rounded-full"
            onClick={() => props.onSet(on ? null : options[0].id)}
          >
            {options[0].label}
          </Button>
        );
      }
      return (
        <select
          aria-label={label}
          value={(value as string | undefined) ?? ""}
          onChange={(e) => props.onSet(e.target.value || null)}
          title={options.find((o) => o.id === value)?.label}
          className={control}
        >
          <option value="">{props.hint}</option>
          {options.map((o) => (
            <option key={o.id} value={o.id}>
              {o.label}
            </option>
          ))}
        </select>
      );
    }
  }
}

// Repeatable records, such as circuits: each field commits the whole list.
function Records(
  props: {
    attribute: Extract<Attribute, { type: "records" }>;
    value: Row[];
    entry: Entry;
    records: RecordsOf;
    connections?: Connections;
    onSet: (key: string, value: unknown) => void;
  } & Sources,
) {
  const { attribute: a, value, connections } = props;
  const set = (rows: Row[]) => props.onSet(a.key, rows);
  // A new record takes the focus from +, so typing fills it in rather than pressing + again or reaching the board's keys.
  const list = useRef<HTMLDivElement>(null);
  const added = useRef<string | null>(null);
  const focusRecord = (id: string) => {
    const control = list.current?.querySelector<HTMLElement>(`[data-record="${id}"] :is(input, select, button)`);
    control?.focus();
    return !!control;
  };
  useEffect(() => {
    if (added.current && focusRecord(added.current)) added.current = null;
  });
  const add = () => {
    const last = value.at(-1);
    if (last && Object.keys(last).every((k) => k === "id")) return focusRecord(last.id);
    added.current = crypto.randomUUID();
    set([...value, { id: added.current }]);
  };
  // A field pointing at the entry's own records shows once it has one to point at, such as a cloud app's network.
  const fields = a.fields.filter((f) => f.type !== "record" || props.records(f.of).length > 0);
  const [first] = a.fields;
  const offered = a.presets.flatMap((id) => {
    const name = props.catalog.find((o) => o.id === id)?.name;
    return name ? [{ name, held: first.type === "text" ? name : id }] : [];
  });
  const holding = (held: string) => (r: Row) =>
    first.type === "text" ? String(r[first.key] ?? "").toLowerCase() === held.toLowerCase() : r[first.key] === held;
  // A chip shows what its record holds in the first field, so that record's row shows only the rest.
  const rest = fields.filter((f) => f !== first);
  // Once the chips offer everything the first field can hold, a blank record has nothing more to add.
  const addable = first.type !== "pick" || optionsOf(first, null, props).some((o) => !offered.some((c) => c.held === o.id));
  return (
    <div ref={list} className="flex flex-col gap-1.5">
      {offered.length > 0 && (
        <ul aria-label={a.name} className="flex flex-wrap gap-1">
          {offered.map(({ name, held }) => {
            const on = value.some(holding(held));
            return (
              <li key={held}>
                <Button
                  size="xs"
                  variant={on ? "default" : "outline"}
                  aria-pressed={on}
                  className="rounded-full"
                  onClick={() => set(on ? value.filter((r) => !holding(held)(r)) : [...value, { id: crypto.randomUUID(), [first.key]: held }])}
                >
                  {name}
                </Button>
              </li>
            );
          })}
        </ul>
      )}
      {value.map((row) => {
        const chip = offered.find((c) => holding(c.held)(row));
        if (chip && !rest.length) return null;
        const setRow = (next: Row) => set(value.map((r) => (r.id === row.id ? next : r)));
        const field = (f: Scalar) => (
          <div key={f.key} className={widthOf(f, toggles(f, row[f.key], props))}>
            <Field
              attribute={named(a, f)}
              hint={f.name}
              value={row[f.key]}
              catalog={props.catalog}
              refs={props.refs}
              records={props.records}
              onSet={(v) => setRow(withField(row, f.key, v))}
            />
          </div>
        );
        return (
          <div key={row.id} data-record={row.id} className="flex items-start gap-1 rounded-lg border p-1.5">
            {a.key === "connections" && connections ? (
              <ConnectionRow
                row={row}
                entry={props.entry}
                attribute={a}
                catalog={props.catalog}
                refs={props.refs}
                connections={connections}
                onSet={setRow}
              />
            ) : (
              <div className={wrap}>
                {chip && <span className={cn(half, "flex min-h-8 items-center px-2 text-sm")}>{chip.name}</span>}
                {(chip ? rest : fields).map(field)}
              </div>
            )}
            <div className="flex h-8 items-center">
              <Button
                variant="ghost"
                size="icon-xs"
                aria-label={`Remove from ${a.name}`}
                title="Remove"
                onClick={() => set(value.filter((r) => r.id !== row.id))}
              >
                <IconX />
              </Button>
            </div>
          </div>
        );
      })}
      {addable && (
        <Button
          variant="outline"
          size="icon-xs"
          aria-label={`Add to ${a.name}`}
          title="Add"
          onClick={add}
        >
          <IconPlus />
        </Button>
      )}
    </div>
  );
}

// A record's controls are named for its attribute as well as their field, such as "Connections type".
const named = (a: Attribute, f: Scalar): Scalar => ({ ...f, name: `${a.name} ${f.name.toLowerCase()}` });

const TAKEN: ConnectionField[] = ["product", "count", "speed"];

// A connection starts from its target, then offers only the types that join the two, then only the fields its type takes.
function ConnectionRow(props: {
  row: Row;
  entry: Entry;
  attribute: Extract<Attribute, { type: "records" }>;
  catalog: (CatalogOption & { category: string })[];
  refs: Refs;
  connections: Connections;
  onSet: (row: Row) => void;
}) {
  const { row, connections } = props;
  const to = (row.to as string | undefined) ?? null;
  const type = (row.type as string | undefined) ?? null;
  const def = (key: string) => props.attribute.fields.find((f) => f.key === key);
  const name = (id: string) => props.catalog.find((o) => o.id === id)?.name ?? id;
  const targetless = connections.types(null);
  const toDef = def("to");
  const typeDef = def("type");
  // A single site has no sites of its own to link.
  const linkable = (id: string) => id !== props.entry.id || props.entry.attrs.count !== 1;
  const targets =
    toDef?.type === "ref"
      ? props.refs(toDef.slots).filter((r) => r.id === to || (linkable(r.id) && connections.types(r.id).length))
      : [];
  const valid = connections.types(to);
  const typeOptions = type && !valid.includes(type) ? [...valid, type] : valid;
  const shown = TAKEN.flatMap((key) => {
    const f = def(key);
    return f && ((type && connections.fields(type).includes(key)) || !sameValue(row[key], null)) ? [f] : [];
  });

  // A new type drops the product picked for the old one, and every field it doesn't take.
  const retype = (next: Row, nextType: string | null) => {
    let out = withField(next, "type", nextType);
    const taken = connections.fields(nextType);
    for (const key of TAKEN)
      if ((key === "product" && nextType !== type) || !taken.includes(key)) out = withField(out, key, null);
    return out;
  };
  const pickTo = (value: string) => {
    if (value.startsWith("type:")) return props.onSet(retype(withField(row, "to", null), value.slice("type:".length)));
    if (!value) return props.onSet(withField(row, "to", null));
    const fits = connections.types(value);
    const nextType = type && fits.includes(type) ? type : fits.length === 1 ? fits[0] : null;
    props.onSet(retype(withField(row, "to", value), nextType));
  };
  // A product offers only its type's.
  const field = (f: Scalar) => (
    <div key={f.key} className={widthOf(f, false)}>
      <Field
        attribute={named(props.attribute, f.type === "pick" && f.key === "product" ? { ...f, items: connectionProducts(type) } : f)}
        hint={f.name}
        value={row[f.key]}
        catalog={props.catalog}
        refs={props.refs}
        onSet={(v) => props.onSet(withField(row, f.key, v))}
      />
    </div>
  );

  return (
    <div className={wrap}>
      <select
        aria-label={toDef && named(props.attribute, toDef).name}
        value={to ?? (type && targetless.includes(type) ? `type:${type}` : "")}
        onChange={(e) => pickTo(e.target.value)}
        className={cn(control, "basis-full")}
      >
        <option value="">{toDef?.name}</option>
        {targets.map((t) => (
          <option key={t.id} value={t.id}>
            {t.label}
          </option>
        ))}
        {targetless.map((t) => (
          <option key={t} value={`type:${t}`}>
            {name(t)}
          </option>
        ))}
      </select>
      {/* The target select already shows a type that needs no target, such as Local internet. */}
      {(to || (type && !targetless.includes(type))) && (
        <select
          aria-label={typeDef && named(props.attribute, typeDef).name}
          value={type ?? ""}
          onChange={(e) => props.onSet(retype(row, e.target.value || null))}
          className={cn(control, "basis-full")}
        >
          <option value="">{typeDef?.name}</option>
          {typeOptions.map((t) => (
            <option key={t} value={t}>
              {name(t)}
            </option>
          ))}
        </select>
      )}
      {shown.map(field)}
    </div>
  );
}
