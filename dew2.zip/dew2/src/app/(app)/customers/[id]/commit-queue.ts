"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { CommitResult } from "@/board/data";
import type { Commit } from "@/board/model";

const RETRY_MS = 3000;

// Moving to another board remounts the cockpit while the old one may still be sending.
// So the tab sends one batch per customer at a time, and its results reach whichever
// cockpit is showing: no commit goes twice, and its number isn't mistaken for a gap.
const inFlight = new Map<string, Promise<void>>();
const latest = new Map<string, number>();
const waiting = new Map<string, () => void>();
// The tab's commits the server has numbered, since the page a cockpit mounts with can
// have been read before they landed.
const landed = new Map<string, { seq: number; commit: Commit }[]>();

// Commits wait in localStorage until the server has them, so a reload or a lost
// connection loses nothing; they are replayed in order and the server ignores repeats.
// A rejected commit, or a gap in the sequence numbers the server hands back, means
// something else changed the customer's boards, such as an approved suggestion or
// another tab, and the cockpit's data is stale.
export function useCommitQueue(customerId: string, seq: number, onStale: () => void) {
  const key = `dew2:queue:${customerId}`;
  const loaded = useRef(seq);
  const [offline, setOffline] = useState(false);
  const sending = useRef(false);
  const wake = useRef(() => {});
  const mounted = useRef(true);
  const settle = useCallback((ids: Iterable<string>) => {
    for (const id of ids) {
      waiting.get(id)?.();
      waiting.delete(id);
    }
  }, []);

  const read = useCallback((): Commit[] => {
    try {
      return JSON.parse(localStorage.getItem(key) ?? "[]");
    } catch {
      return [];
    }
  }, [key]);
  const write = useCallback((queue: Commit[]) => localStorage.setItem(key, JSON.stringify(queue)), [key]);

  const send = useCallback(
    async (batch: Commit[]) => {
      const response = await fetch(`/api/customers/${customerId}/commits`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ commits: batch }),
      });
      // A malformed batch or a deleted customer will never succeed; anything else is retried.
      if (response.status === 400 || response.status === 404) {
        const dropped = new Set(batch.map((c) => c.id));
        write(read().filter((c) => !dropped.has(c.id)));
        settle(dropped);
        onStale();
        return;
      }
      if (!response.ok) throw new Error(`Commits not accepted: ${response.status}`);
      const { results } = (await response.json()) as { results: CommitResult[] };
      const settled = new Set(results.map((r) => r.id));
      write(read().filter((c) => !settled.has(c.id)));
      settle(settled);
      let stale = false;
      for (const r of results) {
        const seen = latest.get(customerId) ?? loaded.current;
        if ("rejected" in r || r.seq > seen + 1) stale = true;
        if (!("seq" in r)) continue;
        latest.set(customerId, Math.max(seen, r.seq));
        landed.get(customerId)?.push({ seq: r.seq, commit: batch.find((c) => c.id === r.id)! });
      }
      if (stale) onStale();
    },
    [customerId, read, write, settle, onStale],
  );

  const sendAll = useCallback(async () => {
    for (;;) {
      while (inFlight.has(customerId)) await inFlight.get(customerId)!.catch(() => {});
      const batch = read().slice(0, 50);
      if (!batch.length) return;
      const sent = send(batch);
      inFlight.set(customerId, sent);
      try {
        await sent;
      } finally {
        inFlight.delete(customerId);
      }
    }
  }, [customerId, read, send]);

  const flush = useCallback(async () => {
    if (sending.current) return;
    sending.current = true;
    try {
      while (mounted.current) {
        try {
          await sendAll();
          setOffline(false);
          return;
        } catch {
          setOffline(true);
          await new Promise<void>((resolve) => {
            wake.current = resolve;
            setTimeout(resolve, RETRY_MS);
          });
        }
      }
    } finally {
      sending.current = false;
    }
  }, [sendAll]);

  useEffect(() => {
    const mine = landed.get(customerId)?.filter((l) => l.seq > loaded.current) ?? [];
    const seen = latest.get(customerId) ?? loaded.current;
    // A page read before this tab's latest commits catches up on them. One older than the
    // commits the tab keeps, such as a page Back restores from the router's cache, can't,
    // so the next commit's number shows the gap.
    latest.set(customerId, seen - loaded.current === mine.length ? seen : loaded.current);
    landed.set(customerId, mine);
    mounted.current = true;
    void flush();
    // The retry loop is asleep whenever there is something to replay.
    const reconnect = () => {
      wake.current();
      void flush();
    };
    window.addEventListener("online", reconnect);
    return () => {
      mounted.current = false;
      window.removeEventListener("online", reconnect);
    };
  }, [customerId, flush]);

  // Resolves once the server has the commit, whenever that turns out to be.
  const push = useCallback(
    (commit: Commit) => {
      write([...read(), commit]);
      const settled = new Promise<void>((resolve) => waiting.set(commit.id, resolve));
      void flush();
      return settled;
    },
    [read, write, flush],
  );

  // Resolves once the queue is empty, or after `ms` if it doesn't empty.
  const drained = useCallback(
    async (ms: number) => {
      for (const until = Date.now() + ms; read().length && Date.now() < until; )
        await new Promise((resolve) => setTimeout(resolve, 100));
    },
    [read],
  );

  // The tab's commits the page may not have read: those that landed after it was read,
  // then those still queued.
  const unseen = useCallback(
    () => [...(landed.get(customerId) ?? []).filter((l) => l.seq > loaded.current).map((l) => l.commit), ...read()],
    [customerId, read],
  );

  return { push, queued: read, unseen, drained, offline };
}
