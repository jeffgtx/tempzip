"use client";

import { IconFlag, IconGhost, IconNote, IconPlus, IconPointFilled, IconX } from "@tabler/icons-react";
import { cn } from "cn";
import { Fragment } from "react";
import { type Entry, entriesIn, gridEntryFacts, markOf } from "@/board/model";
import type { CatalogLookup } from "@/board/summary";
import { CoverageIcon } from "@/components/coverage-icon";
import { MARK, MarkIcon } from "@/components/mark-icon";
import { Button } from "@/components/ui/button";
import { VERDICT, VerdictIcon } from "@/components/verdict-icon";
import { whole } from "@/components/whole";
import type { EditorProps, GridTemplate, Slot } from "./cockpit";
import { EntryActions } from "./entry-actions";
import { selectedClass } from "./selected";

export function GridEditor(
  props: EditorProps & {
    template: GridTemplate;
    rows: string[][];
    suggested: (slot: Slot) => string[];
    lookup: CatalogLookup;
    zoomHref: (entryId: string) => string | null;
  },
) {
  const { template, selection, actions } = props;

  // In a table of columns the row's label names the slot, so its cell shows only the questions.
  const slot = (id: string, named = true) => {
    const def = template.slots.find((s) => s.id === id)!;
    const entries = entriesIn(props.data, id).filter((e) => e.status !== "dismissed");
    const verdict = def.verdict ? VERDICT[def.verdict] : null;
    const picked = selection?.slot === id && !selection.entryId;
    return (
      <section
        key={id}
        aria-label={def.name}
        onClick={() => props.onSelect(picked && !selection.quiet ? null : { slot: id })}
        className={cn(
          "flex min-h-24 cursor-pointer flex-col gap-2 rounded-xl border p-3 hover:border-foreground/30",
          verdict?.tint,
          picked && selectedClass,
        )}
      >
        <button type="button" aria-label={def.name} className="flex flex-col self-start text-left text-muted-foreground">
          {named && (
            <span className={cn("flex items-center gap-1 text-sm font-medium", verdict?.text)}>
              {def.verdict && <VerdictIcon verdict={def.verdict} className="size-4 shrink-0" />}
              {def.name}
            </span>
          )}
          {def.questions.length > 0 && (
            <span className="text-xs">
              {def.questions.map((q, i) => (
                <Fragment key={q}>
                  {i > 0 && <IconPointFilled className="mx-1 inline size-2 align-middle" aria-hidden />}
                  {q}
                </Fragment>
              ))}
            </span>
          )}
        </button>
        <ul className="flex flex-wrap gap-1.5">
          {entries.map((e) => (
            <li key={e.id}>
              <EntryChip
                entry={e}
                label={props.label(e)}
                {...gridEntryFacts(template, id, e.attrs, props.lookup)}
                selected={selection?.entryId === e.id}
                onMark={() => actions.cycleMark(e)}
                onClick={(event) => {
                  event.stopPropagation();
                  // One click puts a ghost back in the room.
                  if (e.status === "ghost") actions.confirm(e);
                  else props.onSelect(selection?.entryId === e.id ? null : { slot: id, entryId: e.id });
                }}
              >
                {selection?.entryId === e.id && (
                  <EntryActions slot={def} entry={e} zoomHref={props.zoomHref(e.id)} actions={actions} />
                )}
              </EntryChip>
            </li>
          ))}
          {props.suggested(def).map((itemId) => (
            <li key={itemId}>
              <Suggestion
                name={props.name(itemId)}
                onAccept={() => actions.pick(def, itemId)}
                onDismiss={() => actions.dismiss(def, itemId)}
              />
            </li>
          ))}
        </ul>
      </section>
    );
  };

  return (
    <div className="flex max-w-5xl min-w-min flex-col gap-4">
      {template.strip && slot(template.strip)}
      {template.columns ? (
        <div className="grid gap-4" style={{ gridTemplateColumns: `fit-content(10rem) repeat(${template.columns.length}, 1fr)` }}>
          <div />
          {template.columns.map((c) => (
            <h2 key={c} className="text-sm font-medium text-muted-foreground">
              {c}
            </h2>
          ))}
          {props.rows.map((row) => (
            <Fragment key={row.join()}>
              <h3 className="pt-3 text-sm font-medium">{template.slots.find((s) => s.id === row[0])!.name}</h3>
              {row.map((id) => slot(id, false))}
            </Fragment>
          ))}
        </div>
      ) : (
        runs(props.rows).map((run) => (
          <div key={run.join()} className="grid gap-4" style={{ gridTemplateColumns: `repeat(${run[0].length}, 1fr)` }}>
            {run.flat().map((id) => slot(id))}
          </div>
        ))
      )}
    </div>
  );
}

// Rows of as many slots share one grid, so a cell's longest word widens its column in every row and they stay in line.
// A row of another count lines up with none, as in the room.
function runs(rows: string[][]) {
  const out: string[][][] = [];
  for (const row of rows) {
    const last = out.at(-1);
    if (last?.[0].length === row.length) last.push(row);
    else out.push([row]);
  }
  return out;
}

// Never narrower than its longest word, so its label breaks only between words, and its actions drop beneath it rather
// than squeeze it.
function EntryChip(props: {
  entry: Entry;
  label: string;
  coverage: string | null;
  goal: string | null;
  detail: string[];
  selected: boolean;
  onClick: (e: React.MouseEvent) => void;
  onMark: () => void;
  children?: React.ReactNode;
}) {
  const { entry } = props;
  const ghost = entry.status === "ghost";
  const mark = markOf(entry.attrs);
  const icon = mark ? (
    <MarkIcon mark={mark} className={cn("size-3.5", !ghost && MARK[mark].cockpit.text)} />
  ) : (
    <IconFlag className="size-3.5 text-muted-foreground/40" />
  );
  // A button only on the selected chip, so one Mark button exists at a time; elsewhere the slot clicks as the chip does.
  const slot =
    props.selected && !ghost ? (
      <Button
        variant="ghost"
        size="icon-xs"
        aria-label="Mark"
        title="Mark"
        className="ml-1 shrink-0 rounded-full"
        onClick={(event) => {
          event.stopPropagation();
          props.onMark();
        }}
      >
        {icon}
      </Button>
    ) : (
      <span aria-hidden className="ml-1 inline-flex size-6 shrink-0 items-center justify-center" onClick={props.onClick}>
        {icon}
      </span>
    );
  return (
    <span
      className={cn(
        "inline-flex max-w-full flex-wrap items-center justify-end rounded-2xl border bg-background text-sm",
        mark && !ghost && MARK[mark].cockpit.border,
        ghost && "border-dashed text-muted-foreground",
        props.selected && selectedClass,
      )}
    >
      <span className="inline-flex grow items-center">
        {slot}
        <button
          type="button"
          onClick={props.onClick}
          aria-pressed={props.selected}
          title={ghost ? "Show in the room" : undefined}
          className={cn("inline-flex grow items-center gap-1 py-1 pl-1 text-left", props.children ? "pr-1" : "pr-3")}
        >
          {ghost && <IconGhost className="size-3.5 shrink-0" />}
          {props.coverage && (
            <CoverageIcon level={props.coverage} className={cn("size-3.5 shrink-0", props.goal && "text-muted-foreground")} />
          )}
          {props.goal && <CoverageIcon level={props.goal} className="size-3.5 shrink-0 text-(--customer)" />}
          <span>{whole(props.label)}</span>
          {typeof entry.attrs.count === "number" && (
            <span className="shrink-0 whitespace-nowrap text-muted-foreground">×{entry.attrs.count.toLocaleString("en-US")}</span>
          )}
          {props.detail.map((d, i) => (
            <span key={i} className="shrink-0 whitespace-nowrap text-xs text-muted-foreground">
              {d}
            </span>
          ))}
          {entry.note && <IconNote className="size-3.5 shrink-0 text-muted-foreground" aria-label="Has a note" />}
        </button>
      </span>
      {props.children}
    </span>
  );
}

// A catalog item another slot holds, offered here: one click accepts, the other dismisses.
export function Suggestion(props: { name: string; onAccept: () => void; onDismiss: () => void }) {
  return (
    <span className="inline-flex items-center rounded-full border border-dashed text-sm text-muted-foreground">
      <button
        type="button"
        title="Accept"
        onClick={(event) => {
          event.stopPropagation();
          props.onAccept();
        }}
        className="inline-flex items-center gap-1 rounded-l-full py-1 pr-1 pl-2.5 text-left hover:text-foreground"
      >
        <IconPlus className="size-3.5 shrink-0" />
        <span>{whole(props.name)}</span>
      </button>
      <button
        type="button"
        aria-label="Dismiss"
        title="Dismiss"
        onClick={(event) => {
          event.stopPropagation();
          props.onDismiss();
        }}
        className="rounded-r-full py-1 pr-2.5 pl-1 hover:text-foreground"
      >
        <IconX className="size-3.5" />
      </button>
    </span>
  );
}
