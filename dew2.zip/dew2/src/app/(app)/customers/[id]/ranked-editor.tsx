"use client";

import {
  IconAntennaBars3,
  IconAntennaBars4,
  IconAntennaBars5,
  IconCircleOff,
  IconGhost,
  IconLink,
  IconNote,
  IconPlus,
} from "@tabler/icons-react";
import { cn } from "cn";
import { type ConcernRow, attachedTo } from "@/board/concerns";
import type { Entry } from "@/board/model";
import type { BoardTemplate } from "@/content/schema";
import { Button } from "@/components/ui/button";
import type { EditorProps } from "./cockpit";
import { EntryActions } from "./entry-actions";
import { selectedClass } from "./selected";

const LEVELS = [
  [0, IconCircleOff, "Not a concern"],
  [1, IconAntennaBars3, "Low"],
  [2, IconAntennaBars4, "Medium"],
  [3, IconAntennaBars5, "High"],
] as const;

export function RankedEditor({
  template,
  rows,
  selection,
  label,
  name,
  onSelect,
  onAdd,
  actions,
}: EditorProps & { template: Extract<BoardTemplate, { layout: "ranked-list" }>; rows: ConcernRow<Entry>[] }) {
  const slot = template.slots[0];

  return (
    <div className="flex max-w-3xl flex-col gap-2">
      <ul className="flex flex-col gap-1.5">
        {rows.map(({ key, itemId, entry, implied, picked, level }) => {
          const ghost = entry?.status === "ghost";
          const selected = (!!entry && selection?.entryId === entry.id) || (!!itemId && selection?.itemId === itemId);
          return (
            <li
              key={key}
              className={cn(
                "flex items-center gap-3 rounded-lg border px-2 py-1",
                ghost
                  ? "border-dashed text-muted-foreground [&_[aria-pressed=true]]:bg-muted-foreground"
                  : level === 0 && "text-muted-foreground",
                selected && selectedClass,
              )}
            >
              {/* One level at a time. An answer's implied 1 shows outlined until the SE picks; tapping the pick clears it. */}
              <div role="group" aria-label="Level" className="flex">
                {LEVELS.map(([value, Icon, title]) => {
                  // The room shows a ghost at the level its answers imply, not at its own earlier pick.
                  const suggested = implied && value === 1 && (picked === null || ghost);
                  return (
                    <Button
                      key={value}
                      size="icon-sm"
                      variant={picked === value ? "default" : suggested ? "outline" : "ghost"}
                      aria-pressed={picked === value}
                      aria-label={title}
                      title={suggested ? "Low, from their answers" : title}
                      onClick={() => actions.level(slot, entry ?? itemId!, value)}
                    >
                      <Icon />
                    </Button>
                  );
                })}
              </div>
              {entry ? (
                <button
                  type="button"
                  title={ghost ? "Show in the room" : undefined}
                  onClick={() => (ghost ? actions.confirm(entry) : onSelect(selected ? null : { slot: slot.id, entryId: entry.id }))}
                  className="flex flex-1 items-center gap-1.5 text-left text-sm"
                >
                  {ghost && <IconGhost className="size-3.5 shrink-0" />}
                  {label(entry)}
                  {entry.note && <IconNote className="size-3.5 shrink-0 text-muted-foreground" aria-label="Has a note" />}
                  {attachedTo(entry.attrs).length > 0 && (
                    <IconLink
                      className="size-3.5 shrink-0 text-muted-foreground"
                      title={`Attached to ${attachedTo(entry.attrs).map(name).join(", ")}`}
                      aria-label={`Attached to ${attachedTo(entry.attrs).map(name).join(", ")}`}
                    />
                  )}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onSelect(selected ? null : { slot: slot.id, itemId: itemId! })}
                  className="flex-1 text-left text-sm"
                >
                  {name(itemId!)}
                </button>
              )}
              {selected && entry && <EntryActions slot={slot} entry={entry} clears={slot.presets.includes(itemId ?? "")} actions={actions} />}
            </li>
          );
        })}
      </ul>
      <Button
        variant="outline"
        size="icon-sm"
        aria-label="Add a concern"
        title="Add a concern"
        onClick={() => onAdd(slot.id)}
      >
        <IconPlus />
      </Button>
    </div>
  );
}
