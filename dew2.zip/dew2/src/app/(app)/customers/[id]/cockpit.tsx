"use client";

import { unstable_rethrow, useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { flushSync } from "react-dom";
import { accentOrDefault } from "@/app/present/room-canvas";
import { PRISMA_SASE, connectionFields, connectionTypes, hubOp } from "@/board/architecture";
import { attachAttrs, concernGroups, detachAttrs, groupFor, levelAttrs, pickedLevel, reattached } from "@/board/concerns";
import {
  type BoardData,
  type Commit,
  type Entry,
  MARKS,
  type Mark,
  type Op,
  type SingleOp,
  addOp,
  applyDiagrams,
  applyOp,
  boardCategories,
  carriedEntries,
  clearOp,
  type Diagram,
  ensureOp,
  entriesIn,
  entryIds,
  gridRows,
  invert,
  live,
  opChain,
  paneOf,
  removeEntryOp,
  removeOp,
  setAttrOp,
  undoStacks,
  updateOp,
  visitOp,
  zoomOf,
  zoomOnlyChange,
} from "@/board/model";
import { type Step, flowPath, flowsAt, stepOp } from "@/board/flows";
import { presetOps } from "@/board/presets";
import { type Placed, suggestions } from "@/board/propagation";
import { appAttributes, appKind } from "@/board/zooms";
import type { CatalogOption } from "@/catalog/match";
import type { Architecture, BoardTemplate, CatalogItem, Category } from "@/content/schema";
import { useBriefly } from "@/components/use-briefly";
import type { ClusterOption } from "../cluster-chips";
import { useCommitQueue } from "./commit-queue";
import { DiagramPicker } from "./diagram-picker";
import type { EditableTemplate } from "./editable";
import { FieldsEditor } from "./fields-editor";
import { type FlowContext, FlowList, FlowSteps } from "./flow-builder";
import { GridEditor } from "./grid-editor";
import { LitMapEditor } from "./lit-map-editor";
import { ListEditor } from "./list-editor";
import { endMeetingAction, startMeetingAction } from "./meeting-actions";
import { NotesPanel, useNotesPanel } from "./notes-panel";
import { PreviewPanel } from "./preview-panel";
import { Rail, type RailSection, type RailZoom } from "./rail";
import { RankedEditor } from "./ranked-editor";
import { ReturnVisit } from "./return-visit";
import { suggestAction } from "./suggest-action";
import { TopBar } from "./top-bar";
import { PlacementControls, SummaryEditor, summaryOf } from "./summary-editor";
import { Tray } from "./tray";
import { type CockpitZoom, ZoomEditor, zoomShows } from "./zoom-editor";

export type GridTemplate = Extract<BoardTemplate, { layout: "grid" }>;
export type Slot = BoardTemplate["slots"][number];
// A capability or capability group on the lit map is a catalog item rather than an entry. A quiet one is the slot "/" opened
// with nothing selected, which isn't where the SE chose to put anything, so the room doesn't outline it.
export type Selection = { slot: string; entryId?: string; itemId?: string; quiet?: boolean };
export type CockpitCustomer = {
  id: string;
  name: string;
  accent: string | null;
  logoUrl: string | null;
  clusters: string[];
};
export type LitInput = {
  groups: CatalogItem[];
  items: CatalogItem[];
  concerns: Pick<Entry, "id" | "itemId" | "text" | "attrs">[];
  implied: string[];
  // The group whose zoom is open.
  zoomed: string | null;
  // The cluster's Concerns board, which keeps the concerns the SE attaches to capabilities. Its own concerns aren't in
  // concerns above, since the cockpit edits them.
  concernsBoard: { id: string; slot: Slot; data: BoardData } | null;
};
type Meeting = { id: string; code: string; held: boolean; pane: number };
type View = { boardId: string | null; pane: number; focus: string | null; held: boolean };

const subscribeOnline = (onChange: () => void) => {
  window.addEventListener("online", onChange);
  window.addEventListener("offline", onChange);
  return () => {
    window.removeEventListener("online", onChange);
    window.removeEventListener("offline", onChange);
  };
};

// How long queued commits get to land before the server's copy is read back:
// the notes at End, or the entry a suggestion names.
const DRAIN_MS = 5000;

// The view the room shows. Moving to another board remounts the cockpit, so the tab
// sends one request per customer at a time, always the latest view, and an older view
// can never land after a newer one. Every call resolves once the latest view has landed.
const views = new Map<string, string>();
const sendingViews = new Map<string, Promise<void>>();

function sendView(customerId: string, view: View) {
  views.set(customerId, JSON.stringify(view));
  if (!sendingViews.has(customerId)) sendingViews.set(customerId, sendViews(customerId));
  return sendingViews.get(customerId)!;
}

async function sendViews(customerId: string) {
  let sent: string | null = null;
  try {
    while (views.get(customerId) !== sent) {
      const body = views.get(customerId)!;
      try {
        const response = await fetch(`/api/customers/${customerId}/view`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body,
        });
        if (response.ok || response.status === 404) {
          sent = body;
          continue;
        }
      } catch {}
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }
  } finally {
    sendingViews.delete(customerId);
  }
}

// A concern attached where its catalog item already routes records only its level, so the commit can't say which
// capability's zoom it was attached in. The tab remembers, for undo to go back there rather than to Concerns.
const routedAttach = new Map<string, string>();

export function Cockpit(props: {
  customer: CockpitCustomer;
  // The customer's latest commit when the page loaded.
  seq: number;
  clusterOptions: ClusterOption[];
  rail: RailSection[];
  board: { id: string; template: EditableTemplate; data: BoardData } | null;
  // The zoom open on the board, which the room shows instead of the board itself.
  zoom: CockpitZoom | null;
  lit: LitInput | null;
  placed: Placed[];
  // The concerns implied by the answers on a ranked list's impliedBy boards.
  implied: string[];
  catalog: (CatalogOption & { category: string })[];
  names: Record<string, string>;
  categories: Category[];
  architectures: Architecture[];
  // The summary's diagrams, and the one this is.
  diagrams: { list: Diagram[]; current: Diagram } | null;
  suggested: string[];
  meeting: Meeting | null;
  pending: string[];
  log: Commit[];
}) {
  const { customer, board, zoom } = props;
  const router = useRouter();
  const [data, setData] = useState<BoardData>(board?.data ?? { entries: [] });
  const [diagrams, setDiagrams] = useState(props.diagrams?.list ?? []);
  const concernsBoard = props.lit?.concernsBoard;
  const [concernsData, setConcernsData] = useState<BoardData>(concernsBoard?.data ?? { entries: [] });
  const [log, setLog] = useState(props.log);
  const [meeting, setMeeting] = useState(props.meeting);
  const [pending, setPending] = useState(props.pending);
  const [suggested, setSuggested] = useState(props.suggested);
  // Boards whose return-visit choice is made but not yet on the server.
  const [settling, setSettling] = useState<string[]>([]);
  const [pane, setPane] = useState(props.meeting?.pane ?? 0);
  const [held, setHeld] = useState(props.meeting?.held ?? false);
  // The tray and the preview panel share the right edge, so opening one closes the other.
  const [selection, select] = useState<Selection | null>(() => {
    const zoomed = board?.data.entries.find((e) => e.id === zoom?.entryId);
    return zoomed ? { slot: zoomed.slot, entryId: zoomed.id } : null;
  });
  const [preview, setPreview] = useState<string | null>(null);
  const [notesOpen, setNotesOpen] = useNotesPanel(customer.id);
  const setSelection = useCallback((next: React.SetStateAction<Selection | null>) => {
    select(next);
    setPreview(null);
  }, []);
  const search = useRef<HTMLInputElement>(null);
  // Counts commits the server has taken, so views of other boards know to refetch.
  const [synced, setSynced] = useState(0);
  const reload = useCallback(() => window.location.reload(), []);
  const { push, queued, unseen, drained, offline } = useCommitQueue(customer.id, props.seq, reload);
  const online = useSyncExternalStore(subscribeOnline, () => navigator.onLine, () => true);
  // Start or End didn't reach the server.
  const [unreachable, setUnreachable] = useBriefly(5000);
  const disconnected = offline || !online || unreachable;
  const reaching = (action: () => Promise<void>) => async () => {
    try {
      await action();
    } catch (error) {
      unstable_rethrow(error);
      setUnreachable(true);
    }
  };

  // The tab's commits the page didn't read, such as ones queued before a reload, go on
  // top of the server's data.
  useEffect(() => {
    const waiting = unseen();
    if (!waiting.length) return;
    const onto = (boardId: string) => (d: BoardData) =>
      waiting.filter((c) => c.boardId === boardId).reduce((acc, c) => applyOp(acc, c.op), d);
    // eslint-disable-next-line react-hooks/set-state-in-effect -- localStorage only exists after mount
    if (board) setData(onto(board.id));
    if (concernsBoard) setConcernsData(onto(concernsBoard.id));
    setDiagrams((l) => waiting.reduce((acc, c) => applyDiagrams(acc, c.op), l));
    if (props.meeting) setLog((l) => [...l, ...waiting.filter((c) => !l.some((x) => x.id === c.id))]);
    // Other boards' commits show in what the page reads, such as the rail's dots, so it reads again once they land.
    if (waiting.every((c) => c.boardId === board?.id || c.boardId === concernsBoard?.id)) return;
    let mounted = true;
    void (async () => {
      while (mounted && queued().length) await new Promise((resolve) => setTimeout(resolve, 250));
      if (mounted) router.refresh();
    })();
    return () => {
      mounted = false;
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps -- once, on mount

  // The entry an undo names has opened its group. Left in the URL, a reload, such as on a stale commit, would show
  // that group again whichever the SE has moved to since.
  useEffect(() => {
    const url = new URL(window.location.href);
    if (!url.searchParams.has("entry")) return;
    url.searchParams.delete("entry");
    window.history.replaceState(null, "", url);
  }, []);

  const commit = useCallback(
    (op: Op, target?: { boardId: string; reverts?: string; id?: string }) => {
      if (!board) return Promise.resolve();
      const c: Commit = {
        id: target?.id ?? crypto.randomUUID(),
        boardId: target?.boardId ?? board.id,
        op,
        reverts: target?.reverts ?? null,
        meetingId: meeting?.id ?? null,
      };
      const local = c.boardId === board.id || c.boardId === concernsBoard?.id;
      if (c.boardId === board.id) setData((d) => applyOp(d, op));
      else if (local) setConcernsData((d) => applyOp(d, op));
      setDiagrams((l) => applyDiagrams(l, op));
      setLog((l) => [...l, c]);
      const sent = push(c);
      void sent.then(() => {
        setSynced((n) => n + 1);
        // Another board's change, such as an undone rating, can move this board's lit map or suggestions.
        if (!local) router.refresh();
      });
      return sent;
    },
    [board, concernsBoard, meeting, push, router],
  );

  const showPane = useCallback(
    (p: number) => {
      setPane(p);
      // Groups hold different slots or concerns, so the tray closes rather than edit one the board no longer shows.
      if ((board?.template.layout === "grid" || board?.template.layout === "ranked-list") && p !== pane) select(null);
    },
    [board, pane],
  );

  const zoomEntry = zoom?.entryId ? data.entries.find((e) => e.id === zoom.entryId) : undefined;
  // Deleting the zoomed entry deletes its zoom board too, and the board it zooms from stands in. Once
  // undo has put the entry back on the server, the page makes the board again.
  const [zoomLost, setZoomLost] = useState(false);
  if (zoom?.entryId && !zoomEntry && !zoomLost) setZoomLost(true);
  const restored = zoomLost && !!zoomEntry;
  useEffect(() => {
    if (restored && !queued().length) router.refresh();
  }, [restored, synced, queued, router]);

  const catalogById = useMemo(() => new Map(props.catalog.map((o) => [o.id, o])), [props.catalog]);
  const name = useCallback(
    (itemId: string) => props.names[itemId] ?? catalogById.get(itemId)?.name ?? itemId,
    [props.names, catalogById],
  );
  // An entry's own name attribute, such as "DC-East", names it before its catalog item does.
  const label = useCallback(
    (e: Entry) => (typeof e.attrs.name === "string" && e.attrs.name) || (e.itemId ? name(e.itemId) : e.text!),
    [name],
  );
  const lookup = useCallback(
    (id: string) => {
      const item = catalogById.get(id);
      return item ? { name: item.name, category: item.category } : undefined;
    },
    [catalogById],
  );
  // While the ranked list awaits its return-visit choice, its concerns imply nothing, as in the room.
  const implied = useMemo(
    () => new Set(board && pending.includes(board.id) ? [] : props.implied),
    [props.implied, board, pending],
  );
  const groups =
    board?.template.layout === "ranked-list"
      ? board.template.slots[0].categories.map((id) => props.categories.find((c) => c.id === id)!)
      : [];
  const concerns =
    board?.template.layout === "ranked-list"
      ? concernGroups(
          board.template.slots[0],
          groups,
          entriesIn(data, board.template.slots[0].id).filter((e) => e.status !== "dismissed"),
          (id) => catalogById.get(id)?.category,
          implied,
        )
      : null;
  // The picker is the cockpit's, so its dots count ghosts, as the rail's does.
  const picker = concerns
    ? concerns.map((g) => ({
        name: g.name,
        mark: g.rows.some((r) => (r.level ?? 0) > 0) ? "Has concerns" : null,
        accent: true,
      }))
    : board?.template.layout === "grid" && board.template.groups
      ? board.template.groups.map((g) => ({
          name: g.name,
          mark: g.rows.flat().some((id) => entriesIn(data, id).some((e) => e.status !== "dismissed")) ? "Has entries" : null,
        }))
      : undefined;
  const showGroup = (id: unknown) => setPane(Math.max(0, groups.findIndex((g) => g.id === id)));
  // A lit map's live group entries hide those groups.
  const hidden = useMemo(
    () =>
      new Set(
        board?.template.layout === "lit-map"
          ? entriesIn(data, board.template.slots[0].id).flatMap((e) => (e.status === "live" && e.itemId ? [e.itemId] : []))
          : [],
      ),
    [board, data],
  );
  // The room shows a lit map's group zoom, as the pane after the map, only while the group isn't hidden.
  const litGroup = props.lit?.groups.find((g) => g.id === props.lit?.zoomed && !hidden.has(g.id));
  const current = diagrams.find((d) => d.id === props.diagrams?.current.id);
  const diagram = current?.name ?? "";
  const summary = useMemo(
    () => (board?.template.layout === "hub-and-spoke" ? summaryOf(board.template, data, diagram, lookup) : null),
    [board, data, diagram, lookup],
  );
  // The zooms of the entries the cockpit shows. A ghost's is quiet and opens here only, since the
  // room keeps the board until a click confirms it.
  const zooms = useMemo((): RailZoom[] => {
    const template = board?.template;
    if (!template) return [];
    if (template.layout === "lit-map")
      return (props.lit?.groups ?? []).map((g) => ({
        key: g.id,
        name: g.name,
        icon: { category: g.category, itemId: g.id },
        quiet: hidden.has(g.id),
      }));
    if (template.layout !== "hub-and-spoke") {
      return template.slots.flatMap((slot) =>
        entriesIn(data, slot.id).flatMap((e) => {
          const category = (e.itemId && catalogById.get(e.itemId)?.category) || slot.categories[0];
          const ghost = e.status === "ghost";
          return e.status !== "dismissed" && zoomOf(template, slot.id, category, e.attrs)
            ? [{ key: e.id, name: label(e), icon: { category, itemId: e.itemId }, quiet: ghost, ghost }]
            : [];
        }),
      );
    }
    const slots = new Map(data.entries.map((e) => [e.id, e.slot]));
    const ghosts = new Set(data.entries.filter((e) => e.status === "ghost").map((e) => e.id));
    // The room folds only what it shows.
    const folded = Object.values(summaryOf(template, live(data), diagram, lookup).placement.folded).flat().length;
    return [
      ...summaryOf(template, data, diagram, lookup)
        .view.nodes.filter((n) => zoomOf(template, slots.get(n.id) ?? "", n.category))
        .map((n) => ({
          key: n.id,
          name: n.name,
          icon: { category: n.category, itemId: n.itemId },
          quiet: ghosts.has(n.id),
          ghost: ghosts.has(n.id),
        })),
      ...(folded && template.more ? [{ key: "more", name: `+${folded} more`, icon: null, quiet: false }] : []),
    ];
  }, [board, data, diagram, lookup, catalogById, label, props.lit, hidden]);
  // The "+N more" zoom stands down while the diagram folds nothing, and an entry's once its zoom is removed.
  const onRequest = board?.template.slots.find((s) => s.id === zoomEntry?.slot)?.zoomOnRequest;
  const opens = zoom?.entryId ? !!zoomEntry && (!onRequest || zoomEntry.attrs.zoom === true) : zooms.some((z) => z.key === "more");
  const zoomed = zoom && opens ? zoom : null;

  const zoomHref = useCallback(
    (entryId: string) =>
      !disconnected && zooms.some((z) => z.key === entryId)
        ? `?board=${board!.template.id}${props.diagrams ? `&diagram=${board!.id}` : ""}&zoom=${entryId}`
        : null,
    [zooms, board, disconnected, props.diagrams],
  );

  const stacks = useMemo(() => undoStacks(log), [log]);
  // Undoing a change out of sight shows it, so the SE sees what it did: on another board by opening that board, and on
  // a board in groups at the group holding it.
  const revert = useCallback(
    (stack: Commit[]) => {
      const top = stack.at(-1);
      if (!top) return;
      const inverse = invert(top.op);
      commit(inverse, { boardId: top.boardId, reverts: top.id });
      const ids = entryIds(top.op);
      // Attaching changes one concern's entry on Concerns, but is done in a lit map's group zoom. Undoing a Remove puts an
      // attached concern back as attaching would, so it's the change as first made that tells.
      const made = (c: Commit): Commit => {
        const reverted = log.find((l) => l.id === c.reverts);
        return reverted ? made(reverted) : c;
      };
      const capability = ids.length === 1 ? (reattached(made(top).op)[0] ?? routedAttach.get(made(top).id)) : undefined;
      if (capability && props.lit) {
        const group = props.lit.items.find((i) => i.id === capability)?.group;
        if (group && group !== props.lit.zoomed && !disconnected) router.push(`?board=${board!.template.id}&zoom=${group}`);
      } else if (top.boardId === board?.id && !capability) {
        // A zoom is a board of its own to the rail and the room. It stays open for a change to what it shows, before
        // or after, and otherwise gives way to the changed entry's zoom or the board. A grid shows some of an entry's
        // fields only in its zoom.
        const own = ids.find((id) => zoomHref(id));
        const changed = [...carriedEntries(top.op), ...data.entries].filter((e) => ids.includes(e.id));
        const shows = (d: BoardData) => zoomShows(board.template, zoomed!, d, diagram, lookup);
        const litZoom = board.template.layout === "lit-map" ? props.lit?.zoomed : null;
        const seen =
          !ids.length ||
          (litZoom
            ? changed.some((e) => e.itemId === litZoom || props.lit!.items.find((i) => i.id === e.itemId)?.group === litZoom)
            : zoomed
              ? ids.some((id) => shows(data).has(id) || shows(applyOp(data, inverse)).has(id))
              : !(own && board.template.layout === "grid" && zoomOnlyChange(top.op) === own));
        if (!seen) {
          if (!disconnected)
            router.push(litZoom ? `?board=${board.template.id}` : own ? zoomHref(own)! : `?boardId=${board.id}&entry=${ids[0]}`);
          return;
        }
        const categoryOf = (itemId: string) => props.catalog.find((o) => o.id === itemId)?.category;
        const panes = changed.flatMap((e) => paneOf(board.template, e, categoryOf) ?? []);
        if (panes.length && !panes.includes(pane)) showPane(panes[0]);
      } else if (!disconnected) {
        const zoom = zoomOnlyChange(top.op);
        router.push(
          `?boardId=${top.boardId}${ids.length ? `&entry=${ids[0]}` : ""}${capability ? `&capability=${capability}` : ""}${zoom ? `&zoom=${zoom}` : ""}`,
        );
      }
    },
    [commit, log, board, data, pane, showPane, props.catalog, props.lit, disconnected, router, zoomHref, zoomed, diagram, lookup],
  );
  const undo = useCallback(() => revert(stacks.undo), [revert, stacks]);
  const redo = useCallback(() => revert(stacks.redo), [revert, stacks]);

  // The summary's "+N more" is its second pane, shown only while that zoom is open.
  const roomPane = props.lit
    ? litGroup
      ? props.lit.groups.indexOf(litGroup) + 1
      : 0
    : board?.template.layout === "hub-and-spoke"
      ? zoomed && !zoomed.entryId
        ? 1
        : 0
      : pane;

  // A zoom's cards open their fields, so it has no type-ahead.
  const focusSearch = useCallback(() => {
    const template = board?.template;
    const first = zoomed
      ? undefined
      : template?.layout === "grid"
        ? (template.strip ?? gridRows(template, pane)[0]?.[0])
        : template?.layout === "lit-map"
          ? undefined
          : template?.slots[0].id;
    if (!first) return;
    flushSync(() => setSelection((s) => (s ? { slot: s.slot, quiet: s.quiet } : { slot: first, quiet: true })));
    search.current?.focus();
  }, [board, zoomed, pane, setSelection]);
  const openAdd = useCallback(
    (slot: string) => {
      flushSync(() => setSelection({ slot }));
      search.current?.focus();
    },
    [setSelection],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const field = e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement ? e.target : null;
      // An empty field has no text to undo, so the board's undo applies there too.
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z" && !field?.value) {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
      } else if (e.key === "Escape") {
        // A menu, dialog or type-ahead that used Escape marks it so; a select or a field holding text keeps it.
        if (e.defaultPrevented || field?.value || e.target instanceof HTMLSelectElement) return;
        field?.blur();
        select(null);
      } else if (field || e.target instanceof HTMLSelectElement) return;
      else if (e.key === "/") {
        e.preventDefault();
        focusSearch();
      } else if (e.key.toLowerCase() === "h" && !e.metaKey && !e.ctrlKey && !e.altKey) setHeld((h) => !h);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo, focusSearch]);

  // The room shows a board only once its return-visit choice is on the server, and a zoom
  // only while the server has its board and its entry isn't a ghost.
  const roomZoom = zoomed && !zoomLost && zoomEntry?.status !== "ghost" ? zoomed : null;
  const shown = board && !pending.includes(board.id) && !settling.includes(board.id) ? (roomZoom?.id ?? board.id) : null;
  // The zooms draw their own picture, the summary lights only a flow picked, and a bare slot on Concerns or a list is its
  // add tray, with nothing to light.
  const layout = board?.template.layout;
  const flows = board?.template.layout === "hub-and-spoke" ? board.template.flows : undefined;
  const focus =
    !selection || selection.quiet || roomZoom
      ? null
      : layout === "hub-and-spoke"
        ? selection.slot === flows && selection.entryId
          ? `entry:${selection.entryId}`
          : null
        : selection.entryId
          ? `entry:${selection.entryId}`
          : selection.itemId
            ? `item:${selection.itemId}`
            : layout === "grid"
              ? `slot:${selection.slot}`
              : null;
  // The meeting and board of the room's view once the server has it, from when the running meeting's notes include that board.
  const [viewed, setViewed] = useState<string | null>(null);
  useEffect(() => {
    if (!meeting) return;
    void sendView(customer.id, { boardId: shown, pane: roomPane, focus, held }).then(() => setViewed(`${meeting.id}:${shown}:${roomPane}:${held}`));
  }, [meeting, customer.id, shown, roomPane, focus, held]);

  const find = (slot: Slot, match: (e: Entry) => boolean) => entriesIn(data, slot.id).find(match);

  const add = (slot: Slot, entry: { itemId?: string; text?: string; attrs?: Entry["attrs"] }) => {
    // A concern in the customer's words joins the group shown.
    const attrs =
      entry.attrs ??
      (board?.template.layout === "list"
        ? { owner: "us" }
        : board?.template.layout === "ranked-list" && entry.text
          ? { group: groups[pane]?.id }
          : undefined);
    const id = crypto.randomUUID();
    commit(addOp(data, { id, slot: slot.id, ...entry, attrs }));
    return id;
  };

  // Adding what's already there brings it back from the ghosts.
  const bringBack = (existing: Entry) => {
    if (existing.status !== "live") commit(updateOp([existing], { status: "live" }));
  };

  // Prisma SASE adds whichever of Prisma Access and Prisma SD-WAN the diagram lacks, or brings it back, and
  // groups them, as one undoable change.
  const bundle = (slot: Slot) => {
    const chain = opChain(data);
    const ensure = (itemId: string, attrs?: Entry["attrs"]) => {
      const ensured = ensureOp(chain.data, slot.id, itemId, attrs);
      ensured.ops.forEach(chain.apply);
      return ensured.id;
    };
    const access = ensure(PRISMA_SASE.access);
    const sdwan = ensure(PRISMA_SASE.sdwan, { group: access });
    if (chain.data.entries.find((e) => e.id === sdwan)?.attrs.group !== access)
      chain.apply(setAttrOp(chain.data, sdwan, "group", access));
    const op = chain.op();
    if (op) commit(op);
  };

  // A template concern left with nothing recorded goes, so the board holds nothing from it.
  const concernOp = (from: BoardData, slot: Slot, entry: Entry, attrs: Entry["attrs"]) =>
    !Object.keys(attrs).length && !entry.note && slot.presets.includes(entry.itemId ?? "")
      ? removeOp(from, entry.id)
      : updateOp([entry], entry.status === "live" ? { attrs } : { attrs, status: "live" });
  const setConcern = (slot: Slot, entry: Entry, attrs: Entry["attrs"]) => commit(concernOp(data, slot, entry, attrs));

  // A template concern the SE hasn't touched has no entry yet, only its item.
  const concern = (slot: Slot, target: Entry | string) =>
    typeof target === "string" ? find(slot, (e) => e.itemId === target) : target;

  const actions: CockpitActions = {
    // Picking what's already there brings it back rather than taking it away. On Concerns it selects the concern's row, in
    // its group, which a template concern has without an entry, so picking one commits nothing.
    pick(slot, itemId, toggle = false) {
      if (board?.template.layout === "hub-and-spoke" && itemId === PRISMA_SASE.id) return bundle(slot);
      const existing = find(slot, (e) => e.itemId === itemId && e.status !== "dismissed");
      if (board?.template.layout === "ranked-list") {
        showGroup(catalogById.get(itemId)?.category);
        if (existing) bringBack(existing);
        return setSelection(
          !existing && slot.presets.includes(itemId)
            ? { slot: slot.id, itemId }
            : { slot: slot.id, entryId: existing?.id ?? add(slot, { itemId }) },
        );
      }
      if (!existing || slot.repeats) add(slot, { itemId });
      else if (toggle && existing.status === "live") commit(removeEntryOp(board!.template, data, existing.id));
      else bringBack(existing);
    },
    dismiss(slot, itemId) {
      commit(addOp(data, { id: crypto.randomUUID(), slot: slot.id, itemId, status: "dismissed" }));
    },
    addText(slot, text) {
      const existing = find(slot, (e) => e.text?.toLowerCase() === text.toLowerCase());
      if (existing) bringBack(existing);
      const entryId = existing?.id ?? add(slot, { text });
      if (board?.template.layout !== "ranked-list") return;
      if (existing) showGroup(existing.attrs.group);
      setSelection({ slot: slot.id, entryId });
    },
    remove(slot, entry) {
      commit(removeEntryOp(board!.template, data, entry.id));
      setSelection({ slot: slot.id });
    },
    confirm: (entry) => commit(updateOp([entry], { status: "live" })),
    note: (entry, note) => commit(updateOp([entry], { note })),
    rename: (entry, text) => commit(updateOp([entry], entry.status === "live" ? { text } : { text, status: "live" })),
    // Moving swaps places with the neighbour, as one undoable change. A live entry's
    // neighbour is the nearest live one, so the room sees every move.
    move(slot, entry, by) {
      const list = entriesIn(data, slot.id).filter((e) =>
        entry.status === "live" ? e.status === "live" : e.status !== "dismissed",
      );
      const other = list[list.findIndex((e) => e.id === entry.id) + by];
      if (other)
        commit({
          type: "batch",
          ops: [updateOp([entry], { position: other.position }), updateOp([other], { position: entry.position })] as SingleOp[],
        });
    },
    // Editing a ghost puts it back in the room.
    setAttrs: (entry, attrs) => commit(updateOp([entry], entry.status === "live" ? { attrs } : { attrs, status: "live" })),
    cycleMark(entry) {
      const { mark, ...rest } = entry.attrs;
      const next = MARKS[MARKS.indexOf(mark as Mark) + 1];
      actions.setAttrs(entry, next ? { ...rest, mark: next } : rest);
    },
    // Removing the zoom keeps its fields, so adding it back restores them.
    zoom(entry) {
      const { zoom, ...rest } = entry.attrs;
      actions.setAttrs(entry, zoom ? rest : { ...rest, zoom: true });
    },
    // Picking a level on a ghost puts it back in the room, and tapping its own level brings it back as it was.
    level(slot, target, level) {
      const entry = concern(slot, target);
      if (!entry) return add(slot, { itemId: target as string, attrs: { level } });
      setConcern(slot, entry, entry.status !== "live" && entry.attrs.level === level ? entry.attrs : levelAttrs(entry.attrs, level));
    },
    // Several attributes at once, as one undoable change. Editing a ghost
    // in the tray puts it back in the room, but not the ghosts a move reorders around it.
    setFields(slot, changes) {
      let next = data;
      const ops = changes.map(([entryId, key, value]) => {
        const op = setAttrOp(next, entryId, key, value);
        next = applyOp(next, op);
        return op;
      });
      const ghost = data.entries.find((e) => e.id === selection?.entryId && e.status === "ghost");
      if (ghost) ops.push(updateOp([ghost], { status: "live" }));
      commit(ops.length === 1 ? ops[0] : { type: "batch", ops: ops as SingleOp[] });
    },
    // The server checks the entry, so it waits for the entry's commits to land.
    async suggest(entry, suggestion) {
      await drained(DRAIN_MS);
      const ok = await suggestAction(customer.id, { entryId: entry.id, ...suggestion }).catch(() => false);
      if (ok) setSuggested((s) => [...s, entry.id]);
      return ok;
    },
    // Attaching goes on the concern's own entry on Concerns, so it and the level it brings are one change there.
    attach(capability, concern) {
      const { id: boardId, slot } = concernsBoard!;
      const existing = entriesIn(concernsData, slot.id).find((e) =>
        "itemId" in concern ? e.itemId === concern.itemId : !e.itemId && e.text?.toLowerCase() === concern.text.toLowerCase(),
      );
      const routed = "itemId" in concern && props.lit!.items.some((i) => i.id === concern.itemId && i.routes.includes(capability));
      const attrs = (from: Entry["attrs"]) =>
        routed ? { ...from, level: Math.max(1, pickedLevel(from) ?? 0) } : attachAttrs(from, capability);
      const id = crypto.randomUUID();
      if (routed) routedAttach.set(id, capability);
      commit(
        existing
          ? updateOp([existing], { attrs: attrs(existing.attrs), status: "live" })
          : addOp(concernsData, {
              id: crypto.randomUUID(),
              slot: slot.id,
              ...concern,
              attrs: attrs("text" in concern ? { group: groupFor(capability, props.lit!.items, slot.categories) } : {}),
            }),
        { boardId, id },
      );
    },
    detach(capability, key) {
      const { id: boardId, slot } = concernsBoard!;
      const entry = entriesIn(concernsData, slot.id).find((e) => e.id === key || e.itemId === key)!;
      commit(concernOp(concernsData, slot, entry, detachAttrs(entry.attrs, capability)), { boardId });
    },
    // Null returns a capability to its concerns' level; 0 turns it off. Forcing a ghost puts it back in the room.
    force(slot, itemId, level) {
      const entry = find(slot, (e) => e.itemId === itemId);
      if (level === null) {
        if (entry) commit(removeOp(data, entry.id));
      } else if (!entry) add(slot, { itemId, attrs: { level } });
      else actions.setAttrs(entry, { level });
    },
  };

  // A Concerns board still awaiting its return-visit choice lights nothing here, and takes no attachments.
  const attachable = !!concernsBoard && !pending.includes(concernsBoard.id);
  const lit = useMemo(
    () =>
      props.lit && {
        ...props.lit,
        implied: attachable ? props.lit.implied : [],
        concerns: [
          ...props.lit.concerns,
          ...(attachable ? entriesIn(concernsData, concernsBoard!.slot.id).filter((e) => e.status === "live") : []),
        ],
      },
    [props.lit, attachable, concernsData, concernsBoard],
  );

  const template = board?.template;
  const previewed = props.rail
    .flatMap((c) => c.boards)
    .find((b) => b.id === preview && (b.id !== template?.id || zoomed))?.template;
  const selectedSlot = template?.slots.find((s) => s.id === selection?.slot);
  // A slot that shares another's tray opens that tray, unless one of its own entries is selected.
  const traySlot =
    selectedSlot?.tray && !selection?.entryId ? template?.slots.find((s) => s.id === selectedSlot.tray) : selectedSlot;
  const also = template?.slots.filter((s) => s.tray === traySlot?.id) ?? [];
  const flowing = !!traySlot && traySlot.id === flows;
  const editorProps = { data, selection, label, name, onSelect: setSelection, onAdd: openAdd, actions };
  const flowContext: FlowContext | null =
    template?.layout === "hub-and-spoke" && summary
      ? {
          template,
          view: summary.view,
          data,
          catalog: props.catalog,
          onStep(flowId: string | null, step: Step) {
            const { op, id } = stepOp(template, data, lookup, flowId, step);
            if (op) commit(op);
            if (!flowId) setSelection({ slot: flows!, entryId: id });
          },
        }
      : null;
  const picked =
    flowContext && selection?.slot === flows ? flowsAt(flowContext.template, data).find((f) => f.id === selection?.entryId) : undefined;
  // A grouped Prisma SASE pair holds Prisma SASE, so a suggestion of it goes once accepted.
  const sase = data.entries.find((e) => e.id === summary?.view.nodes.find((n) => n.group)?.id);
  const suggestedFor = (slot: Slot) =>
    suggestions(
      { templateId: template!.id, slot },
      props.placed,
      [
        ...data.entries,
        ...(sase ? [{ itemId: PRISMA_SASE.id, slot: sase.slot }] : []),
      ],
    );
  // A slot that accepts every category gets no suggestions, so its chips lead with what the customer named on
  // other boards in the categories its board names, such as App tiers' apps heard on the AI board.
  const chipsFor = (slot: Slot) => {
    if (slot.categories.length) return slot.presets;
    const offered = boardCategories(template!);
    return [...new Set([...props.placed.filter((p) => offered.includes(p.category)).map((p) => p.itemId), ...slot.presets])];
  };
  // The SE sees one group of a board in groups, so Clear empties only that.
  const clearing = clearOp(data, (e) =>
    concerns
      ? (concerns[pane] ?? concerns[0]).rows.some((r) => r.entry?.id === e.id)
      : template?.layout !== "grid" || !template.groups || gridRows(template, pane).flat().includes(e.slot),
  );

  return (
    <div
      className="flex h-screen flex-col"
      // The room's accent, held to at most 60% lightness so changes read on the cockpit's white.
      style={{ "--customer": `oklch(from ${accentOrDefault(customer.accent)} min(l, 0.6) c h)` } as React.CSSProperties}
    >
      <TopBar
        customer={customer}
        clusterOptions={props.clusterOptions}
        template={template ?? null}
        zoom={
          roomZoom &&
          // The "+N more" zoom exports as its diagram's second pane.
          (roomZoom.entryId
            ? { template: roomZoom.template, entry: zoomEntry && { id: zoomEntry.id, name: label(zoomEntry) } }
            : { template: template!, entry: { name: "more" } })
        }
        meeting={meeting}
        diagrams={
          props.diagrams && (
            <DiagramPicker
              customerId={customer.id}
              templateId={template!.id}
              diagrams={diagrams}
              current={props.diagrams.current.id}
              offline={disconnected}
              drained={() => drained(DRAIN_MS)}
              onFailed={() => setUnreachable(true)}
              onCommit={commit}
            />
          )
        }
        diagram={current}
        pane={roomPane}
        litGroup={litGroup?.name}
        flow={layout === "hub-and-spoke" ? focus : null}
        groups={picker}
        held={held}
        notesOpen={!!notesOpen}
        offline={disconnected}
        canUndo={stacks.undo.length > 0}
        canRedo={stacks.redo.length > 0}
        onClear={
          board && !zoomed && !props.lit?.zoomed && clearing.entries.length
            ? () => {
                setSelection(null);
                void commit(clearing);
              }
            : undefined
        }
        onStart={reaching(async () => {
          const started = await startMeetingAction(customer.id);
          setPending(started.pending);
          setLog([]);
          setMeeting({ id: started.meeting.id, code: started.meeting.code!, held, pane });
        })}
        onEnd={reaching(async () => {
          await drained(DRAIN_MS);
          const ended = await endMeetingAction(customer.id, Intl.DateTimeFormat().resolvedOptions().timeZone);
          setMeeting(null);
          setPending([]);
          setLog([]);
          if (ended) setNotesOpen({ meetingId: ended });
        })}
        onPane={showPane}
        onHold={() => setHeld((h) => !h)}
        onNotes={() => setNotesOpen(notesOpen ? null : { meetingId: null })}
        onUndo={undo}
        onRedo={redo}
      />
      <div className="flex min-h-0 flex-1">
        <Rail
          sections={props.rail}
          active={template?.id}
          activeFilled={data.entries.some((e) => e.status !== "dismissed")}
          zooms={zooms}
          zoomed={props.lit?.zoomed ?? (zoomed ? (zoomed.entryId ?? "more") : null)}
          diagram={props.diagrams?.current.id}
          offline={disconnected}
          onPreview={(id) => {
            select(null);
            setPreview((p) => (p === id ? null : id));
          }}
        />
        <main
          className="min-w-0 flex-1 overflow-auto p-6"
          // A click on the board's background, outside every item and control, lets the selection go. Menus portalled
          // out of the board still bubble here, so only clicks within it count.
          onClick={(e) => {
            const target = e.target as Element;
            if (e.currentTarget.contains(target) && !target.closest("a, button, input, li, section")) select(null);
          }}
        >
          {template?.layout === "grid" && !zoomed && (
            <GridEditor
              {...editorProps}
              template={template}
              rows={gridRows(template, pane)}
              suggested={suggestedFor}
              lookup={lookup}
              zoomHref={zoomHref}
            />
          )}
          {template?.layout === "ranked-list" && concerns && (
            <RankedEditor {...editorProps} template={template} rows={(concerns[pane] ?? concerns[0]).rows} />
          )}
          {template?.layout === "lit-map" && lit && (
            <LitMapEditor
              template={template}
              data={data}
              lit={lit}
              attachable={attachable}
              zoomHref={zoomHref}
              selected={selection?.itemId}
              onSelect={(itemId) => setSelection(itemId ? { slot: template.slots[0].id, itemId } : null)}
              actions={actions}
            />
          )}
          {template?.layout === "list" && <ListEditor {...editorProps} template={template} />}
          {template && zoomed && (
            <ZoomEditor
              template={template}
              zoom={zoomed}
              data={data}
              diagram={diagram}
              lookup={lookup}
              selected={selection?.entryId}
              zoomHref={zoomHref}
              actions={actions}
              onSelect={(id) => {
                const entry = data.entries.find((e) => e.id === id);
                if (entry?.status === "ghost") actions.confirm(entry);
                else setSelection(entry ? { slot: entry.slot, entryId: entry.id } : null);
              }}
            />
          )}
          {template?.layout === "hub-and-spoke" && !zoomed && summary && (
            <SummaryEditor
              {...editorProps}
              template={template}
              summary={summary}
              suggested={suggestedFor}
              zoomHref={zoomHref}
              architectures={props.architectures}
              onArchitecture={(a) => {
                const op = presetOps(data, a);
                if (op) commit(op);
              }}
              flow={picked ? flowPath(summary.view, picked) : null}
            />
          )}
        </main>
        {previewed && (
          <PreviewPanel
            customer={customer}
            template={previewed}
            diagram={previewed.id === template?.id ? current : undefined}
            synced={synced}
            online={online}
            narrow={!!notesOpen}
            onClose={() => setPreview(null)}
          />
        )}
        {board && traySlot && template?.layout !== "lit-map" && !selection?.itemId && (
          <Tray
            key={traySlot.id}
            slot={traySlot}
            also={also}
            chips={template?.layout === "ranked-list" ? null : flowing ? [] : chipsFor(traySlot)}
            named={flowing}
            list={
              flowing ? (
                <FlowList
                  context={flowContext!}
                  entries={entriesIn(data, traySlot.id).filter((e) => e.status !== "dismissed")}
                  // A ghost flow comes back with the ghosts on its path, whose lines come with them, so the room lights it.
                  onOpen={(entry) => {
                    const flow = flowsAt(flowContext!.template, data).find((f) => f.id === entry.id);
                    const path = [entry.id, flow?.who, flow?.through, flow?.where];
                    const ghosts = data.entries.filter((e) => e.status === "ghost" && path.includes(e.id));
                    if (ghosts.length) commit(updateOp(ghosts, { status: "live" }));
                    setSelection({ slot: traySlot.id, entryId: entry.id });
                  }}
                />
              ) : undefined
            }
            extra={
              flowing
                ? (entry) => {
                    const flow = flowsAt(flowContext!.template, data).find((f) => f.id === entry.id);
                    return flow && <FlowSteps context={flowContext!} flow={flow} />;
                  }
                : traySlot.attributes.length
                  ? (entry) => {
                      // Fields edited on a zoom on request would show nowhere until it's added.
                      if (traySlot.zoomOnRequest && entry.attrs.zoom !== true) return null;
                      const node = summary?.view.nodes.find((n) => n.id === entry.id);
                      // The attributes a template ties to a part of its zoom are an AI app's; the tray offers an app only its kind's.
                      const fieldsSlot = traySlot.attributes.some((a) => a.at)
                        ? { ...traySlot, attributes: appAttributes(traySlot, entry, appKind(entry, lookup)) }
                        : traySlot;
                      return (
                        <>
                          {summary && node && !zoomed && (
                            <PlacementControls
                              node={node}
                              summary={summary}
                              onSet={(changes) => actions.setFields(traySlot, changes)}
                              onHub={(hub) => commit(hubOp(data, summary.view.nodes, node.id, hub))}
                            />
                          )}
                          <FieldsEditor
                            key={entry.id}
                            slot={fieldsSlot}
                            entry={entry}
                            catalog={props.catalog}
                            // An entry refers to itself only as a site group linking its own sites.
                            refs={(slots) =>
                              slots.flatMap((s) =>
                                entriesIn(data, s)
                                  .filter((e) => e.status !== "dismissed")
                                  .map((e) => ({ id: e.id, label: e.id === entry.id ? `Between ${label(e)}` : label(e) })),
                              )
                            }
                            connections={
                              summary
                                ? {
                                    types: (to) => {
                                      const from = summary.view.nodes.find((n) => n.id === entry.id);
                                      const target = to === null ? null : summary.view.nodes.find((n) => n.id === to);
                                      return from && (to === null || target) ? connectionTypes(from, target ?? null) : [];
                                    },
                                    fields: connectionFields,
                                  }
                                : undefined
                            }
                            onSet={(key, value) => actions.setFields(traySlot, [[entry.id, key, value]])}
                          />
                        </>
                      );
                    }
                  : undefined
            }
            entries={[traySlot, ...also].flatMap((s) => entriesIn(data, s.id))}
            entryId={selection?.entryId}
            // A suggestion can't carry the capabilities a concern routes to, so concerns aren't suggested; nor is a flow's name.
            categories={
              template?.layout === "ranked-list" || flowing
                ? []
                : (traySlot.categories.length ? traySlot.categories : boardCategories(board.template)).flatMap((id) =>
                    props.categories.filter((c) => c.id === id),
                  )
            }
            suggested={suggested}
            catalog={props.catalog}
            label={label}
            search={search}
            actions={actions}
            onSelect={setSelection}
            onClose={() => setSelection(null)}
          />
        )}
        {notesOpen && (
          <NotesPanel
            key={notesOpen.meetingId}
            customer={customer}
            meetingId={notesOpen.meetingId}
            running={meeting?.id ?? null}
            synced={synced}
            viewed={viewed}
            offline={disconnected}
            queued={queued}
            onClose={() => setNotesOpen(null)}
          />
        )}
      </div>
      {meeting && board && pending.includes(board.id) && (
        <ReturnVisit
          onChoose={(choice) => {
            setPending((p) => p.filter((id) => id !== board.id));
            if (choice === "live") return;
            const op = visitOp(data, choice);
            // What the selection names is a ghost now, or gone.
            select(null);
            setSettling((s) => [...s, board.id]);
            void commit(op).then(() => setSettling((s) => s.filter((id) => id !== board.id)));
          }}
        />
      )}
    </div>
  );
}

export type CockpitActions = {
  pick(slot: Slot, itemId: string, toggle?: boolean): void;
  dismiss(slot: Slot, itemId: string): void;
  addText(slot: Slot, text: string): void;
  remove(slot: Slot, entry: Entry): void;
  confirm(entry: Entry): void;
  note(entry: Entry, note: string | null): void;
  rename(entry: Entry, text: string): void;
  move(slot: Slot, entry: Entry, by: -1 | 1): void;
  setAttrs(entry: Entry, attrs: Entry["attrs"]): void;
  cycleMark(entry: Entry): void;
  zoom(entry: Entry): void;
  level(slot: Slot, target: Entry | string, level: number): void;
  setFields(slot: Slot, changes: [entryId: string, key: string, value: unknown][]): void;
  suggest(entry: Entry, suggestion: { name: string; category: string; aliases: string[] }): Promise<boolean>;
  force(slot: Slot, itemId: string, level: number | null): void;
  attach(capability: string, concern: { itemId: string } | { text: string }): void;
  // The concern by its key on the lit map.
  detach(capability: string, key: string): void;
};

export type EditorProps = {
  data: BoardData;
  selection: Selection | null;
  label: (e: Entry) => string;
  name: (itemId: string) => string;
  onSelect: (selection: Selection | null) => void;
  // Opens a slot's tray with its type-ahead focused.
  onAdd: (slot: string) => void;
  actions: CockpitActions;
};
