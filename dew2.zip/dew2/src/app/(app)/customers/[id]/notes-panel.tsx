"use client";

import {
  IconCheck,
  IconChevronLeft,
  IconChevronRight,
  IconCloudOff,
  IconCloudUpload,
  IconCopy,
  IconFileX,
  IconFileZip,
  IconJson,
  IconLoader2,
  IconMarkdown,
  IconNotesOff,
  IconPointFilled,
  IconRefresh,
  IconX,
} from "@tabler/icons-react";
import { type Zippable, strToU8, zipSync } from "fflate";
import { unstable_rethrow } from "next/navigation";
import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import type { Commit } from "@/board/model";
import type { MeetingNotes, PackBoard } from "@/notes/data";
import { type NotesData, entryDetails } from "@/notes/notes";
import { Button } from "@/components/ui/button";
import { useBriefly } from "@/components/use-briefly";
import type { CockpitCustomer } from "./cockpit";
import { fileName, renderPng, saveFile } from "./export";
import { regenerateNotesAction, saveMemoAction } from "./meeting-actions";

type Notes = { meetings: { id: string; startedAt: string }[]; notes: MeetingNotes | null };
type Open = { meetingId: string | null };

const timeZone = () => Intl.DateTimeFormat().resolvedOptions().timeZone;

// Moving to another board remounts the cockpit, so the notes stay open per customer on the meeting they show, with what they
// last read to show while they read it again.
const panels = new Map<string, Open & { read: Notes | null }>();

// Whether the notes are open, on a meeting, or with none named on the latest.
export function useNotesPanel(customerId: string) {
  const [open, setOpen] = useState<Open | null>(() => panels.get(customerId) ?? null);
  const set = useCallback(
    (next: Open | null) => {
      if (next) panels.set(customerId, { ...next, read: null });
      else panels.delete(customerId);
      setOpen(next);
    },
    [customerId],
  );
  return [open, set] as const;
}

// Leaving the memo box saves it, so a download waits for that save to carry what was just typed.
const memoSaves = new Map<string, Promise<MeetingNotes | null>>();
const latest = async (shown: MeetingNotes) => (await memoSaves.get(shown.meetingId)) ?? shown;

// The meeting's notes and the room's image of every board it touched, in one zip.
async function pack(customer: CockpitCustomer, notes: MeetingNotes, onProgress: (done: number, of: number) => void) {
  const response = await fetch(`/api/customers/${customer.id}/notes/${notes.meetingId}/boards`);
  if (!response.ok) throw new Error(`Boards not available: ${response.status}`);
  const { boards } = (await response.json()) as { boards: PackBoard[] };
  const files: Zippable = { "notes.md": strToU8(notes.markdown), "notes.json": strToU8(JSON.stringify(notes.data, null, 2)) };
  for (const [i, board] of boards.entries()) {
    onProgress(i, boards.length);
    const png = new Uint8Array(await (await renderPng(board.view, customer)).arrayBuffer());
    // A PNG is compressed already.
    files[`${fileName(String(i + 1).padStart(2, "0"), board.name)}.png`] = [png, { level: 0 }];
  }
  saveFile(`${fileName(notes.data.customer, notes.data.date)}.zip`, new Blob([zipSync(files)], { type: "application/zip" }));
}

// The notes of the customer's meetings, beside the board, which stays usable; the room never sees them. They open on the
// meeting asked for, else the latest, which while a meeting runs is that one, with its notes built so far.
export function NotesPanel(props: {
  customer: CockpitCustomer;
  meetingId: string | null;
  // The meeting running, if any, whose notes follow its commits and the boards it shows as they land.
  running: string | null;
  synced: number;
  viewed: string | null;
  offline: boolean;
  queued: () => Commit[];
  onClose: () => void;
}) {
  const { customer, offline } = props;
  const [shown, setShown] = useState(props.meetingId);
  // They turn to a meeting started while they're open, but keep the one stepped to when the cockpit remounts.
  const [running, setRunning] = useState(props.running);
  if (props.running !== running) {
    setRunning(props.running);
    if (props.running) setShown(props.running);
  }
  const [state, setState] = useState(() => panels.get(customer.id)?.read ?? null);
  useEffect(() => {
    panels.set(customer.id, { meetingId: shown, read: state });
  }, [customer.id, shown, state]);
  const [unreachable, setUnreachable] = useState(false);
  const notes = state?.notes ?? null;
  const live = notes?.running ? props.synced : 0;
  const viewed = notes?.running ? props.viewed : null;
  useEffect(() => {
    let current = true;
    // Commits land in bursts, so the live notes are fetched once they settle.
    const timer = setTimeout(() => {
      const query = new URLSearchParams({ tz: timeZone(), ...(shown && { meeting: shown }) });
      void Promise.all(memoSaves.values())
        .then(() => fetch(`/api/customers/${customer.id}/notes?${query}`))
        .then((r) => {
          if (!r.ok) throw new Error(`Notes not available: ${r.status}`);
          return r.json() as Promise<Notes>;
        })
        .then(
          (next) => {
            if (!current) return;
            setState(next);
            setUnreachable(false);
          },
          () => current && setUnreachable(true),
        );
    }, 250);
    return () => {
      current = false;
      clearTimeout(timer);
    };
  }, [customer.id, shown, live, viewed, props.running, offline]);

  const replace = useCallback(
    (fresh: MeetingNotes | null) => fresh && setState((s) => (s?.notes?.meetingId === fresh.meetingId ? { ...s, notes: fresh } : s)),
    [],
  );
  const { queued } = props;
  const queuedFor = useCallback((meetingId: string) => queued().some((c) => c.meetingId === meetingId), [queued]);
  // An ended meeting whose notes lack changes it queued, until notes regenerated once they all landed arrive.
  const [behind, setBehind] = useState<string | null>(null);
  const [regenerating, startRegenerating] = useTransition();
  const regenerate = useCallback(
    (meetingId: string) =>
      startRegenerating(async () => {
        const landed = !queuedFor(meetingId);
        try {
          replace(await regenerateNotesAction({ customerId: customer.id, meetingId, timeZone: timeZone() }));
        } catch (error) {
          // Offline, the notes stay as they are and Regenerate can be tapped again.
          unstable_rethrow(error);
        } finally {
          if (landed) setBehind((b) => (b === meetingId ? null : b));
        }
      }),
    [customer.id, replace, queuedFor],
  );

  // Known before its notes load when they open on a meeting, as at End, whose last commits may land while they load.
  const meetingId = notes?.meetingId ?? shown;
  const ended = !!meetingId && meetingId !== props.running;
  // A running meeting's own commits are only on their way while the cockpit is offline; an ended one's always are.
  const onTheirWay = !!meetingId && (ended || offline) && queuedFor(meetingId);
  if (onTheirWay && ended && behind !== meetingId) setBehind(meetingId);
  const waiting = onTheirWay || (!!meetingId && behind === meetingId);
  // Once its commits have landed, and after its notes are read while they're the ones shown, so the read can't land over
  // the regenerated notes. The panel may have turned to a meeting started since.
  const due = !!behind && !queuedFor(behind) && (behind !== meetingId || notes?.meetingId === behind);
  useEffect(() => {
    if (behind && due && !regenerating) regenerate(behind);
  }, [behind, due, regenerating, regenerate]);

  const saveMemo = useCallback(
    async (meetingId: string, memo: string) => {
      const saved = saveMemoAction({ customerId: customer.id, meetingId, memo, timeZone: timeZone() }).catch((error) => {
        unstable_rethrow(error);
        return null;
      });
      memoSaves.set(meetingId, saved);
      const fresh = await saved;
      if (memoSaves.get(meetingId) === saved) memoSaves.delete(meetingId);
      replace(fresh);
      return !!fresh;
    },
    [customer.id, replace],
  );

  const meetings = state?.meetings ?? [];
  const at = meetings.findIndex((m) => m.id === notes?.meetingId);
  const step = (by: number) => meetings[at + by] && setShown(meetings[at + by].id);
  const icon = (label: string, rest: Omit<React.ComponentProps<typeof Button>, "aria-label">) => (
    <Button variant="ghost" size="icon-sm" aria-label={label} title={label} {...rest} />
  );

  return (
    <aside aria-label="Notes" className="flex w-[min(24rem,22vw)] shrink-0 flex-col border-l">
      <header className="flex flex-wrap items-center gap-1 border-b p-2">
        {icon("Earlier meeting", { disabled: at < 0 || at === meetings.length - 1, onClick: () => step(1), children: <IconChevronLeft /> })}
        {notes && at >= 0 && (
          <span className="flex items-center gap-1 text-sm font-medium tabular-nums">
            {notes.running && <IconPointFilled className="size-4 text-red-600" aria-label="Running" />}
            <time dateTime={meetings[at].startedAt}>
              {new Date(meetings[at].startedAt).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
            </time>
          </span>
        )}
        {icon("Later meeting", { disabled: at <= 0, onClick: () => step(-1), children: <IconChevronRight /> })}
        <div className="ml-auto flex items-center gap-1">
          {waiting && <IconCloudUpload className="mr-1 size-4 text-amber-600" aria-label="Changes on their way" />}
          {unreachable && <IconCloudOff className="mr-1 size-4 text-amber-600" aria-label="Offline" />}
          {notes && (
            <>
              <CopyButton markdown={async () => (await latest(notes)).markdown} />
              {icon("Download Markdown", {
                onClick: async () => {
                  const { markdown, data } = await latest(notes);
                  saveFile(`${fileName(data.customer, data.date)}.md`, new Blob([markdown], { type: "text/markdown" }));
                },
                children: <IconMarkdown />,
              })}
              {icon("Download JSON", {
                onClick: async () => {
                  const { data } = await latest(notes);
                  saveFile(
                    `${fileName(data.customer, data.date)}.json`,
                    new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }),
                  );
                },
                children: <IconJson />,
              })}
              {!notes.running &&
                icon("Regenerate", { disabled: regenerating, onClick: () => regenerate(notes.meetingId), children: <IconRefresh /> })}
              <PackButton key={notes.meetingId} customer={customer} notes={() => latest(notes)} />
            </>
          )}
          {icon("Close notes", { onClick: props.onClose, children: <IconX /> })}
        </div>
      </header>
      <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto p-4">
        {notes ? (
          <>
            <MemoBox
              key={notes.meetingId}
              meetingId={notes.meetingId}
              initial={notes.data.memo ?? ""}
              offline={offline}
              save={(memo) => saveMemo(notes.meetingId, memo)}
            />
            <NotesBody data={notes.data} />
          </>
        ) : state ? (
          <IconNotesOff className="m-auto size-8 text-muted-foreground" aria-label="No meetings yet" />
        ) : (
          !unreachable && <IconLoader2 className="m-auto size-6 animate-spin text-muted-foreground" aria-label="Loading" />
        )}
      </div>
    </aside>
  );
}

// The boards as the notes list them, in the cockpit's own type; copying and downloading give the Markdown.
function NotesBody({ data }: { data: NotesData }) {
  return data.boards.map((board, b) => {
    const filled = board.sections.filter((s) => s.entries.length);
    return (
      filled.length > 0 && (
        <section key={b} className="flex flex-col gap-2 text-sm">
          <h3 className="font-semibold">{board.name}</h3>
          {filled.map((section, s) => (
            <div key={s} className="flex flex-col gap-1">
              {/* A board of one list needs no heading for it. */}
              {board.sections.length > 1 && <h4 className="text-xs font-medium text-muted-foreground">{section.name}</h4>}
              <ul className="flex flex-col gap-1.5">
                {section.entries.map((e, i) => (
                  <li key={i}>
                    {[e.label, ...entryDetails(board.layout, e.attrs, data.date)].join(" · ")}
                    {e.fields?.map((f) => (
                      <p key={f.name} className="text-xs text-muted-foreground">
                        {f.name}: {f.value}
                      </p>
                    ))}
                    {e.note && (
                      <blockquote className="mt-0.5 border-l-2 pl-2 text-xs whitespace-pre-line text-muted-foreground italic">
                        {e.note}
                      </blockquote>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </section>
      )
    );
  });
}

// A promised blob keeps the click's permission to write while the memo's save settles, which Safari and Firefox insist on.
function CopyButton({ markdown }: { markdown: () => Promise<string> }) {
  const [copied, setCopied] = useBriefly(1500);
  return (
    <Button
      variant="ghost"
      size="icon-sm"
      aria-label="Copy"
      title="Copy"
      onClick={async () => {
        const text = markdown().then((m) => new Blob([m], { type: "text/plain" }));
        await navigator.clipboard.write([new ClipboardItem({ "text/plain": text })]);
        setCopied(true);
      }}
    >
      {copied ? <IconCheck /> : <IconCopy />}
    </Button>
  );
}

function PackButton({ customer, notes }: { customer: CockpitCustomer; notes: () => Promise<MeetingNotes> }) {
  const [progress, setProgress] = useState<string | null>(null);
  const [failed, setFailed] = useState<string | null>(null);
  const run = async () => {
    setFailed(null);
    setProgress("Packing");
    try {
      await pack(customer, await notes(), (done, of) => setProgress(`Packing ${done + 1} of ${of}`));
    } catch (error) {
      setFailed(`Pack failed: ${error instanceof Error ? error.message : error}`);
    } finally {
      setProgress(null);
    }
  };
  const label = progress ?? failed ?? "Download meeting pack";
  return (
    <Button variant="ghost" size="icon-sm" aria-label={label} title={label} disabled={!!progress} onClick={() => void run()}>
      {progress ? <IconLoader2 className="animate-spin" /> : failed ? <IconFileX className="text-destructive" /> : <IconFileZip />}
    </Button>
  );
}

// The memo as the SE last typed it in this tab, by meeting, and whether it still has to be saved. Moving to another board
// remounts the box, which picks it up from here rather than from notes read before its save landed. Unsaved text also
// waits in localStorage until it is saved, so a reload or a closed tab doesn't lose it.
const memos = new Map<string, { text: string; unsaved: boolean }>();
const memoKey = (meetingId: string) => `dew2:memo:${meetingId}`;

function memoOf(meetingId: string) {
  try {
    const stored = memos.has(meetingId) ? null : localStorage.getItem(memoKey(meetingId));
    if (stored !== null) memos.set(meetingId, { text: stored, unsaved: true });
  } catch {}
  return memos.get(meetingId);
}

function keepUnsaved(meetingId: string, text: string | null) {
  try {
    if (text === null) localStorage.removeItem(memoKey(meetingId));
    else localStorage.setItem(memoKey(meetingId), text);
  } catch {}
}

// What the SE jots about the meeting. It is saved on leaving the box, on closing the notes or leaving the board, and,
// if that failed offline or the page went first, once back online or when the box shows again.
function MemoBox(props: { meetingId: string; initial: string; offline: boolean; save: (memo: string) => Promise<boolean> }) {
  const { meetingId } = props;
  const [text, setText] = useState(() => memoOf(meetingId)?.text ?? props.initial);
  const [failed, setFailed] = useState(() => !!memoOf(meetingId)?.unsaved);
  const saveRef = useRef(props.save);
  useEffect(() => {
    saveRef.current = props.save;
  });
  const flush = useCallback(async () => {
    const memo = memoOf(meetingId);
    if (!memo?.unsaved) return;
    memos.set(meetingId, { ...memo, unsaved: false });
    const ok = await saveRef.current(memo.text);
    if (memos.get(meetingId)?.text === memo.text) {
      if (ok) keepUnsaved(meetingId, null);
      else memos.set(meetingId, memo);
    }
    setFailed(!ok);
  }, [meetingId]);
  useEffect(() => {
    if (!props.offline) void flush();
  }, [props.offline, flush]);
  useEffect(() => () => void flush(), [flush]);
  return (
    <div className="relative">
      <textarea
        aria-label="Your notes"
        placeholder="Your notes"
        maxLength={20_000}
        rows={4}
        value={text}
        onChange={(e) => {
          memos.set(meetingId, { text: e.target.value, unsaved: true });
          keepUnsaved(meetingId, e.target.value);
          setText(e.target.value);
        }}
        onBlur={() => void flush()}
        className="w-full rounded-lg border bg-transparent p-2 text-sm outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
      />
      {failed && <IconCloudOff className="absolute top-2 right-2 size-4 text-amber-600" aria-label="Not saved" />}
    </div>
  );
}
