"use client";

import { IconCloudOff, IconX } from "@tabler/icons-react";
import { cn } from "cn";
import { useEffect, useState } from "react";
import type { BoardView } from "@/board/view";
import type { BoardTemplate } from "@/content/schema";
import { Button } from "@/components/ui/button";
import { RoomCanvas } from "@/app/present/room-canvas";
import { RoomView } from "@/app/present/room-view";
import type { CockpitCustomer } from "./cockpit";
import { ExportButton, viewUrl } from "./export";

// Another board as the room would show it. It never moves the room.
export function PreviewPanel(props: {
  customer: CockpitCustomer;
  template: BoardTemplate;
  // The overview's diagram the cockpit is on, when this is a preview of it from one of its zooms.
  diagram?: { id: string; name: string };
  // Changes as commits land, so the preview follows them.
  synced: number;
  // A preview that failed offline fills in when the connection returns.
  online: boolean;
  // Beside the notes, so the board keeps room between them.
  narrow: boolean;
  onClose: () => void;
}) {
  const { customer, template } = props;
  const [board, setBoard] = useState<BoardView | null>(null);
  const [failed, setFailed] = useState(false);
  const url = viewUrl(customer.id, template.id, { pane: 0 }, { diagramId: props.diagram?.id });
  useEffect(() => {
    let current = true;
    void fetch(url)
      .then((r) => (r.ok ? r.json() : null))
      .then(
        (view) => {
          if (!current) return;
          setBoard(view);
          setFailed(false);
        },
        () => current && setFailed(true),
      );
    return () => {
      current = false;
    };
  }, [url, props.synced, props.online]);

  return (
    <aside
      aria-label={`Preview of ${template.name}`}
      className={cn("flex shrink-0 flex-col border-l", props.narrow ? "w-[min(28rem,25vw)]" : "w-[min(45vw,56rem)]")}
    >
      <header className="flex items-center gap-1 p-2 pl-4">
        <h2 className="flex-1 truncate font-medium">{template.name}</h2>
        {failed && <IconCloudOff className="size-4 text-amber-600" aria-label="Offline" />}
        <ExportButton
          customer={customer}
          template={template}
          {...(props.diagram ? { diagram: props.diagram } : { entry: board && "name" in board ? { name: board.name } : undefined })}
        />
        <Button variant="ghost" size="icon-sm" aria-label="Close" onClick={props.onClose}>
          <IconX />
        </Button>
      </header>
      <RoomCanvas accent={customer.accent} className="aspect-video w-full">
        {board && <RoomView board={board} logoUrl={customer.logoUrl} />}
      </RoomCanvas>
    </aside>
  );
}
