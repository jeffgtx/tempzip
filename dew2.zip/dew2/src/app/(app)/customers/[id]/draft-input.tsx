"use client";

import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";

// Keeps typing local and commits on blur or Enter, so the room never sees a half-typed value.
// Callers key it on the committed value, so an undo shows at once, and a commit the caller
// turns down, such as clearing a required field, shows the value again.
export function DraftInput({
  value,
  onCommit,
  ...props
}: { value: string; onCommit: (value: string) => void } & Omit<React.ComponentProps<typeof Input>, "value" | "onChange">) {
  const [draft, setDraft] = useState(value);
  // A reload or a closed tab doesn't blur the field. The commit queue keeps what the page commits as it goes.
  useEffect(() => {
    const save = () => {
      if (draft !== value) onCommit(draft);
    };
    window.addEventListener("pagehide", save);
    return () => window.removeEventListener("pagehide", save);
  });
  return (
    <Input
      {...props}
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        if (draft !== value) onCommit(draft);
        setDraft(value);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") e.currentTarget.blur();
      }}
    />
  );
}
