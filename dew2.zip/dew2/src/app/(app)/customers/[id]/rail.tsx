import { IconDots, IconEye, IconGhost } from "@tabler/icons-react";
import { cn } from "cn";
import Link from "next/link";
import type { BoardTemplate } from "@/content/schema";
import { NodeIcon } from "@/components/node-icon";
import { Button } from "@/components/ui/button";

// filled leaves out the board shown, whose dot follows the cockpit's live entries; another diagram can still fill it.
export type RailSection = { id: string; name: string | null; boards: { id: string; template: BoardTemplate; filled: boolean }[] };
// A zoom the active board opens: an entry's, or the "+N more" one, keyed `more`. A quiet one's entry is a ghost.
export type RailZoom = {
  key: string;
  name: string;
  icon: { category: string; itemId: string | null } | null;
  quiet: boolean;
  ghost?: boolean;
};

// Offline, a link can't fetch its page and falls back to the browser's error page, which loses the cockpit.
export const offlineLink = (offline: boolean) =>
  offline ? { "aria-disabled": true, onClick: (e: React.MouseEvent) => e.preventDefault() } : {};

export function Rail({
  sections,
  active,
  activeFilled,
  zooms,
  zoomed,
  diagram,
  offline,
  onPreview,
}: {
  sections: RailSection[];
  active?: string;
  activeFilled: boolean;
  zooms: RailZoom[];
  zoomed: string | null;
  // The summary's diagram shown, which its own link and its zooms' links keep.
  diagram?: string;
  offline: boolean;
  onPreview: (id: string) => void;
}) {
  const section = (c: RailSection) => (
    <section key={c.id} className="mb-4 last:mb-0">
      {c.name && <h2 className="px-2 pb-1 text-xs font-medium text-muted-foreground">{c.name}</h2>}
      <ul>
        {c.boards.map((b) => {
          const filled = b.filled || (b.id === active && activeFilled);
          return (
            <li key={b.id} className="group relative">
              <Link
                href={`?board=${b.id}${b.id === active && diagram ? `&diagram=${diagram}` : ""}`}
                aria-current={b.id === active && !zoomed ? "page" : undefined}
                {...offlineLink(offline)}
                className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-muted aria-disabled:pointer-events-none aria-disabled:opacity-50 aria-[current=page]:bg-muted aria-[current=page]:font-medium"
              >
                <span
                  className={cn("size-2 shrink-0 rounded-full border border-foreground/40", filled && "bg-foreground/60")}
                />
                {b.template.name}
              </Link>
              {(b.id !== active || zoomed) && (
                <Button
                  variant="ghost"
                  size="icon-xs"
                  aria-label={`Preview ${b.template.name}`}
                  title="Preview"
                  onClick={() => onPreview(b.id)}
                  className="absolute top-1.5 right-1 opacity-0 group-hover:opacity-100 focus-visible:opacity-100"
                >
                  <IconEye />
                </Button>
              )}
              {b.id === active && zooms.length > 0 && (
                <ul aria-label={`${b.template.name} zooms`} className="ml-4">
                  {zooms.map((z) => (
                    <li key={z.key}>
                      <Link
                        href={`?board=${b.id}${diagram ? `&diagram=${diagram}` : ""}&zoom=${z.key}`}
                        aria-current={z.key === zoomed ? "page" : undefined}
                        {...offlineLink(offline)}
                        className={cn(
                          "flex items-center gap-2 rounded-md px-2 py-1 text-sm hover:bg-muted aria-disabled:pointer-events-none aria-disabled:opacity-50 aria-[current=page]:bg-muted aria-[current=page]:font-medium",
                          z.quiet && "opacity-50",
                        )}
                      >
                        {z.ghost ? (
                          <IconGhost className="size-4 shrink-0 text-muted-foreground" />
                        ) : z.icon ? (
                          <NodeIcon category={z.icon.category} itemId={z.icon.itemId} className="size-4 shrink-0 text-muted-foreground" />
                        ) : (
                          <IconDots className="size-4 shrink-0 text-muted-foreground" />
                        )}
                        <span className="truncate">{z.name}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
  return (
    <nav className="flex w-52 shrink-0 flex-col border-r">
      <div className="min-h-0 flex-1 overflow-y-auto p-3">{sections.filter((c) => c.name).map(section)}</div>
      <div className="border-t p-3">{sections.filter((c) => !c.name).map(section)}</div>
    </nav>
  );
}
