// What the SE has selected, in the customer's accent and clear of the item's edge, so it never reads as the accent an item
// carries on its own border or fill.
export const selectedClass = "outline-2 outline-offset-2 outline-solid outline-(--customer)";
