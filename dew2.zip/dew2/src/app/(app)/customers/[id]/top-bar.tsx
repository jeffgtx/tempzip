"use client";

import {
  IconArrowBackUp,
  IconArrowForwardUp,
  IconArrowLeft,
  IconCloudOff,
  IconEraser,
  IconExternalLink,
  IconEyeOff,
  IconNotes,
  IconPencil,
  IconPlayerPlay,
  IconPlayerStop,
} from "@tabler/icons-react";
import { cn } from "cn";
import Link from "next/link";
import { useEffect, useRef, useTransition } from "react";
import type { BoardTemplate } from "@/content/schema";
import { ConfirmButton } from "@/components/confirm-button";
import { Button } from "@/components/ui/button";
import type { ClusterOption } from "../cluster-chips";
import { CustomerDialog } from "../customer-dialog";
import { DeleteCustomerDialog } from "../delete-customer-dialog";
import type { CockpitCustomer } from "./cockpit";
import { ExportButton } from "./export";
import { offlineLink } from "./rail";

export function TopBar(props: {
  customer: CockpitCustomer;
  clusterOptions: ClusterOption[];
  template: BoardTemplate | null;
  // The zoom the room shows instead of the board, which exports instead of it.
  zoom: { template: BoardTemplate; entry?: { id?: string; name: string } } | null;
  meeting: { code: string } | null;
  // The summary's diagram picker, and the diagram shown, which exports under its name.
  diagrams?: React.ReactNode;
  diagram?: { id: string; name: string };
  // The pane the room shows.
  pane: number;
  // The lit map's group zoom the room shows, which exports instead of the map.
  litGroup?: string;
  // The flow picked on the summary, which exports lit.
  flow: string | null;
  // The groups of a ranked list or a grid, each with what its dot means when it has one.
  groups?: { name: string; mark: string | null; accent?: boolean }[];
  held: boolean;
  notesOpen: boolean;
  offline: boolean;
  canUndo: boolean;
  canRedo: boolean;
  // Absent where there's nothing to clear.
  onClear?: () => void;
  onStart: () => Promise<void>;
  onEnd: () => Promise<void>;
  onPane: (pane: number) => void;
  onHold: () => void;
  onNotes: () => void;
  onUndo: () => void;
  onRedo: () => void;
}) {
  const { customer, meeting, template } = props;
  const [pending, startTransition] = useTransition();
  const clear = props.groups ? "Clear the group" : "Clear the board";
  const icon = (label: string, rest: Omit<React.ComponentProps<typeof Button>, "aria-label">) => (
    <Button variant="ghost" size="icon" aria-label={label} title={label} {...rest} />
  );
  const link = (label: string, href: string, children: React.ReactNode) => (
    <Button asChild variant="ghost" size="icon" className="aria-disabled:pointer-events-none aria-disabled:opacity-50">
      <Link href={href} aria-label={label} title={label} {...offlineLink(props.offline)}>
        {children}
      </Link>
    </Button>
  );

  return (
    <header className="flex h-12 shrink-0 items-center gap-2 border-b px-2">
      {link("Customers", "/", <IconArrowLeft />)}
      {customer.logoUrl ? (
        // eslint-disable-next-line @next/next/no-img-element -- a data URL
        <img src={customer.logoUrl} alt="" className="h-6 max-w-16 object-contain" />
      ) : (
        <span className="size-3 shrink-0 rounded-full bg-(--customer)" />
      )}
      <h1 title={customer.name} className="max-w-1/4 truncate font-semibold">
        {customer.name}
      </h1>
      <CustomerDialog clusters={props.clusterOptions} customer={customer}>
        {icon("Edit customer", { children: <IconPencil /> })}
      </CustomerDialog>
      <DeleteCustomerDialog id={customer.id} name={customer.name} />

      {/* Only the picker gives way, so however many names it holds, every other control stays on the bar. */}
      <div className="flex min-w-0 flex-1 items-center justify-end gap-1">
        {props.offline && <IconCloudOff className="size-4 shrink-0 text-amber-600" aria-label="Offline" />}
        {props.groups ? (
          <Picker
            label="Group"
            value={props.pane}
            options={props.groups.map((g, i) => ({
              value: i,
              name: g.name,
              badge: g.mark && (
                <span
                  role="img"
                  aria-label={g.mark}
                  title={g.mark}
                  className={cn("size-1.5 shrink-0 rounded-full", g.accent ? "bg-(--customer) ring-1 ring-background" : "bg-current opacity-60")}
                />
              ),
            }))}
            onChange={props.onPane}
          />
        ) : (
          props.diagrams
        )}
      </div>
      <div className="flex items-center gap-1">
        {icon("Hold", {
          "aria-pressed": props.held,
          onClick: props.onHold,
          className: cn(props.held && "bg-amber-100 text-amber-900 hover:bg-amber-200"),
          children: <IconEyeOff />,
        })}
        {icon("Undo", { disabled: !props.canUndo, onClick: props.onUndo, children: <IconArrowBackUp /> })}
        {icon("Redo", { disabled: !props.canRedo, onClick: props.onRedo, children: <IconArrowForwardUp /> })}
        {props.onClear && (
          <ConfirmButton variant="ghost" size="icon" aria-label={clear} title={clear} onClick={props.onClear}>
            <IconEraser />
          </ConfirmButton>
        )}
        {template && (
          <ExportButton
            customer={customer}
            template={props.zoom?.template ?? template}
            pane={props.pane}
            focus={props.flow}
            diagram={props.diagram}
            entry={
              props.zoom?.entry ??
              (props.groups
                ? { name: (props.groups[props.pane] ?? props.groups[0]).name }
                : props.litGroup
                  ? { name: props.litGroup }
                  : undefined)
            }
          />
        )}
        {icon("Notes", { "aria-pressed": props.notesOpen, onClick: props.onNotes, children: <IconNotes /> })}
        {meeting ? (
          <>
            <span className="px-2 font-mono text-lg tracking-widest tabular-nums" aria-label="Join code">
              {meeting.code}
            </span>
            {icon("Open the room", {
              onClick: () => window.open(`/present?code=${meeting.code}`, "dew2-room"),
              children: <IconExternalLink />,
            })}
            <ConfirmButton
              variant="destructive"
              size="icon"
              aria-label="End meeting"
              title="End meeting"
              disabled={pending}
              onClick={() => startTransition(props.onEnd)}
            >
              <IconPlayerStop />
            </ConfirmButton>
          </>
        ) : (
          icon("Start meeting", {
            variant: "default",
            disabled: pending,
            onClick: () => startTransition(props.onStart),
            children: <IconPlayerPlay />,
          })
        )}
      </div>
    </header>
  );
}

// One of several, picked by name. Past a width a name truncates, and the names scroll sideways, keeping the one picked
// in view. Its children, such as a menu, stay put beside them.
export function Picker<T extends string | number>(props: {
  label: string;
  value: T;
  options: { value: T; name: string; badge?: React.ReactNode }[];
  disabled?: boolean;
  onChange: (value: T) => void;
  children?: React.ReactNode;
}) {
  const list = useRef<HTMLDivElement>(null);
  // Braced so the effect returns nothing: Chrome's scrollIntoView returns a promise, which React would call as cleanup.
  const reveal = () => {
    list.current?.querySelector("[aria-pressed=true]")?.scrollIntoView({ block: "nearest", inline: "nearest" });
  };
  // New names, after a move or on another board's groups, and a narrower list, as when Clear or the offline mark
  // appears beside it, can leave the picked one out of view. Scrolling it back on any other render would undo the SE's
  // own scrolling.
  const names = props.options.map((o) => o.name).join("\n");
  useEffect(reveal, [props.value, names]);
  useEffect(() => {
    const el = list.current!;
    let width = el.clientWidth;
    const observer = new ResizeObserver(() => {
      if (el.clientWidth === width) return;
      width = el.clientWidth;
      reveal();
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return (
    <div role="group" aria-label={props.label} className="flex min-w-0 items-center rounded-lg border p-0.5">
      <div ref={list} className="flex min-w-0 overflow-x-auto overflow-y-hidden [scrollbar-width:thin]">
        {props.options.map((o) => (
          <Button
            key={o.value}
            size="sm"
            variant={props.value === o.value ? "default" : "ghost"}
            aria-pressed={props.value === o.value}
            title={o.name}
            disabled={props.disabled}
            className="max-w-48"
            onClick={() => props.onChange(o.value)}
          >
            <span className="truncate">{o.name}</span>
            {o.badge}
          </Button>
        ))}
      </div>
      {props.children}
    </div>
  );
}
