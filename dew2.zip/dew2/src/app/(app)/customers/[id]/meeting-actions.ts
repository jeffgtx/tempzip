"use server";

import { notFound } from "next/navigation";
import { z } from "zod";
import { requireUser } from "@/auth/current";
import { getCustomer } from "@/customers/data";
import { endMeeting, pendingReturnVisits, startMeeting } from "@/meetings/data";
import { generateNotes, regenerateNotes, saveMemo } from "@/notes/data";

async function ownCustomer(customerId: string) {
  const user = await requireUser();
  if (!z.uuid().safeParse(customerId).success || !(await getCustomer(user.id, customerId))) notFound();
  return user;
}

export async function startMeetingAction(customerId: string) {
  const user = await ownCustomer(customerId);
  const meeting = await startMeeting(user.id, customerId);
  return { meeting, pending: await pendingReturnVisits(user.id, customerId, meeting) };
}

// Returns the ended meeting, whose notes are ready unless generating them failed.
export async function endMeetingAction(customerId: string, timeZone: string) {
  const user = await ownCustomer(customerId);
  const meetingId = await endMeeting(user.id, customerId);
  if (meetingId) await generateNotes(user.id, meetingId, timeZone).catch((error) => console.error("Notes failed", error));
  return meetingId;
}

const meetingInput = z.object({ customerId: z.uuid(), meetingId: z.uuid(), timeZone: z.string().max(100) });

export async function regenerateNotesAction(input: z.input<typeof meetingInput>) {
  const user = await requireUser();
  const parsed = meetingInput.safeParse(input);
  return parsed.success ? regenerateNotes(user.id, parsed.data.customerId, parsed.data.meetingId, parsed.data.timeZone) : null;
}

export async function saveMemoAction(input: z.input<typeof meetingInput> & { memo: string }) {
  const user = await requireUser();
  const parsed = meetingInput.extend({ memo: z.string().max(20_000) }).safeParse(input);
  if (!parsed.success) return null;
  const { customerId, meetingId, memo, timeZone } = parsed.data;
  return saveMemo(user.id, customerId, meetingId, memo, timeZone);
}
