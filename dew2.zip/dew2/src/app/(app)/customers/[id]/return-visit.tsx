"use client";

import { IconEraser, IconEye, IconGhost } from "@tabler/icons-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";

// Asked before the room shows a board that holds data from an earlier meeting.
export function ReturnVisit({ onChoose }: { onChoose: (choice: "live" | "clean" | "ghost") => void }) {
  return (
    <Dialog open>
      <DialogContent aria-describedby={undefined} showCloseButton={false} className="sm:max-w-md">
        <DialogTitle>This board holds entries from an earlier meeting</DialogTitle>
        <div className="grid grid-cols-3 gap-2">
          <Button variant="outline" className="h-auto flex-col py-3" onClick={() => onChoose("live")}>
            <IconEye className="size-5" />
            Keep
          </Button>
          <Button variant="outline" className="h-auto flex-col py-3" onClick={() => onChoose("ghost")}>
            <IconGhost className="size-5" />
            Ghost
          </Button>
          <Button variant="outline" className="h-auto flex-col py-3" onClick={() => onChoose("clean")}>
            <IconEraser className="size-5" />
            Start clean
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
