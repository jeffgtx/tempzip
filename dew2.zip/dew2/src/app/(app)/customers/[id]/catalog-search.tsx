"use client";

import { IconQuote, IconSearch } from "@tabler/icons-react";
import { cn } from "cn";
import { type RefObject, useState } from "react";
import { type CatalogOption, matchCatalog } from "@/catalog/match";
import { Input } from "@/components/ui/input";

// Type-ahead over catalog options, whose last choice is always the customer's own words.
export function CatalogSearch({
  inputRef,
  ...props
}: {
  options: CatalogOption[];
  label: string;
  inputRef?: RefObject<HTMLInputElement | null>;
  autoFocus?: boolean;
  onPick: (id: string) => void;
  onText: (text: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [highlight, setHighlight] = useState(0);
  const matches = matchCatalog(props.options, query);
  const text = query.trim();
  const choices = text ? matches.length + 1 : 0;

  const choose = (index: number) => {
    if (index < matches.length) props.onPick(matches[index].id);
    else if (text) props.onText(text);
    setQuery("");
    setHighlight(0);
  };

  return (
    <div className="relative">
      <IconSearch className="absolute top-2 left-2.5 size-4 text-muted-foreground" />
      <Input
        ref={inputRef}
        aria-label={props.label}
        autoFocus={props.autoFocus}
        autoComplete="off"
        maxLength={200}
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setHighlight(0);
        }}
        onKeyDown={(e) => {
          if (e.key === "ArrowDown") setHighlight((h) => Math.min(h + 1, choices - 1));
          else if (e.key === "ArrowUp") setHighlight((h) => Math.max(h - 1, 0));
          else if (e.key === "Enter" && choices) choose(highlight);
          else if (e.key === "Escape" && query) setQuery("");
          else return;
          e.preventDefault();
        }}
        className="pl-8"
      />
      {choices > 0 && (
        <ul role="listbox" className="mt-1 overflow-hidden rounded-lg border">
          {matches.map((o, i) => (
            <li key={o.id} role="option" aria-selected={i === highlight}>
              <button
                type="button"
                onClick={() => choose(i)}
                className={cn("flex w-full flex-col px-3 py-1.5 text-left text-sm", i === highlight && "bg-muted")}
              >
                {o.name}
                <span className="text-xs text-muted-foreground empty:hidden">{o.vendor?.name ?? o.group}</span>
              </button>
            </li>
          ))}
          <li role="option" aria-selected={highlight === matches.length}>
            <button
              type="button"
              onClick={() => choose(matches.length)}
              className={cn("flex w-full items-center gap-2 px-3 py-1.5 text-left text-sm", highlight === matches.length && "bg-muted")}
            >
              <IconQuote className="size-4 shrink-0 text-muted-foreground" aria-label="In their words" />
              {text}
            </button>
          </li>
        </ul>
      )}
    </div>
  );
}
