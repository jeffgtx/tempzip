"use client";

import {
  IconArrowLeft,
  IconBookmarkPlus,
  IconCategory,
  IconCheck,
  IconEraser,
  IconHourglass,
  IconPencil,
  IconQuote,
  IconTag,
  IconTags,
  IconTrash,
  IconX,
} from "@tabler/icons-react";
import { cn } from "cn";
import { type RefObject, useEffect, useMemo, useState } from "react";
import { PRISMA_SASE } from "@/board/architecture";
import type { Entry } from "@/board/model";
import type { CatalogOption } from "@/catalog/match";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { Category } from "@/content/schema";
import { CatalogSearch } from "./catalog-search";
import type { CockpitActions, Selection, Slot } from "./cockpit";
import { DraftInput } from "./draft-input";

export function Tray(props: {
  slot: Slot;
  // The slots that share this slot's tray.
  also: Slot[];
  // The chips to offer, or null where the editor lists the presets itself.
  chips: string[] | null;
  // Layout-specific controls for the selected entry, such as its fields.
  extra?: (entry: Entry) => React.ReactNode;
  // What the slot shows in place of its type-ahead and chips, as the summary's saved flows do.
  list?: React.ReactNode;
  // Its free text is a name the SE gives, not the customer's words.
  named?: boolean;
  entries: Entry[];
  entryId?: string;
  categories: Category[];
  suggested: string[];
  catalog: (CatalogOption & { category: string })[];
  label: (e: Entry) => string;
  search: RefObject<HTMLInputElement | null>;
  actions: CockpitActions;
  onSelect: (selection: Selection) => void;
  onClose: () => void;
}) {
  const { slot } = props;
  const entry = props.entries.find((e) => e.id === props.entryId);
  return (
    // The tray scrolls as a whole, so nothing in it shrinks to fit. It opens afresh for each entry.
    <aside
      key={entry?.id ?? ""}
      className="flex w-80 shrink-0 flex-col gap-4 overflow-y-auto border-l p-4 *:shrink-0"
    >
      <header className="flex items-center gap-1">
        {entry && (
          <Button variant="ghost" size="icon-sm" aria-label="Back" onClick={() => props.onSelect({ slot: slot.tray ?? slot.id })}>
            <IconArrowLeft />
          </Button>
        )}
        <h2 className="flex-1 truncate font-medium">{entry ? props.label(entry) : slot.name}</h2>
        <Button variant="ghost" size="icon-sm" aria-label="Close" onClick={props.onClose}>
          <IconX />
        </Button>
      </header>
      {entry ? (
        <EntryDetail
          slot={slot}
          entry={entry}
          extra={props.extra?.(entry)}
          // An editor that lists the presets itself keeps a preset's row, so removing its entry clears it.
          clears={props.chips === null && !!entry.itemId && slot.presets.includes(entry.itemId)}
          categories={props.categories}
          suggested={props.suggested.includes(entry.id)}
          named={!!props.named}
          actions={props.actions}
          // Picking steps saves as it goes, so a slot with its own list, such as the saved flows, offers a way back to it as done.
          onDone={props.list ? () => props.onSelect({ slot: slot.tray ?? slot.id }) : undefined}
        />
      ) : (
        (props.list ?? <SlotDetail {...props} />)
      )}
    </aside>
  );
}

function SlotDetail({ slot, also, chips, entries, catalog, search, actions }: Parameters<typeof Tray>[0]) {
  const options = useMemo(
    () =>
      catalog.filter(
        (o) => !slot.categories.length || [slot, ...also].some((s) => s.categories.includes(o.category)),
      ),
    [catalog, slot, also],
  );
  const byId = useMemo(() => new Map(catalog.map((o) => [o.id, o])), [catalog]);
  const present = (own: Slot, itemId: string) =>
    entries.some((e) => e.slot === own.id && e.itemId === itemId && e.status === "live");
  // Prisma SASE is a shortcut, not an entry, so it reads pressed while picking it would change nothing: the entries the
  // cockpit's bundle would take are live and grouped.
  const bundled = (own: Slot) => {
    const [access, sdwan] = [PRISMA_SASE.access, PRISMA_SASE.sdwan].map((itemId) =>
      entries.find((e) => e.slot === own.id && e.itemId === itemId && e.status !== "dismissed"),
    );
    return access?.status === "live" && sdwan?.status === "live" && sdwan.attrs.group === access.id;
  };

  return (
    <>
      <CatalogSearch
        options={options}
        label="Add to this slot"
        inputRef={search}
        onPick={(id) => actions.pick([slot, ...also].find((s) => s.categories.includes(byId.get(id)!.category)) ?? slot, id)}
        onText={(text) => actions.addText(slot, text)}
      />
      <ul className="flex flex-wrap gap-1.5">
        {[
          ...(chips ?? []).map((id) => [slot, id] as const),
          ...also.flatMap((s) => s.presets.map((id) => [s, id] as const)),
        ].map(([own, id]) => {
          const shortcut = id === PRISMA_SASE.id;
          // In a slot that repeats, a preset adds another entry rather than toggling one.
          const on = shortcut ? bundled(own) : !own.repeats && present(own, id);
          return (
            <li key={`${own.id}:${id}`}>
              <Button
                size="sm"
                variant={on && !shortcut ? "default" : "outline"}
                aria-pressed={on}
                className={cn(
                  "h-auto rounded-full py-1 text-left whitespace-normal",
                  on &&
                    shortcut &&
                    "border-transparent bg-muted-foreground text-background hover:bg-muted-foreground/90 hover:text-background dark:border-transparent dark:bg-muted-foreground dark:hover:bg-muted-foreground/90",
                )}
                onClick={() => actions.pick(own, id, !own.repeats)}
              >
                {byId.get(id)?.name ?? id}
              </Button>
            </li>
          );
        })}
      </ul>
    </>
  );
}

function EntryDetail(props: {
  slot: Slot;
  entry: Entry;
  extra: React.ReactNode;
  clears: boolean;
  categories: Category[];
  suggested: boolean;
  named: boolean;
  actions: CockpitActions;
  onDone?: () => void;
}) {
  const { slot, entry, actions } = props;
  const Icon = props.named ? IconPencil : IconQuote;
  const [suggesting, setSuggesting] = useState(false);
  // An entry of a slot with its own list, such as a saved flow, keeps its name and its way back above its steps, in view
  // however far they run.
  const top = !!props.onDone;
  const name = entry.text !== null && (
    <div className={cn("relative", top && "min-w-0 flex-1")}>
      <Icon className="absolute top-2 left-2.5 size-4 text-muted-foreground" />
      <DraftInput
        key={entry.text}
        aria-label={props.named ? "Name" : "Their words"}
        maxLength={200}
        value={entry.text}
        onCommit={(value) => value.trim() && value.trim() !== entry.text && actions.rename(entry, value.trim())}
        className="pl-8"
      />
    </div>
  );
  const buttons = (
    <div className="flex justify-end gap-1">
      {entry.text !== null && props.categories.length > 0 && (
        <div className="mr-auto">
          {props.suggested ? (
            <span title="Suggested for the catalog">
              <IconHourglass className="m-2 size-5 text-muted-foreground" aria-label="Suggested for the catalog" />
            </span>
          ) : (
            !suggesting && (
              <Button
                variant="outline"
                size="icon"
                aria-label="Suggest for the catalog"
                title="Suggest for the catalog"
                onClick={() => setSuggesting(true)}
              >
                <IconBookmarkPlus />
              </Button>
            )
          )}
        </div>
      )}
      <Button
        variant="destructive"
        size="icon"
        aria-label={props.clears ? "Clear" : "Remove"}
        title={props.clears ? "Clear" : "Remove"}
        onClick={() => actions.remove(slot, entry)}
      >
        {props.clears ? <IconEraser /> : <IconTrash />}
      </Button>
      {props.onDone && (
        <Button size="icon" aria-label="Done" title="Done" onClick={props.onDone}>
          <IconCheck />
        </Button>
      )}
    </div>
  );
  return (
    <>
      {top && (
        <div className="sticky -top-4 z-10 -my-4 flex items-center justify-end gap-1 bg-background py-4">
          {name}
          {buttons}
        </div>
      )}
      {props.extra}
      {!top && name}
      {/* Keyed on the note, so an undone note change shows at once. */}
      <NoteField key={entry.note} entry={entry} actions={actions} />
      {suggesting && <SuggestForm entry={entry} categories={props.categories} actions={actions} onDone={() => setSuggesting(false)} />}
      {!top && buttons}
    </>
  );
}

function NoteField({ entry, actions }: { entry: Entry; actions: CockpitActions }) {
  const [note, setNote] = useState(entry.note ?? "");
  const save = () => {
    const next = note.trim() || null;
    if (next !== entry.note) actions.note(entry, next);
  };
  // A reload or a closed tab doesn't blur the field. The commit queue keeps what the page commits as it goes.
  useEffect(() => {
    window.addEventListener("pagehide", save);
    return () => window.removeEventListener("pagehide", save);
  });
  return (
    <textarea
      aria-label="Note"
      placeholder="Note"
      maxLength={2000}
      value={note}
      onChange={(e) => setNote(e.target.value)}
      onBlur={save}
      rows={5}
      className="rounded-lg border bg-transparent p-2 text-sm outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
    />
  );
}

function SuggestForm(props: { entry: Entry; categories: Category[]; actions: CockpitActions; onDone: () => void }) {
  const [name, setName] = useState(props.entry.text ?? "");
  const [category, setCategory] = useState(props.categories[0].id);
  const [aliases, setAliases] = useState("");
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);
  const field = (Icon: typeof IconTag, control: React.ReactNode) => (
    <div className="relative">
      <Icon className="pointer-events-none absolute top-2 left-2.5 size-4 text-muted-foreground" />
      {control}
    </div>
  );
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        const ok = await props.actions.suggest(props.entry, { name, category, aliases: aliases.split(",") });
        setBusy(false);
        if (ok) props.onDone();
        else setFailed(true);
      }}
      className="flex flex-col gap-3 rounded-lg border p-3"
    >
      {field(
        IconTag,
        <Input aria-label="Name" value={name} onChange={(e) => setName(e.target.value)} required maxLength={200} className="h-8 pl-8" />,
      )}
      {props.categories.length > 1 &&
        field(
          IconCategory,
          <select
            aria-label="Category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="h-8 w-full min-w-0 rounded-lg border bg-transparent pr-2 pl-8 text-sm"
          >
            {props.categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>,
        )}
      {field(
        IconTags,
        <Input
          aria-label="Aliases"
          value={aliases}
          onChange={(e) => setAliases(e.target.value)}
          placeholder="Aliases, comma separated"
          className="h-8 pl-8"
        />,
      )}
      {failed && (
        <p role="alert" className="text-sm text-destructive">
          Couldn&apos;t suggest it. Check the aliases: up to 20, of 100 characters each.
        </p>
      )}
      <div className="flex justify-end gap-1">
        <Button type="button" variant="ghost" size="icon" aria-label="Cancel" title="Cancel" onClick={props.onDone}>
          <IconX />
        </Button>
        <Button type="submit" size="icon" aria-label="Suggest" title="Suggest" disabled={busy}>
          <IconCheck />
        </Button>
      </div>
    </form>
  );
}
