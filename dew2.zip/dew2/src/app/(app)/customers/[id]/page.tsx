import { notFound, redirect } from "next/navigation";
import { z } from "zod";
import { boardCategories, carriedEntries, paneOf } from "@/board/model";
import { requireUser } from "@/auth/current";
import { attachedTo, impliedConcerns } from "@/board/concerns";
import {
  boardData,
  boardTemplate,
  boardsWithEntries,
  ensureBoard,
  ensureDiagrams,
  ensureZoomBoard,
  meetingCommits,
  placedOn,
  templateById,
  zoomedFrom,
} from "@/board/data";
import { concernEntries, concernsTemplate, deviceClasses, litContent } from "@/board/view";
import { capabilityProducts } from "@/board/lit-map";
import { catalogFor, itemNames } from "@/catalog/data";
import { suggestedEntries } from "@/catalog/suggestions";
import { getContent, railSections, withClusterPresets, zoomsOf } from "@/content/load";
import type { BoardTemplate } from "@/content/schema";
import { getCustomer } from "@/customers/data";
import { pendingReturnVisits, runningMeeting } from "@/meetings/data";
import { Cockpit } from "./cockpit";
import { isEditable } from "./editable";

// A summary's "+N more" zoom opens as `zoom=more`, and is its diagram's second pane; any other zoom opens as its entry's id.
async function zoomBoard(ownerId: string, customerId: string, template: BoardTemplate, boardId: string, zoomed: string) {
  const board =
    zoomed === "more"
      ? template.layout === "hub-and-spoke" && template.more && { id: boardId, template: templateById(template.more)! }
      : z.uuid().safeParse(zoomed).success && (await ensureZoomBoard(ownerId, customerId, zoomed));
  return board && board.template.layout === "zoom"
    ? {
        id: board.id,
        template: board.template,
        entryId: zoomed === "more" ? null : zoomed,
        classes: deviceClasses(),
        products: capabilityProducts(getContent().items),
      }
    : null;
}

export default async function CockpitPage({ params, searchParams }: PageProps<"/customers/[id]">) {
  const user = await requireUser();
  const { id } = await params;
  const customer = z.uuid().safeParse(id).success ? await getCustomer(user.id, id) : null;
  if (!customer) notFound();

  const content = getContent();
  const sections = railSections(customer.clusters);
  const { board: requested, zoom: zoomed, diagram: pickedDiagram, boardId: named, entry, capability } = await searchParams;
  // Undo names another board by its id, which opens as its template, a diagram as itself, and the entry it changed, on a
  // grid in its zoom when that's where the change shows. A concern attached to a capability or detached from it opens
  // where that's done, the capability's group zoom on the lit map.
  const changed = typeof entry === "string" && z.uuid().safeParse(entry).success ? entry : null;
  const byId = typeof named === "string" && z.uuid().safeParse(named).success ? await boardTemplate(user.id, named) : undefined;
  const group = content.items.find((i) => i.id === capability)?.group;
  const attachedOn =
    byId?.layout === "ranked-list" && group
      ? content.templates.find((t) => t.layout === "lit-map" && concernsTemplate(t)?.id === byId.id && t.slots[0].presets.includes(group))
      : undefined;
  if (attachedOn) redirect(`/customers/${id}?board=${attachedOn.id}&zoom=${group}`);
  if (byId)
    redirect(
      `/customers/${id}?board=${byId.id}${byId.layout === "hub-and-spoke" ? `&diagram=${named}` : ""}${changed ? `&entry=${changed}` : ""}${byId.layout === "grid" && changed && zoomed === changed ? `&zoom=${changed}` : ""}`,
    );
  const [meeting, filled] = await Promise.all([runningMeeting(user.id, id), boardsWithEntries(user.id, id)]);
  const shown = meeting?.boardId ? await boardTemplate(user.id, meeting.boardId) : undefined;
  const boardIds = sections.flatMap((s) => s.boards);
  // Without a board in the URL, the cockpit opens on the topic the room shows, so opening it doesn't change topic.
  const home = shown?.layout === "zoom" ? boardIds.find((b) => zoomsOf(templateById(b)!).includes(shown.id)) : shown?.id;
  const templateId = boardIds.find((b) => b === requested) ?? boardIds.find((b) => b === home) ?? boardIds[0];
  const found = templateId ? templateById(templateId) : undefined;
  const template = found && isEditable(found) ? withClusterPresets(found, customer.clusters) : undefined;
  // The URL names the board, so a refresh, such as after editing the customer, keeps it.
  if (template && template.id !== requested) redirect(`/customers/${id}?board=${template.id}`);

  // A lit map's zoom names one of its capability groups.
  const litGroup =
    template?.layout === "lit-map" && typeof zoomed === "string" && template.slots[0].presets.includes(zoomed) ? zoomed : null;
  // A lit map attaches concerns to capabilities on its cluster's Concerns board.
  const ranked = template?.layout === "lit-map" ? concernsTemplate(template) : undefined;
  const [diagrams, rankedId, roomBoard] = await Promise.all([
    template?.layout === "hub-and-spoke" ? ensureDiagrams(user.id, id, template.id) : null,
    ranked ? ensureBoard(user.id, id, ranked.id) : null,
    template?.layout === "hub-and-spoke" && shown?.layout === "zoom" && meeting?.boardId
      ? zoomedFrom(user.id, meeting.boardId)
      : meeting?.boardId,
  ]);
  // Without one in the URL, the diagram the room shows, or whose zoom it shows, else the first.
  const diagram = diagrams && (diagrams.find((d) => d.id === pickedDiagram) ?? diagrams.find((d) => d.id === roomBoard) ?? diagrams[0]);
  const boardId = diagram ? diagram.id : template ? await ensureBoard(user.id, id, template.id) : null;
  const zoom = template && boardId && typeof zoomed === "string" ? await zoomBoard(user.id, id, template, boardId, zoomed) : null;
  const [data, catalog, pending, log, placed, concerns, rankedData, suggested] = await Promise.all([
    boardId ? boardData(user.id, boardId) : null,
    template ? catalogFor(template) : [],
    meeting ? pendingReturnVisits(user.id, id, meeting) : ([] as string[]),
    meeting ? meetingCommits(user.id, meeting.id) : [],
    boardId ? placedOn(user.id, id, { except: boardId }) : [],
    template?.layout === "lit-map" ? concernEntries(user.id, id, { except: rankedId ?? undefined }) : [],
    rankedId ? boardData(user.id, rankedId) : null,
    suggestedEntries(user.id, id),
  ]);
  const settled = placed.filter((p) => !pending.includes(p.boardId));
  // Opening another discussion starts at its first pane; a board and its zooms are one discussion. Undo or redo opens a
  // board in groups at the group holding the entry it changed, which it may have deleted.
  const sameDiscussion = !!template && !!shown && (shown.id === template.id || zoomsOf(template).includes(shown.id));
  const reverted = changed && [...(data?.entries ?? []), ...log.flatMap((c) => carriedEntries(c.op))].find((e) => e.id === changed);
  const start = reverted && template ? paneOf(template, reverted, (itemId) => catalog.find((o) => o.id === itemId)?.category) : null;
  const names = await itemNames([
    ...(data?.entries.flatMap((e) => [...(e.itemId ? [e.itemId] : []), ...attachedTo(e.attrs)]) ?? []),
    ...placed.map((p) => p.itemId),
  ]);

  return (
    <Cockpit
      key={`${boardId}:${zoom?.id ?? litGroup}`}
      customer={customer}
      seq={customer.seq}
      clusterOptions={content.clusters.map(({ id, name }) => ({ id, name }))}
      rail={sections.map((s) => ({
        id: s.id,
        name: s.name,
        boards: s.boards.map((b) => ({ id: b, template: templateById(b)!, filled: filled.some((f) => f.templateId === b && f.id !== boardId) })),
      }))}
      board={template && boardId && data ? { id: boardId, template, data } : null}
      zoom={zoom && (!zoom.entryId || data?.entries.some((e) => e.id === zoom.entryId)) ? zoom : null}
      lit={
        template?.layout === "lit-map"
          ? {
              ...litContent(template),
              concerns,
              implied: ranked ? [...impliedConcerns(ranked, settled, content)] : [],
              zoomed: litGroup,
              concernsBoard: ranked && rankedId && rankedData ? { id: rankedId, slot: ranked.slots[0], data: rankedData } : null,
            }
          : null
      }
      placed={placed}
      implied={template?.layout === "ranked-list" ? [...impliedConcerns(template, settled, content)] : []}
      catalog={catalog}
      names={names}
      categories={content.categories.filter((c) => template && boardCategories(template).includes(c.id))}
      architectures={content.architectures.filter((a) => a.board === template?.id)}
      diagrams={diagrams && diagram ? { list: diagrams, current: diagram } : null}
      suggested={suggested}
      meeting={
        meeting && {
          id: meeting.id,
          code: meeting.code!,
          held: meeting.held,
          pane: start ?? (sameDiscussion ? meeting.pane : 0),
        }
      }
      pending={pending}
      log={log}
    />
  );
}
