import type { BoardTemplate } from "@/content/schema";

const EDITABLE = ["grid", "ranked-list", "lit-map", "list", "hub-and-spoke"] as const;

// The layouts the cockpit has editors for.
export type EditableTemplate = Extract<BoardTemplate, { layout: (typeof EDITABLE)[number] }>;
export const isEditable = (t: BoardTemplate): t is EditableTemplate => (EDITABLE as readonly string[]).includes(t.layout);
