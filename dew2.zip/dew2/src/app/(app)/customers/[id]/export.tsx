"use client";

import { IconPhoto, IconPhotoX } from "@tabler/icons-react";
import { domToBlob } from "modern-screenshot";
import { useState } from "react";
import { flushSync } from "react-dom";
import { createRoot } from "react-dom/client";
import type { BoardView, ViewOptions } from "@/board/view";
import type { BoardTemplate } from "@/content/schema";
import { Button } from "@/components/ui/button";
import { useBriefly } from "@/components/use-briefly";
import { HEIGHT, RoomStage, WIDTH } from "@/app/present/room-canvas";
import { RoomView } from "@/app/present/room-view";
import type { CockpitCustomer } from "./cockpit";

// A board's view as the room shows it: its entry's for a zoom, and the picked diagram's for the summary.
export const viewUrl = (
  customerId: string,
  templateId: string,
  { pane, focus }: ViewOptions,
  pick: { entryId?: string; diagramId?: string } = {},
) =>
  `/api/customers/${customerId}/boards/${templateId}?pane=${pane}` +
  `${pick.entryId ? `&entry=${pick.entryId}` : ""}${pick.diagramId ? `&diagram=${pick.diagramId}` : ""}${focus ? `&focus=${focus}` : ""}`;

export const fileName = (...parts: string[]) =>
  parts
    .join("-")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

export function saveFile(name: string, file: Blob) {
  const link = document.createElement("a");
  link.href = URL.createObjectURL(file);
  link.download = name;
  link.click();
  // A browser may start the download only after click() returns.
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

// Renders the room view offscreen at full size, so the image matches the room exactly.
export async function renderPng(board: BoardView, customer: Pick<CockpitCustomer, "accent" | "logoUrl">) {
  const host = document.createElement("div");
  host.style.cssText = "position: fixed; top: 0; left: -100000px; pointer-events: none";
  document.body.append(host);
  const root = createRoot(host);
  try {
    flushSync(() =>
      root.render(
        <RoomStage accent={customer.accent}>
          <RoomView board={board} logoUrl={customer.logoUrl} />
        </RoomStage>,
      ),
    );
    await Promise.all([...host.querySelectorAll("img")].map((img) => img.decode().catch(() => {})));
    await document.fonts.ready;
    return await domToBlob(host.firstElementChild as HTMLElement, {
      width: WIDTH,
      height: HEIGHT,
      type: "image/png",
      onCloneEachNode: (node) => {
        if (!(node instanceof HTMLElement)) return;
        // Chrome reports a line-clamped -webkit-box as flow-root, which loses the clamp and its ellipsis in the copy.
        if (/^\d/.test(node.style.webkitLineClamp)) node.style.display = "-webkit-box";
        // The copy pins each box to its computed height, rounded down a fraction of a pixel. A multi-column box
        // pinned so is too short for its tallest column, whose last card then breaks into the next column. Most
        // copies carry column-count "auto", so only a number marks one.
        if (/^\d/.test(node.style.columnCount)) node.style.height = "auto";
      },
    });
  } finally {
    root.unmount();
    host.remove();
  }
}

async function exportPng(customer: CockpitCustomer, template: BoardTemplate, options: ViewOptions, named: Named) {
  const response = await fetch(viewUrl(customer.id, template.id, options, { entryId: named.entry?.id, diagramId: named.diagram?.id }));
  if (!response.ok) throw new Error(`Board not available: ${response.status}`);
  const png = await renderPng((await response.json()) as BoardView, customer);
  const shown = [named.diagram?.name, named.entry?.name].filter((part): part is string => !!part);
  saveFile(`${fileName(customer.name, ...(shown.length ? shown : [template.name]))}.png`, png);
}

// What the image is named after instead of the board: the diagram shown, then a zoom board's entry or the pane shown,
// such as a concern group.
type Named = { entry?: { id?: string; name: string }; diagram?: { id: string; name: string } };

export function ExportButton({
  customer,
  template,
  pane = 0,
  focus = null,
  ...named
}: Named & {
  customer: CockpitCustomer;
  template: BoardTemplate;
  pane?: number;
  // The flow picked on the summary, which exports lit.
  focus?: string | null;
}) {
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useBriefly(3000);
  const run = async () => {
    setBusy(true);
    try {
      await exportPng(customer, template, { pane, focus }, named);
    } catch {
      setFailed(true);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Button variant="ghost" size="icon" aria-label="Export PNG" title="Export PNG" disabled={busy} onClick={() => void run()}>
      {failed ? <IconPhotoX className="text-destructive" /> : <IconPhoto />}
    </Button>
  );
}
