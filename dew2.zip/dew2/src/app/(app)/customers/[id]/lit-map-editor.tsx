"use client";

import { IconEye, IconEyeOff, IconGhost, IconLink, IconLinkOff, IconMessage2, IconZoomIn } from "@tabler/icons-react";
import { cn } from "cn";
import Link from "next/link";
import { useState } from "react";
import { litMap } from "@/board/lit-map";
import { type BoardData, entriesIn } from "@/board/model";
import type { BoardTemplate } from "@/content/schema";
import { Button } from "@/components/ui/button";
import { CatalogSearch } from "./catalog-search";
import type { CockpitActions, LitInput } from "./cockpit";
import { selectedClass } from "./selected";

export function LitMapEditor({
  template,
  data,
  lit,
  attachable,
  zoomHref,
  selected,
  onSelect,
  actions,
}: {
  template: Extract<BoardTemplate, { layout: "lit-map" }>;
  data: BoardData;
  lit: LitInput;
  attachable: boolean;
  zoomHref: (groupId: string) => string | null;
  selected: string | undefined;
  onSelect: (itemId: string | null) => void;
  actions: CockpitActions;
}) {
  const slot = template.slots[0];
  const overrides = entriesIn(data, slot.id);
  const groups = litMap({ ...lit, implied: new Set(lit.implied), overrides: overrides.filter((e) => e.status === "live") });
  const ghosts = new Map(overrides.filter((e) => e.status === "ghost").map((e) => [e.itemId, e]));
  const ghostAt = (id: string, level: number) => ghosts.get(id)?.attrs.level === level;
  const zoomed = groups.find((g) => g.id === lit.zoomed);
  const [attaching, setAttaching] = useState<string | null>(null);
  const concernItems = lit.items.filter((i) => lit.concernsBoard?.slot.categories.includes(i.category));
  return (
    // Columns rather than a grid, so a short group doesn't leave a long one's height empty beside it.
    <div className={cn("max-w-6xl", !zoomed && "columns-[20rem] gap-4")}>
      {(zoomed ? [zoomed] : groups).map((g) => {
        const href = zoomHref(g.id);
        const title = (
          <>
            <span className="text-sm font-medium text-muted-foreground">{g.name}</span>
            {g.summary && <span className="text-xs text-muted-foreground">{g.summary}</span>}
          </>
        );
        return (
          <section
            key={g.id}
            className={cn(
              "mb-4 flex break-inside-avoid flex-col gap-2 rounded-xl border p-3",
              g.hidden && "border-dashed opacity-50",
              selected === g.id && selectedClass,
            )}
          >
            <div className="flex items-start gap-1">
              {zoomed ? (
                <div className="flex flex-1 flex-col">{title}</div>
              ) : (
                <button
                  type="button"
                  aria-pressed={selected === g.id}
                  onClick={() => onSelect(selected === g.id ? null : g.id)}
                  className="flex flex-1 flex-col text-left"
                >
                  {title}
                </button>
              )}
              {href && (
                <Button asChild size="icon-xs" variant="ghost">
                  <Link href={href} aria-label={`Zoom into ${g.name}`} title={`Zoom into ${g.name}`}>
                    <IconZoomIn />
                  </Link>
                </Button>
              )}
              <Button
                size="icon-xs"
                variant="ghost"
                aria-pressed={g.hidden}
                aria-label={`Hide ${g.name}`}
                title={`Hide ${g.name}`}
                onClick={() => actions.pick(slot, g.id, true)}
              >
                {g.hidden ? <IconEyeOff /> : ghosts.has(g.id) ? <IconGhost /> : <IconEye />}
              </Button>
            </div>
            <ul className={cn("gap-2", zoomed ? "grid grid-cols-[repeat(auto-fill,minmax(18rem,1fr))]" : "flex flex-col")}>
              {g.capabilities.map((c) => {
                const levels = (
                  <div role="group" aria-label={`${c.name} level`} className="flex">
                    {[1, 2, 3].map((level) => {
                      const picked = c.forced === level;
                      const ghost = !picked && ghostAt(c.id, level);
                      // The concerns' level is grey while it lights the room, and outlined while the SE's pick, or off, keeps it dark.
                      const concerns = c.computed === level && !picked && !ghost;
                      const off = concerns && c.forced === 0;
                      const next = picked ? (c.computed === level ? 0 : null) : off ? null : level;
                      return (
                        <Button
                          key={level}
                          size="icon-xs"
                          variant={picked ? "default" : ghost || (concerns && c.forced !== null) ? "outline" : concerns ? "secondary" : "ghost"}
                          aria-pressed={picked}
                          className={cn(ghost && "border-dashed text-muted-foreground")}
                          aria-label={off ? `Level ${level}, their concerns' level, off` : concerns ? `Level ${level}, their concerns' level` : `Level ${level}`}
                          title={
                            picked
                              ? c.computed === level
                                ? "Turn off"
                                : c.computed
                                  ? `Back to ${c.computed}`
                                  : "Back to unlit"
                              : off
                                ? "Back to their concerns' level"
                                : concerns
                                  ? "Confirm their concerns' level"
                                  : ghost
                                    ? `Show in the room at ${level}`
                                    : `Level ${level}`
                          }
                          onClick={() => actions.force(slot, c.id, next)}
                        >
                          {level}
                        </Button>
                      );
                    })}
                  </div>
                );
                return (
                  <li
                    key={c.id}
                    className={cn(
                      "rounded-lg border p-2",
                      c.level === 0 && "border-dashed text-muted-foreground",
                      selected === c.id && selectedClass,
                    )}
                  >
                    <div className="flex items-start gap-2">
                      <button
                        type="button"
                        aria-pressed={selected === c.id}
                        onClick={() => onSelect(selected === c.id ? null : c.id)}
                        className="flex flex-1 flex-col gap-1 text-left"
                      >
                        <span className="text-sm font-medium">{c.name}</span>
                        {zoomed && (
                          <span className="flex flex-wrap gap-1">
                            {c.products.map((p) => (
                              <span key={p} className="rounded-full bg-muted px-2 py-0.5 text-xs">
                                {p}
                              </span>
                            ))}
                          </span>
                        )}
                        {c.summary && <span className="text-xs text-muted-foreground">{c.summary}</span>}
                      </button>
                      {ghosts.has(c.id) && (
                        <Button
                          size="icon-xs"
                          variant="ghost"
                          aria-label="Show in the room"
                          title={`Show in the room at ${ghosts.get(c.id)!.attrs.level}`}
                          onClick={() => actions.confirm(ghosts.get(c.id)!)}
                        >
                          <IconGhost />
                        </Button>
                      )}
                      {!zoomed && levels}
                    </div>
                    {zoomed && (
                      <>
                        {c.concerns.length > 0 && (
                          <ul className="mt-2 flex flex-col gap-1">
                            {c.concerns.map((k) => (
                              <li key={k.key} className={cn("flex items-center gap-1.5 text-xs", !k.level && "text-muted-foreground")}>
                                <IconMessage2 className="size-3.5 shrink-0" />
                                <span className="flex-1">{k.label}</span>
                                {k.attached && attachable && (
                                  <Button
                                    size="icon-xs"
                                    variant="ghost"
                                    aria-label={`Detach ${k.label}`}
                                    title="Detach"
                                    onClick={() => actions.detach(c.id, k.key)}
                                  >
                                    <IconLinkOff />
                                  </Button>
                                )}
                              </li>
                            ))}
                          </ul>
                        )}
                        {attachable && attaching === c.id && (
                          <div className="mt-2">
                            <CatalogSearch
                              autoFocus
                              label="Concern to attach"
                              options={concernItems
                                .filter((i) => !c.concerns.some((k) => k.key === i.id))
                                .map(({ id, name, aliases }) => ({ id, name, aliases, vendor: null }))}
                              onPick={(itemId) => {
                                actions.attach(c.id, { itemId });
                                setAttaching(null);
                              }}
                              onText={(text) => {
                                actions.attach(c.id, { text });
                                setAttaching(null);
                              }}
                            />
                          </div>
                        )}
                        <div className="mt-2 flex items-center justify-between">
                          {attachable ? (
                            <Button
                              size="icon-xs"
                              variant="ghost"
                              aria-pressed={attaching === c.id}
                              aria-label="Attach a concern"
                              title="Attach a concern"
                              onClick={() => setAttaching((a) => (a === c.id ? null : c.id))}
                            >
                              <IconLink />
                            </Button>
                          ) : (
                            <span />
                          )}
                          {levels}
                        </div>
                      </>
                    )}
                  </li>
                );
              })}
            </ul>
          </section>
        );
      })}
    </div>
  );
}
