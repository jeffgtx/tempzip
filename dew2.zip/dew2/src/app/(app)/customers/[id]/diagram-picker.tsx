"use client";

import { IconChevronLeft, IconChevronRight, IconCopy, IconDots, IconPencil, IconPlus, IconTrash } from "@tabler/icons-react";
import { cn } from "cn";
import { unstable_rethrow, useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { DIAGRAM_NAME_MAX, type Diagram, type Op, diagramName, moveOp, renameOp } from "@/board/model";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { addDiagramAction, deleteDiagramAction } from "./diagram-actions";
import { Picker } from "./top-bar";

type Naming = { kind: "blank" | "copy" | "rename"; name: string };

// The summary's diagrams, one shown at a time, and what can be done with them.
export function DiagramPicker(props: {
  customerId: string;
  templateId: string;
  diagrams: Diagram[];
  current: string;
  offline: boolean;
  // Lets queued commits land first, so a copy holds them.
  drained: () => Promise<unknown>;
  onFailed: () => void;
  // Renaming and moving are commits, which undo takes back.
  onCommit: (op: Op) => void;
}) {
  const { customerId, templateId, diagrams, current } = props;
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [naming, setNaming] = useState<Naming | null>(null);
  const [deleting, setDeleting] = useState(false);
  const left = DIAGRAM_NAME_MAX - (naming?.name.trim().length ?? 0);
  const at = diagrams.findIndex((d) => d.id === current);
  const self = diagrams[at];
  const href = (id?: string) => `?board=${templateId}${id ? `&diagram=${id}` : ""}`;
  const run = (action: () => Promise<void>) =>
    startTransition(async () => {
      try {
        await action();
      } catch (error) {
        unstable_rethrow(error);
        props.onFailed();
      }
    });
  const move = (by: -1 | 1) => {
    const op = moveOp(diagrams, current, by);
    if (op) props.onCommit(op);
  };
  const save = (n: Naming) => {
    const name = n.name.trim();
    if (n.kind !== "rename")
      run(async () => {
        if (n.kind === "copy") await props.drained();
        const id = await addDiagramAction(customerId, templateId, { name, ...(n.kind === "copy" ? { copyOf: current } : {}) });
        if (id) router.push(href(id));
      });
    else if (name !== self.name) props.onCommit(renameOp(self, name));
  };
  // The default name is one no diagram has yet.
  const fresh = (base: (n: number) => string) => {
    for (let n = 1; ; n++) if (!diagrams.some((d) => d.name === base(n))) return base(n);
  };

  return (
    <Picker
      label="Diagram"
      value={current}
      options={diagrams.map((d) => ({ value: d.id, name: d.name }))}
      disabled={props.offline}
      onChange={(id) => id !== current && router.push(href(id))}
    >
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon-sm" aria-label="Diagrams" title="Diagrams" disabled={pending}>
            <IconDots />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem
            disabled={props.offline}
            onSelect={() => setNaming({ kind: "blank", name: fresh((n) => `Diagram ${diagrams.length + n}`) })}
          >
            <IconPlus />
            New blank
          </DropdownMenuItem>
          <DropdownMenuItem
            disabled={props.offline}
            onSelect={() => setNaming({ kind: "copy", name: fresh((n) => `${self.name} ${n + 1}`) })}
          >
            <IconCopy />
            Copy {self.name}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={() => setNaming({ kind: "rename", name: self.name })}>
            <IconPencil />
            Rename
          </DropdownMenuItem>
          <DropdownMenuItem disabled={at <= 0} onSelect={() => move(-1)}>
            <IconChevronLeft />
            Earlier
          </DropdownMenuItem>
          <DropdownMenuItem disabled={at >= diagrams.length - 1} onSelect={() => move(1)}>
            <IconChevronRight />
            Later
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem variant="destructive" disabled={props.offline || diagrams.length < 2} onSelect={() => setDeleting(true)}>
            <IconTrash />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={!!naming} onOpenChange={(open) => !open && setNaming(null)}>
        <DialogContent aria-describedby={undefined} className="sm:max-w-sm">
          <DialogTitle>{naming?.kind === "rename" ? "Rename" : naming?.kind === "copy" ? `Copy ${self.name}` : "New blank"}</DialogTitle>
          <form
            className="flex items-center gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (naming) save(naming);
              setNaming(null);
            }}
          >
            <Input
              aria-label="Name"
              autoComplete="off"
              autoFocus
              aria-invalid={left < 0}
              value={naming?.name ?? ""}
              onChange={(e) => setNaming((n) => n && { ...n, name: e.target.value })}
            />
            {left < 10 && (
              <span title="Characters left" className={cn("text-xs tabular-nums", left < 0 ? "text-destructive" : "text-muted-foreground")}>
                {left}
              </span>
            )}
            <Button type="submit" size="icon" aria-label="Save" title="Save" disabled={!diagramName.safeParse(naming?.name).success}>
              {naming?.kind === "rename" ? <IconPencil /> : <IconPlus />}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={deleting} onOpenChange={setDeleting}>
        <DialogContent aria-describedby={undefined} className="sm:max-w-sm">
          <DialogTitle>Delete {self.name}?</DialogTitle>
          <p className="text-sm">Everything on it goes, and this can&apos;t be undone.</p>
          <Button
            variant="destructive"
            aria-label="Delete"
            className="self-end"
            onClick={() => {
              setDeleting(false);
              run(async () => {
                if (await deleteDiagramAction(customerId, current)) router.push(href());
              });
            }}
          >
            <IconTrash />
          </Button>
        </DialogContent>
      </Dialog>
    </Picker>
  );
}
