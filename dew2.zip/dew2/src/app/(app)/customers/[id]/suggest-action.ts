"use server";

import { z } from "zod";
import { requireUser } from "@/auth/current";
import { proposal, raiseSuggestion } from "@/catalog/suggestions";

const suggestion = proposal.extend({ entryId: z.uuid(), category: z.string() });

export async function suggestAction(customerId: string, input: z.input<typeof suggestion>) {
  const user = await requireUser();
  const parsed = suggestion.safeParse(input);
  return z.uuid().safeParse(customerId).success && parsed.success ? raiseSuggestion(user.id, customerId, parsed.data) : false;
}
