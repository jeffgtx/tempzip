"use client";

import {
  IconArrowBarToDown,
  IconArrowBarToLeft,
  IconArrowBarToRight,
  IconArrowBarToUp,
  IconCheck,
  IconChevronDown,
  IconChevronLeft,
  IconChevronRight,
  IconChevronUp,
  IconFrame,
  IconFrameOff,
  IconGhost,
  IconNote,
  IconPlus,
  IconRoute,
  IconTemplate,
  IconTopologyStar3,
} from "@tabler/icons-react";
import { cn } from "cn";
import { Fragment } from "react";
import { type Placement, DATACENTERS, PRISMA_SASE, place } from "@/board/architecture";
import type { Zone } from "@/board/attributes";
import type { BoardData } from "@/board/model";
import { presetOps } from "@/board/presets";
import { type CatalogLookup, type FlowPath, type SummaryNode, type SummaryView, summaryView } from "@/board/summary";
import type { Architecture, BoardTemplate } from "@/content/schema";
import { NodeIcon } from "@/components/node-icon";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { whole } from "@/components/whole";
import type { EditorProps, Slot } from "./cockpit";
import { EntryActions } from "./entry-actions";
import { Suggestion } from "./grid-editor";
import { selectedClass } from "./selected";

type Template = Extract<BoardTemplate, { layout: "hub-and-spoke" }>;

// The summary as the room lays it out, from the cockpit's own data, ghosts included.
export function summaryOf(template: Template, data: BoardData, diagram: string, lookup: CatalogLookup) {
  const view = summaryView(template, { entries: data.entries.filter((e) => e.status !== "dismissed") }, diagram, lookup);
  return { view, placement: place(view.nodes, view.hub) };
}

export function SummaryEditor(
  props: EditorProps & {
    template: Template;
    summary: ReturnType<typeof summaryOf>;
    suggested: (slot: Slot) => string[];
    zoomHref: (entryId: string) => string | null;
    architectures: Architecture[];
    onArchitecture: (architecture: Architecture) => void;
    // The flow picked, whose nodes stand out while the rest fade.
    flow: FlowPath | null;
  },
) {
  const { template, data, selection, summary } = props;
  const { view, placement } = summary;
  const byId = new Map(view.nodes.map((n) => [n.id, n]));
  const status = new Map(data.entries.map((e) => [e.id, e.status]));
  const slotOf = new Map(data.entries.map((e) => [e.id, e.slot]));
  const outside = view.nodes.filter((n) => n.kind === "datacenter" && !placement.hub.includes(n.id));
  const empty = !view.nodes.length;
  const hosts = template.slots.filter((slot) => !slot.tray && slot.id !== template.flows);
  const trayOf = (id: string | undefined) => {
    const slot = template.slots.find((s) => s.id === id);
    return slot?.tray ?? slot?.id;
  };
  const open = (host: string) => trayOf(selection?.slot) === host && !selection?.entryId;

  const card = (node: SummaryNode) => {
    const ghost = status.get(node.id) === "ghost";
    const entry = data.entries.find((e) => e.id === node.id);
    const selected = selection?.entryId === node.id;
    const slot = template.slots.find((s) => s.id === slotOf.get(node.id));
    return (
      <NodeCard
        key={node.id}
        icon={ghost ? <IconGhost className="size-4 shrink-0" /> : <NodeIcon category={node.category} itemId={node.itemId} className="size-4 shrink-0" />}
        name={node.name}
        count={node.count === null ? null : node.count.toLocaleString("en-US")}
        note={!!entry?.note}
        quiet={ghost}
        clamp
        title={ghost ? "Show in the room" : undefined}
        selected={selected}
        onClick={() =>
          ghost && entry
            ? props.actions.confirm(entry)
            : props.onSelect(selected ? null : { slot: slotOf.get(node.id)!, entryId: node.id })
        }
        className={cn(props.flow && (props.flow.nodes.includes(node.id) ? selectedClass : "opacity-40"))}
      >
        {selected && slot && entry && (
          <EntryActions slot={slot} entry={entry} zoomHref={props.zoomHref(node.id)} actions={props.actions} />
        )}
      </NodeCard>
    );
  };
  const cards = (id: string) => {
    if (id === DATACENTERS) return outside.map((n) => card(n));
    if (!byId.has(id)) return [];
    const members = view.nodes.filter((n) => n.group?.lead === id);
    if (!members.length) return [card(byId.get(id)!)];
    return [
      <div key={id} className="flex flex-col gap-2 rounded-xl border-2 border-dashed p-1">
        {[byId.get(id)!, ...members].map((n) => card(n))}
      </div>,
    ];
  };
  // What the room folds into "+N more" sits together, apart from the shown nodes, since only they reorder.
  const zone = (z: Zone, className: string) => (
    <div className={cn("flex gap-2", className)}>
      {placement.zones[z].flatMap(cards)}
      {placement.folded[z] && (
        <div className={cn("flex gap-2 rounded-xl border-2 border-dashed bg-muted p-1.5", className)}>
          {placement.folded[z].flatMap(cards)}
        </div>
      )}
    </div>
  );

  return (
    <div className="flex max-w-5xl flex-col gap-4">
      <div role="group" aria-label="Add" className="flex flex-wrap items-center gap-1.5">
        {hosts.map((host) => (
          <Fragment key={host.id}>
            <Button
              size="sm"
              variant={open(host.id) ? "default" : "outline"}
              onClick={() => (open(host.id) ? props.onSelect(null) : props.onAdd(host.id))}
            >
              {host.name}
            </Button>
            {template.slots
              .filter((slot) => trayOf(slot.id) === host.id)
              .flatMap((slot) =>
                props.suggested(slot).map((itemId) => (
                  <Suggestion
                    key={`${slot.id}:${itemId}`}
                    name={props.name(itemId)}
                    onAccept={() => props.actions.pick(slot, itemId)}
                    onDismiss={() => props.actions.dismiss(slot, itemId)}
                  />
                )),
              )}
            </Fragment>
        ))}
        {template.flows && (
          <Button
            variant={selection?.slot === template.flows ? "default" : "ghost"}
            size="icon-sm"
            aria-label="Flows"
            title="Flows"
            onClick={() => props.onSelect(selection?.slot === template.flows ? null : { slot: template.flows! })}
          >
            <IconRoute />
          </Button>
        )}
        {!empty && props.architectures.length > 0 && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon-sm" aria-label="Add a common architecture" title="Add a common architecture">
                <IconTemplate />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-auto">
              <ArchitectureItems {...props} />
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
      {empty && !selection ? (
        <section aria-label="Start" className="grid grid-cols-3 gap-3">
          <StartCard icon={<IconPlus />} name="Blank" onClick={() => props.onAdd(hosts[0].id)} />
          {template.flows && (
            <StartCard icon={<IconRoute />} name="Start from a flow" onClick={() => props.onSelect({ slot: template.flows! })} />
          )}
          {props.architectures.map((a) => (
            <StartCard key={a.id} name={a.name} summary={a.summary} onClick={() => props.onArchitecture(a)} />
          ))}
        </section>
      ) : (
        <div className="grid grid-cols-[1fr_1.4fr_1fr] gap-3">
          {zone("top", "col-span-3 flex-wrap justify-center")}
          {zone("left", "flex-col justify-center")}
          <div className="flex min-h-40 flex-col justify-center gap-2 rounded-xl border-2 border-dashed p-3">
            {placement.hub.filter((id) => !byId.get(id)!.group).flatMap(cards)}
          </div>
          {zone("right", "flex-col justify-center")}
          {zone("bottom", "col-span-3 flex-wrap justify-center")}
        </div>
      )}
    </div>
  );
}

// Never narrower than its longest word, so its text breaks only between words, and its actions drop beneath it rather
// than squeeze it.
export function NodeCard(props: {
  icon: React.ReactNode;
  name: string;
  count?: string | null;
  stats?: React.ReactNode;
  detail?: string;
  note?: boolean;
  quiet?: boolean;
  // The overview keeps its cards to two lines; a zoom shows each name whole, as the room does.
  clamp?: boolean;
  selected: boolean;
  label?: string;
  title?: string;
  className?: string;
  onClick: () => void;
  children?: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "flex flex-wrap items-center justify-end rounded-lg border bg-background text-sm",
        props.quiet && "border-dashed text-muted-foreground",
        props.selected && selectedClass,
        props.className,
      )}
    >
      <button
        type="button"
        aria-pressed={props.selected}
        aria-label={props.label}
        title={props.title}
        onClick={props.onClick}
        className={cn("flex flex-1 items-center gap-2 py-1.5 pl-2.5 text-left", props.children ? "pr-1" : "pr-2.5")}
      >
        {props.icon}
        <span className="flex flex-1 flex-col">
          <span className={cn(props.clamp && "line-clamp-2")}>{whole(props.name)}</span>
          {(props.stats || props.detail) && (
            <span className="text-xs text-muted-foreground">
              {props.stats}
              {props.detail && whole(props.detail)}
            </span>
          )}
        </span>
        {props.count && <span className="text-xs text-muted-foreground tabular-nums">{props.count}</span>}
        {props.note && <IconNote className="size-3.5 shrink-0 text-muted-foreground" aria-label="Has a note" />}
      </button>
      {props.children}
    </span>
  );
}

function StartCard(props: { icon?: React.ReactNode; name: string; summary?: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={props.onClick}
      className="flex flex-col gap-1 rounded-xl border bg-background p-4 text-left hover:bg-muted"
    >
      <span className="flex items-center gap-2 font-medium [&_svg]:size-5 [&_svg]:text-muted-foreground">
        {props.icon}
        {props.name}
      </span>
      {props.summary && <span className="text-sm text-muted-foreground">{props.summary}</span>}
    </button>
  );
}

// Rendered only while the menu is open, since working out what each architecture would add takes a pass over the board.
function ArchitectureItems(props: { data: BoardData; architectures: Architecture[]; onArchitecture: (architecture: Architecture) => void }) {
  return props.architectures.map((a) => {
    const complete = !presetOps(props.data, a);
    return (
      <DropdownMenuItem key={a.id} disabled={complete} onSelect={() => props.onArchitecture(a)}>
        {a.name}
        {complete && <IconCheck className="ml-auto" aria-label="Nothing missing" />}
      </DropdownMenuItem>
    );
  });
}

const MOVES: [Zone, string, typeof IconArrowBarToUp][] = [
  ["top", "Move to the top row", IconArrowBarToUp],
  ["left", "Move to the left column", IconArrowBarToLeft],
  ["right", "Move to the right column", IconArrowBarToRight],
  ["bottom", "Move to the bottom row", IconArrowBarToDown],
];

// Moving a node to the zone it was moved to returns it to where it would go by itself.
export function PlacementControls(props: {
  node: SummaryNode;
  summary: { view: SummaryView; placement: Placement };
  onSet: (changes: [string, string, unknown][]) => void;
  onHub: (hub: boolean) => void;
}) {
  const { node, summary } = props;
  const { placement, view } = summary;
  const hub = placement.hub.includes(node.id);
  // A Prisma SD-WAN groups with an ungrouped Prisma Access, and either member ungroups them.
  const member = node.group ? node : view.nodes.find((n) => n.group?.lead === node.id);
  const free = view.nodes.find((n) => n.itemId === PRISMA_SASE.access && !view.nodes.some((m) => m.group?.lead === n.id));
  const pair = member ? [member.id, member.group!.lead] : node.itemId === PRISMA_SASE.sdwan && free ? [node.id, free.id] : null;
  // A grouped member goes with its lead.
  const fixed = hub || !!node.group;
  const zone = (Object.keys(placement.zones) as Zone[]).find((z) =>
    [...placement.zones[z], ...(placement.folded[z] ?? [])].includes(node.kind === "datacenter" ? DATACENTERS : node.id),
  );
  // Weight, not order, decides which nodes fold, so only the nodes shown reorder.
  const ids = zone ? placement.zones[zone] : [];
  const self = ids.indexOf(node.kind === "datacenter" ? DATACENTERS : node.id);
  const outside = view.nodes.filter((n) => n.kind === "datacenter" && !placement.hub.includes(n.id));
  // The data centers outside the hub move and reorder together, as the one node they show as.
  const entries = (id: string) => (id === DATACENTERS ? outside.map((n) => n.id) : [id]);
  const moved = node.kind === "datacenter" ? (outside.find((n) => n.zone)?.zone ?? null) : node.zone;
  const orders = new Map(view.nodes.map((n) => [n.id, n.order]));
  const reorder = (to: number) => {
    const order = [...ids];
    order.splice(to, 0, ...order.splice(self, 1));
    const changes = order.flatMap((id, i) =>
      entries(id).flatMap((e): [string, string, unknown][] => (orders.get(e) === i ? [] : [[e, "order", i]])),
    );
    if (changes.length) props.onSet(changes);
  };
  const columns = zone === "left" || zone === "right";
  return (
    <div className="flex flex-wrap items-center gap-1">
      {node.kind === "security" && (
        <Button
          variant={hub ? "default" : "outline"}
          size="icon-sm"
          aria-pressed={hub}
          aria-label="Hub"
          title={hub ? "The hub" : "Make this the hub"}
          onClick={() => props.onHub(!hub)}
        >
          <IconTopologyStar3 />
        </Button>
      )}
      {pair && (
        <Button
          variant={member ? "default" : "outline"}
          size="icon-sm"
          aria-pressed={!!member}
          aria-label="Prisma SASE"
          title="Prisma SASE"
          onClick={() => props.onSet([[pair[0], "group", member ? null : pair[1]]])}
        >
          {member ? <IconFrameOff /> : <IconFrame />}
        </Button>
      )}
      {!fixed &&
        MOVES.map(([z, title, Icon]) => (
          <Button
            key={z}
            variant={moved === z ? "default" : "ghost"}
            size="icon-sm"
            aria-pressed={moved === z}
            aria-label={title}
            title={title}
            onClick={() =>
              props.onSet(
                entries(node.kind === "datacenter" ? DATACENTERS : node.id).flatMap((id): [string, string, unknown][] => [
                  [id, "zone", moved === z ? null : z],
                  [id, "order", null],
                ]),
              )
            }
          >
            <Icon />
          </Button>
        ))}
      {!fixed && zone && (
        <>
          <Button variant="ghost" size="icon-sm" aria-label="Earlier" title="Earlier" disabled={self <= 0} onClick={() => reorder(self - 1)}>
            {columns ? <IconChevronUp /> : <IconChevronLeft />}
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Later"
            title="Later"
            disabled={self < 0 || self >= ids.length - 1}
            onClick={() => reorder(self + 1)}
          >
            {columns ? <IconChevronDown /> : <IconChevronRight />}
          </Button>
        </>
      )}
    </div>
  );
}
