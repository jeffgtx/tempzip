"use client";

import { IconDevices, IconFirewallCheck, IconGhost, IconShieldCheck, IconUsers } from "@tabler/icons-react";
import { cn } from "cn";
import { Fragment, useMemo } from "react";
import { type BoardData, live } from "@/board/model";
import { type CatalogLookup, nodeName, nodesAt } from "@/board/summary";
import {
  type AppRow,
  type AppView,
  type ZoomCard,
  type ZoomView,
  appView,
  quietAll,
  reach,
  sizedThrough,
  zoomView,
} from "@/board/zooms";
import type { BoardTemplate } from "@/content/schema";
import { BOUGHT_COLUMNS, BUILT_COLUMNS, ROW_ICONS } from "@/app/present/room-app";
import { ZoomCardIcon } from "@/app/present/room-zoom";
import { NodeIcon } from "@/components/node-icon";
import { whole } from "@/components/whole";
import type { CockpitActions } from "./cockpit";
import { EntryActions } from "./entry-actions";
import { selectedClass } from "./selected";
import { NodeCard } from "./summary-editor";

export type CockpitZoom = {
  id: string;
  template: Extract<BoardTemplate, { layout: "zoom" }>;
  // Null for the "+N more" zoom, which belongs to no one entry.
  entryId: string | null;
  classes: { id: string; name: string }[];
  // The names of the products that deliver each capability, for an AI app's zoom.
  products: Record<string, string[]>;
};

type ZoomEditorProps = {
  template: BoardTemplate;
  zoom: CockpitZoom;
  data: BoardData;
  // The diagram's name, which leads the zoom's subtitle.
  diagram: string;
  lookup: CatalogLookup;
  selected: string | undefined;
  zoomHref: (entryId: string) => string | null;
  actions: CockpitActions;
  onSelect: (entryId: string | null) => void;
};

export function ZoomEditor(props: ZoomEditorProps) {
  const { shows } = props.zoom.template;
  return shows === "app" ? <AppZoom {...props} /> : <ColumnZoom {...props} shows={shows} />;
}

// What a column zoom draws: its view, and set apart as the summary's folded nodes are, what it names without a card
// and the people and site groups that don't connect to a security service.
function columnZoom(
  template: BoardTemplate,
  zoom: CockpitZoom,
  data: BoardData,
  shows: ZoomView["shows"],
  diagram: string,
  lookup: CatalogLookup,
) {
  const ghost = data.entries.some((e) => e.id === zoom.entryId && e.status === "ghost");
  // A ghost's zoom draws from the ghosts too, since it shows here only.
  const shown = ghost ? { entries: data.entries.filter((e) => e.status !== "dismissed") } : live(data);
  const drawn = zoomView(template, shown, shows, zoom.entryId, diagram, lookup, zoom.classes);
  if (!drawn) return null;
  const view = ghost ? quietAll(drawn) : drawn;
  const nodes = nodesAt(template, shown, lookup);
  const self = nodes.find((n) => n.id === zoom.entryId);
  const through = shows === "security" && self ? sizedThrough(nodes, self.id) : null;
  const missed = new Set(
    through
      ? nodes
          .filter((n) => {
            const r = reach(n, through);
            return n.kind === "people" ? !r?.users : n.kind === "site" && !r?.mbps;
          })
          .map((n) => n.id)
      : [],
  );
  const cards = new Set(view.columns.flat().map((c) => c.entry ?? c.id));
  const apart = nodes.filter((n) => n !== self && !cards.has(n.id) && (view.names.includes(n.id) || missed.has(n.id)));
  return { view, ghost, missed, apart };
}

// The entries a zoom shows, whose changes the SE sees without leaving it.
export function zoomShows(template: BoardTemplate, zoom: CockpitZoom, data: BoardData, diagram: string, lookup: CatalogLookup) {
  const { shows } = zoom.template;
  if (shows === "app") return new Set(zoom.entryId ? [zoom.entryId] : []);
  const drawn = columnZoom(template, zoom, data, shows, diagram, lookup);
  if (!drawn) return new Set<string>();
  const { view, apart } = drawn;
  return new Set([
    ...[...view.columns.flat(), ...view.inspected, ...view.tiles].map((c) => c.entry ?? c.id),
    ...apart.map((n) => n.id),
    ...(view.box ? [view.box.id] : []),
  ]);
}

// The tray holds what the room's lines say, so the centre draws the zoom in the summary's cards and the
// room's columns, without the room's measured layout. A card opens the zoom's entry's fields, or confirms a
// ghost's zoom back onto the room, but another entry's card opens that entry's, so the room keeps the zoom.
function ColumnZoom(props: ZoomEditorProps & { shows: ZoomView["shows"] }) {
  const { template, zoom, data, diagram, lookup, shows } = props;
  const drawn = useMemo(() => columnZoom(template, zoom, data, shows, diagram, lookup), [template, zoom, data, shows, diagram, lookup]);
  if (!drawn) return null;
  const { view, ghost, missed, apart } = drawn;
  const entryOf = new Map(data.entries.map((e) => [e.id, e]));
  const own = zoom.entryId ? entryOf.get(zoom.entryId) : undefined;
  const box = view.box && { ...view.box, last: view.box.column + (view.box.span ?? 1) - 1 };
  // An entry can stand in two columns, such as a data center an SD-WAN fabric both carries and reaches, or one on both
  // sides of a security service; only its first card takes its actions.
  const acting = new Set<string>();

  const cardOf = (c: ZoomCard) => {
    const id = c.entry ?? c.id;
    const other = id !== zoom.entryId ? entryOf.get(id) : undefined;
    const target = other ?? own;
    const slot = other && template.slots.find((s) => s.id === other.slot);
    const selected = props.selected === id && id !== box?.id;
    const acts = selected && !!other && !!slot && !acting.has(id);
    if (acts) acting.add(id);
    const ghostCard = other?.status === "ghost";
    return (
      <NodeCard
        key={c.id}
        icon={ghostCard ? <IconGhost className="size-4 shrink-0" /> : <ZoomCardIcon icon={c.icon} className="size-4 shrink-0" />}
        name={c.name}
        count={c.count}
        stats={
          c.stats.length > 0 &&
          c.stats.map((s) => (
            <span key={s.glyph} className="mr-1.5 inline-flex items-center gap-0.5 tabular-nums">
              <ZoomCardIcon icon={{ glyph: s.glyph }} className="size-3" />
              {s.value}
            </span>
          ))
        }
        detail={c.detail.join(" · ")}
        note={!!entryOf.get(id)?.note}
        quiet={c.quiet || ghostCard || missed.has(c.id)}
        label={c.name ? undefined : view.title}
        title={target?.status === "ghost" ? "Show in the room" : c.name ? undefined : view.title}
        selected={selected}
        onClick={() => {
          if (!target) return;
          props.onSelect(target.id);
          // A card of one of the entry's own records, such as a circuit, brings that record's row into view in the tray.
          if (!other && c.id !== own?.id)
            requestAnimationFrame(() => document.querySelector(`[data-record="${c.id}"]`)?.scrollIntoView({ block: "nearest" }));
        }}
      >
        {acts && (
          <EntryActions slot={slot} entry={other} zoomHref={props.zoomHref(other.id)} actions={props.actions} />
        )}
      </NodeCard>
    );
  };
  const n = view.columns.length;
  const header = ghost || view.subtitle.length > 0 || view.inspected.length > 0;
  const topRow = !!box || view.heads.length > 0;

  return (
    <div className="flex max-w-5xl min-w-min flex-col gap-4">
      {header && (
        <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
          {ghost && <IconGhost className="size-4" />}
          {view.subtitle.length > 0 && <span>{whole(view.subtitle.join(" · "))}</span>}
          {view.inspected.length > 0 && (
            <>
              <IconFirewallCheck aria-label="Inspected" className="size-4" />
              {view.inspected.map(cardOf)}
            </>
          )}
        </div>
      )}
      {/* Each column takes two tracks, so the box can end halfway across the next one and a boundary's cards
          straddle its edge, as in the room. That needs the grid gapless and the columns' padding even. An item across
          two flexible tracks has no minimum width of its own, so each column sets one and never narrows below a word. */}
      <div
        className="grid"
        style={{ gridTemplateColumns: `repeat(${2 * n}, 1fr)`, gridTemplateRows: topRow ? "2rem auto auto" : undefined }}
      >
        {box && (
          <div
            className={cn("rounded-xl border-2 border-dashed px-2.5 py-2", props.selected === box.id && selectedClass)}
            style={{ gridColumn: `${2 * box.column + 1} / ${2 * box.last + (box.boundary ? 4 : 3)}`, gridRow: "1 / -1" }}
          >
            <NodeIcon category={box.icon.category} itemId={box.icon.itemId} className="size-4 text-muted-foreground" />
          </div>
        )}
        {view.columns.map((cards, i) => {
          const head = view.heads.find((h) => h.column === i);
          return (
            <div
              key={i}
              className="relative flex min-w-min flex-col justify-center gap-2 self-center p-3"
              style={{ gridColumn: `${2 * i + 1} / span 2`, gridRow: topRow ? 2 : 1 }}
            >
              {head && (
                <div className="absolute inset-x-0 bottom-full flex items-center justify-center gap-1 text-xs whitespace-nowrap text-muted-foreground">
                  <ZoomCardIcon icon={{ glyph: head.glyph }} className="size-3.5" />
                  {head.name}
                </div>
              )}
              {cards.map(cardOf)}
            </div>
          );
        })}
        {box && view.tiles.length > 0 && (
          <div
            className="flex flex-wrap justify-center gap-1.5 px-3 pb-3"
            style={{ gridColumn: `${2 * box.column + 1} / ${2 * box.last + 3}`, gridRow: 3 }}
          >
            {view.tiles.map(cardOf)}
          </div>
        )}
      </div>
      {apart.length > 0 && (
        <div className="flex flex-wrap justify-center gap-2 self-center rounded-xl border-2 border-dashed bg-muted p-1.5">
          {apart.map((node) =>
            cardOf({
              id: node.id,
              name: nodeName(node, lookup),
              icon: { node: { category: node.category, itemId: node.itemId } },
              detail: [],
              count: null,
              stats: [],
              quiet: false,
            }),
          )}
        </div>
      )}
    </div>
  );
}

const ROW_LABELS: Record<AppRow["key"], string> = { models: "Models", tools: "Tools and MCP servers", data: "Data" };

// An AI app's zoom in the room's places, without its lines. Every card opens the app's fields, or confirms a
// ghost's zoom back onto the room, and brings its own field into view; the app's card brings the tray's top.
function AppZoom({ template, zoom, data, lookup, selected, onSelect }: ZoomEditorProps) {
  const entry = data.entries.find((e) => e.id === zoom.entryId);
  const view = useMemo(
    () => entry && appView(template, data, entry.id, lookup, zoom.products),
    [template, data, entry, lookup, zoom.products],
  );
  if (!entry || !view) return null;
  const ghost = entry.status === "ghost";
  const { at } = view;
  const card = (field?: string) => ({
    quiet: ghost,
    title: ghost ? "Show in the room" : undefined,
    selected: false,
    onClick: () => {
      onSelect(entry.id);
      requestAnimationFrame(() => {
        const tray = document.querySelector("[data-field]")?.closest("aside");
        if (!field) tray?.scrollTo({ top: 0 });
        else tray?.querySelector(`[data-field="${field}"]`)?.scrollIntoView({ block: "nearest" });
      });
    },
  });
  // Proposed carries the accent, as a planned coverage does, except on a ghost, which is quiet throughout.
  const capabilities = (...fields: (keyof AppView["at"])[]) =>
    fields.flatMap((field) =>
      at[field].map((p) => {
        const accent = !p.inPlace && !ghost;
        return (
          <NodeCard
            key={`${field}-${p.id}`}
            {...card(field)}
            icon={<IconShieldCheck className={cn("size-4 shrink-0", accent && "text-(--customer)")} />}
            name={p.name}
            detail={p.products.join(" · ") || undefined}
            className={cn(accent && "border-(--customer)")}
          />
        );
      }),
    );
  // Each name is a card of its own, as the room shows each as a chip; with none, a quiet card says what goes there.
  const named = (field: string, names: string[], Icon: typeof IconUsers, label: string) =>
    names.length ? (
      names.map((n) => <NodeCard key={n} {...card(field)} icon={<Icon className="size-4 shrink-0" />} name={n} />)
    ) : (
      <NodeCard {...card(field)} icon={<Icon className="size-4 shrink-0" />} name="" label={label} quiet className="grow" />
    );
  const box = (className: string, ...fields: (keyof AppView["at"])[]) => (
    <div
      className={cn(
        "flex flex-col gap-1.5 rounded-xl border-2 border-dashed p-2",
        selected === entry.id && selectedClass,
        className,
      )}
    >
      <NodeCard
        {...card()}
        icon={<NodeIcon category={view.icon.category} itemId={view.icon.itemId} className="size-4 shrink-0" />}
        name={view.title}
      />
      {capabilities(...fields)}
    </div>
  );
  return (
    <div className="flex min-w-min flex-col gap-4">
      {(ghost || view.subtitle.length > 0) && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          {ghost && <IconGhost className="size-4" />}
          {view.subtitle.length > 0 && <span>{whole(view.subtitle.join(" · "))}</span>}
        </div>
      )}
      {view.kind === "bought" ? (
        <div className={cn("grid grid-rows-3 items-center gap-x-4 gap-y-2", BOUGHT_COLUMNS)}>
          {/* As in the room, the frame ends halfway down the two rows the endpoints' cards share, so they straddle its edge. */}
          <div className="col-start-1 row-span-3 row-start-1 grid grid-rows-[auto_1fr_1fr]">
            <div className="col-start-1 row-span-2 row-start-1 rounded-xl border-2 border-dashed" />
            <div className="col-start-1 row-start-1 flex flex-col gap-1.5 p-2">
              <IconDevices className="size-4 text-muted-foreground" />
              {named("app-users", view.users, IconUsers, "Who uses it")}
            </div>
            {at.endpoints.length > 0 && (
              <div className="col-start-1 row-span-2 row-start-2 flex flex-col gap-1.5 px-2">{capabilities("endpoints")}</div>
            )}
          </div>
          <div className="col-start-2 row-span-3 row-start-1 flex flex-col gap-1.5">{capabilities("access", "prompts")}</div>
          {box("col-start-3 row-span-3 row-start-1", "tenant", "build")}
        </div>
      ) : (
        <div
          className={cn("grid items-center gap-x-4 gap-y-2", BUILT_COLUMNS)}
          style={{ gridTemplateRows: `repeat(${view.rows.length}, minmax(0, 1fr))` }}
        >
          <div className="col-start-1 row-span-full flex flex-col gap-1.5">
            {named("app-users", view.users, IconUsers, "Who uses it")}
          </div>
          <div className="col-start-2 row-span-full flex flex-col gap-1.5">{capabilities("prompts", "access")}</div>
          {box("col-start-3 row-span-full self-stretch", "build", "tenant")}
          {view.rows.map((row, i) => (
            <Fragment key={row.key}>
              <div className="col-start-4 flex flex-col gap-1.5" style={{ gridRowStart: i + 1 }}>
                {capabilities(row.line)}
              </div>
              <div className="col-start-5 flex flex-wrap gap-1.5" style={{ gridRowStart: i + 1 }}>
                {named(row.field, row.names, ROW_ICONS[row.key], ROW_LABELS[row.key])}
              </div>
            </Fragment>
          ))}
        </div>
      )}
    </div>
  );
}
