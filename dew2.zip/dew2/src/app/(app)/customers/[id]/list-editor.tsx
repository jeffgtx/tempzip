"use client";

import { IconChevronDown, IconChevronUp, IconClock, IconGhost, IconNote, IconPlus, IconUser } from "@tabler/icons-react";
import { cn } from "cn";
import { type Entry, entriesIn } from "@/board/model";
import type { BoardTemplate } from "@/content/schema";
import { Button } from "@/components/ui/button";
import type { CockpitActions, EditorProps, Slot } from "./cockpit";
import { DraftInput } from "./draft-input";
import { EntryActions } from "./entry-actions";
import { selectedClass } from "./selected";

type List = Extract<BoardTemplate, { layout: "list" }>;
type Attrs = Entry["attrs"];
const withAttr = (attrs: Attrs, key: string, value: string | number | null): Attrs => {
  const next = { ...attrs };
  if (value) next[key] = value;
  else delete next[key];
  return next;
};

export function ListEditor({
  template,
  data,
  selection,
  label,
  onSelect,
  onAdd,
  actions,
}: EditorProps & { template: List }) {
  const slot = template.slots[0];
  const steps = entriesIn(data, slot.id).filter((e) => e.status !== "dismissed");
  const live = steps.filter((e) => e.status === "live");
  const minutes = live.reduce((sum, e) => sum + ((e.attrs.minutes as number | undefined) ?? 0), 0);
  return (
    <div className="flex max-w-4xl flex-col gap-2">
      <ol className="flex flex-col gap-1.5">
        {steps.map((e) => {
          // A live step is numbered and moved among the live ones, as the room shows them.
          const order = e.status === "live" ? live : steps;
          const at = order.indexOf(e);
          return (
            <Step
              key={e.id}
              slot={slot}
              timing={template.timing}
              entry={e}
              number={e.status === "live" ? at + 1 : null}
              first={at === 0}
              last={at === order.length - 1}
              label={label(e)}
              selected={selection?.entryId === e.id}
              actions={actions}
              onMove={(by) => actions.move(slot, e, by)}
              onSelect={() =>
                e.status === "ghost"
                  ? actions.confirm(e)
                  : onSelect(selection?.entryId === e.id ? null : { slot: slot.id, entryId: e.id })
              }
            />
          );
        })}
      </ol>
      <div className="flex items-center gap-3">
        <Button variant="outline" size="icon-sm" aria-label={`Add to ${slot.name}`} title="Add" onClick={() => onAdd(slot.id)}>
          <IconPlus />
        </Button>
        {minutes > 0 && (
          <span className="flex items-center gap-1 text-sm text-muted-foreground tabular-nums">
            <IconClock className="size-4" />
            {minutes} min
          </span>
        )}
      </div>
    </div>
  );
}

function Step(props: {
  slot: Slot;
  timing: List["timing"];
  entry: Entry;
  number: number | null;
  first: boolean;
  last: boolean;
  label: string;
  selected: boolean;
  actions: CockpitActions;
  onSelect: () => void;
  onMove: (by: -1 | 1) => void;
}) {
  const { entry, actions } = props;
  const owner = entry.attrs.owner as string | undefined;
  const named = owner === "us" || owner === "them" ? "" : (owner ?? "");
  const due = (entry.attrs.due as string | undefined) ?? "";
  const minutes = String(entry.attrs.minutes ?? "");
  const ghost = entry.status === "ghost";
  // Setting a ghost's own value still brings it back.
  const set = (key: string, value: string | number | null) => {
    if (ghost || (entry.attrs[key] ?? null) !== value) actions.setAttrs(entry, withAttr(entry.attrs, key, value));
  };

  return (
    <li
      className={cn(
        "flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-lg border px-3 py-1.5",
        ghost && "border-dashed text-muted-foreground [&_[aria-pressed=true]]:bg-muted-foreground",
        props.selected && selectedClass,
      )}
    >
      <span className="w-5 text-right text-sm text-muted-foreground tabular-nums">{props.number}</span>
      <div className="flex flex-col">
        <Button
          variant="ghost"
          size="icon-xs"
          aria-label="Move up"
          title="Move up"
          disabled={props.first}
          onClick={() => props.onMove(-1)}
          className="h-3.5"
        >
          <IconChevronUp />
        </Button>
        <Button
          variant="ghost"
          size="icon-xs"
          aria-label="Move down"
          title="Move down"
          disabled={props.last}
          onClick={() => props.onMove(1)}
          className="h-3.5"
        >
          <IconChevronDown />
        </Button>
      </div>
      <button
        type="button"
        title={ghost ? "Show in the room" : undefined}
        onClick={props.onSelect}
        className="flex min-w-48 flex-1 items-center gap-1.5 text-left text-sm"
      >
        {ghost && <IconGhost className="size-3.5 shrink-0" />}
        {props.label}
        {entry.note && <IconNote className="size-3.5 shrink-0 text-muted-foreground" aria-label="Has a note" />}
      </button>
      {/* Every row shares out its width the same way, whatever it holds, so the rows' controls line up. */}
      <div className="ml-auto flex grow-2 basis-0 items-center justify-end gap-3">
        <div role="group" aria-label="Owner" className="flex grow basis-0 items-center justify-end gap-1">
          {(["us", "them"] as const).map((who) => (
            <Button
              key={who}
              size="sm"
              variant={owner === who ? "default" : "outline"}
              aria-pressed={owner === who}
              onClick={() => set("owner", who)}
            >
              {who === "us" ? "Us" : "Them"}
            </Button>
          ))}
          <div className="relative min-w-36 max-w-64 grow">
            <IconUser className="absolute top-2 left-2 size-4 text-muted-foreground" />
            <DraftInput
              key={named}
              aria-label="Owner's name"
              maxLength={100}
              value={named}
              onCommit={(value) => set("owner", value.trim() || "us")}
              className={cn("h-7 pl-7", named && (ghost ? "border-muted-foreground" : "border-primary"))}
            />
          </div>
        </div>
        {props.timing === "due" ? (
          <DraftInput
            key={due}
            type="date"
            aria-label="Due"
            value={due}
            onCommit={(value) => set("due", value || null)}
            className="h-7 w-36"
          />
        ) : (
          <div className="relative">
            <IconClock className="absolute top-2 left-2 size-4 text-muted-foreground" />
            <DraftInput
              key={minutes}
              type="number"
              aria-label="Minutes"
              min={1}
              max={999}
              value={minutes}
              onCommit={(value) => {
                const n = Math.round(Number(value));
                set("minutes", n >= 1 ? Math.min(n, 999) : null);
              }}
              className="h-7 w-20 pl-7"
            />
          </div>
        )}
        <span className="w-6">{props.selected && <EntryActions slot={props.slot} entry={entry} actions={actions} />}</span>
      </div>
    </li>
  );
}
