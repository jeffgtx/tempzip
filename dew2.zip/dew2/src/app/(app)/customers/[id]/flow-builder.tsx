"use client";

import { IconApps, IconArrowNarrowRight, IconCornerDownRight, IconGhost, IconPlus, IconWorld } from "@tabler/icons-react";
import { cn } from "cn";
import { useState } from "react";
import { CONNECTION_TYPES, PRISMA_SASE, connectionTypes, kindOf } from "@/board/architecture";
import { DIRECT, type Flow, type Step, type Target, directThrough } from "@/board/flows";
import { type BoardData, type Entry } from "@/board/model";
import { type Named, type SummaryNode, type SummaryView, list } from "@/board/summary";
import type { BoardTemplate } from "@/content/schema";
import { NodeIcon } from "@/components/node-icon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Template = Extract<BoardTemplate, { layout: "hub-and-spoke" }>;
type End = { id?: string; kind: SummaryNode["kind"]; category: string; itemId: string | null };

export type FlowContext = {
  template: Template;
  view: SummaryView;
  data: BoardData;
  catalog: { id: string; name: string; category: string }[];
  onStep: (flowId: string | null, step: Step) => void;
};

// Through points the builder can add: the usual security service, the browser's connector to private apps, and a data
// center, standing in for its firewalls.
const THROUGH_NEW = [PRISMA_SASE.access, "p-prisma-browser-connector", "data-center"];
// What "direct" can reach: a data center, a cloud, SaaS or the internet.
const DIRECT_ENDS: End[] = [
  { kind: "datacenter", category: "data-center", itemId: null },
  { kind: "cloud", category: "cloud-provider", itemId: null },
  { kind: "saas", category: "saas", itemId: null },
  { kind: "internet", category: "internet", itemId: null },
];
// A ZTNA connector carries other people's traffic in to the apps beside it, so it is never how who connects.
const INBOUND = "conn-ztna-connector";

function sources({ template, view, data, catalog }: FlowContext) {
  const slot = template.slots.find((s) => s.id === template.flows)!;
  const refSlots = (key: string) => {
    const a = slot.attributes.find((x) => x.key === key);
    return a?.type === "ref" ? a.slots : [];
  };
  const slotOf = new Map(data.entries.map((e) => [e.id, e.slot]));
  const nodesIn = (slots: string[]) => view.nodes.filter((n) => slots.includes(slotOf.get(n.id) ?? ""));
  const presetsIn = (slots: string[]) => template.slots.filter((s) => slots.includes(s.id)).flatMap((s) => s.presets);
  const item = (id: string) => catalog.find((o) => o.id === id);
  const endOf = (itemId: string): End => {
    const category = item(itemId)?.category ?? "";
    return { kind: kindOf(category), category, itemId };
  };
  const label = (id: string | null) => (id ? (view.nodes.find((n) => n.id === id)?.name ?? item(id)?.name ?? null) : null);
  const attrsOf = (id: string) => data.entries.find((e) => e.id === id)?.attrs ?? {};
  const absent = (itemId: string) => !view.nodes.some((n) => n.itemId === itemId);
  return { refSlots, nodesIn, presetsIn, item, endOf, label, attrsOf, absent };
}

type Chip = { key: string; name: string; icon: React.ReactNode; title?: string; on: boolean; onClick: () => void };

function ChipList({ chips, label }: { chips: Chip[]; label?: string }) {
  return (
    <ul aria-label={label} className="flex flex-wrap gap-1.5">
      {chips.map((c) => (
        <li key={c.key}>
          <Button
            size="sm"
            variant={c.on ? "default" : "outline"}
            aria-pressed={c.on}
            title={c.title}
            className="h-auto rounded-full py-1 text-left whitespace-normal"
            onClick={c.onClick}
          >
            {c.icon}
            {c.name}
          </Button>
        </li>
      ))}
    </ul>
  );
}

// A row of chips: nodes already on the board with their icons, then what can be added.
function Chips(props: { label: string; chips: Chip[]; children?: React.ReactNode }) {
  return (
    <section aria-label={props.label} className="flex flex-col gap-1.5">
      <h3 className="text-xs font-medium text-muted-foreground">{props.label}</h3>
      <ChipList chips={props.chips} />
      {props.children}
    </section>
  );
}

// An app in the customer's words, then where it lives; Enter puts it in the first.
function NewApp(props: { homes: (Omit<Chip, "on" | "onClick"> & { home: End })[]; onPick: (app: string, home: End) => void }) {
  const [name, setName] = useState("");
  const app = name.trim();
  const pick = (home: End) => {
    props.onPick(app, home);
    setName("");
  };
  return (
    <>
      <div className="relative">
        <IconApps className="pointer-events-none absolute top-2 left-2.5 size-4 text-muted-foreground" />
        <Input
          aria-label="New app"
          placeholder="New app"
          title="Type an app, then pick where it lives"
          maxLength={200}
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && app) pick(props.homes[0].home);
          }}
          className="h-8 pl-8"
        />
      </div>
      {app && (
        <div className="flex items-start gap-1.5 pl-2.5">
          <IconCornerDownRight className="mt-1.5 size-4 shrink-0 text-muted-foreground" />
          <ChipList
            label="Where it lives"
            chips={props.homes.map((h) => ({ ...h, title: `${app} in ${h.name}`, on: false, onClick: () => pick(h.home) }))}
          />
        </div>
      )}
    </>
  );
}

const nodeIcon = (n: { category: string; itemId: string | null }) => <NodeIcon category={n.category} itemId={n.itemId} />;
// A node to add: its kind's icon, marked with a plus.
const addIcon = (n: { category: string; itemId: string | null }) => (
  <span className="inline-flex items-start">
    {nodeIcon(n)}
    <IconPlus className="-ml-0.5 size-2.5 stroke-3" />
  </span>
);

function Who({ context, flow }: { context: FlowContext; flow: Flow | null }) {
  const s = sources(context);
  const slots = s.refSlots("who");
  const [more, setMore] = useState(false);
  const pick = (who: Target) => {
    setMore(false);
    context.onStep(flow?.id ?? null, { who });
  };
  const nodes = s.nodesIn(slots);
  const toAdd = s
    .presetsIn(slots)
    .filter(s.absent)
    .map((id) => ({ key: id, name: s.item(id)?.name ?? id, icon: addIcon(s.endOf(id)), on: false, onClick: () => pick({ itemId: id }) }));
  // Once who is picked, those to add wait behind a button, keeping the steps after it in view.
  const folded = nodes.some((n) => n.id === flow?.who) && !more && toAdd.length > 0;
  return (
    <Chips
      label="Who"
      chips={[
        ...nodes.map((n) => ({ key: n.id, name: n.name, icon: nodeIcon(n), on: flow?.who === n.id, onClick: () => pick({ id: n.id }) })),
        ...(folded ? [{ key: "more", name: "", icon: <IconPlus />, title: "More", on: false, onClick: () => setMore(true) }] : toAdd),
      ]}
    />
  );
}

// The steps after who: how they connect, through what, and where the app lives. Each offers only what joins the steps before it.
function Steps({ context, flow, who }: { context: FlowContext; flow: Flow; who: SummaryNode }) {
  const s = sources(context);
  const step = (value: Step) => context.onStep(flow.id, value);
  const throughSlots = s.refSlots("through");
  const whereSlots = s.refSlots("where");
  const fits = (end: End) => !!flow.how && connectionTypes(who, end).includes(flow.how);
  const ends: End[] = [...s.nodesIn([...throughSlots, ...whereSlots]), ...[...THROUGH_NEW, ...s.presetsIn(whereSlots)].map(s.endOf)];
  const types = CONNECTION_TYPES.filter((id) => id !== DIRECT && id !== INBOUND && ends.some((e) => connectionTypes(who, e).includes(id)));
  const through = flow.through ? context.view.nodes.find((n) => n.id === flow.through) : undefined;
  const reaches = (end: End) =>
    through
      ? end.id !== through.id && (connectionTypes(through, end).length > 0 || connectionTypes(end, through).length > 0)
      : flow.how === DIRECT
        ? end.kind === "saas" || end.kind === "internet"
        : fits(end);
  const saasItem = s.presetsIn(whereSlots).find((id) => s.endOf(id).kind === "saas");
  const saas = s.nodesIn(whereSlots).find((n) => n.kind === "saas") ?? (saasItem ? s.endOf(saasItem) : undefined);
  const appsField = context.template.slots
    .find((x) => x.categories.includes(saas?.category ?? ""))
    ?.attributes.find((a) => a.key === "apps");
  const appsOf = (id: string | undefined) => (id ? list<Named>(s.attrsOf(id).apps).flatMap((r) => (r.name ? [r.name] : [])) : []);
  const hosts = s.nodesIn(whereSlots).filter((n) => n.kind === "datacenter" || n.kind === "cloud");
  const hosted = new Set(hosts.flatMap((n) => appsOf(n.id)).map((name) => name.toLowerCase()));
  const elsewhere = (name: string) => !hosted.has(name.toLowerCase());
  // The common business apps, then those named on the SaaS node and in what people need, all living in SaaS unless a data
  // center or cloud hosts one by that name, then those the data centers and clouds host; once each where it lives.
  const common = appsField?.type === "records" ? appsField.presets.map((id) => s.item(id)?.name ?? id) : [];
  const needed = s.nodesIn(s.refSlots("who")).filter((n) => n.kind === "people").flatMap((n) => appsOf(n.id));
  const keyOf = (e: End) => e.id ?? e.itemId!;
  // The data center or cloud the flow goes through can also be where the app lives.
  const via = hosts.filter((n) => n.id === through?.id);
  const apps = [
    ...new Map(
      [
        ...(saas ? [...common.filter(elsewhere), ...appsOf(saas.id), ...needed.filter(elsewhere)].map((name) => ({ name, home: saas })) : []),
        ...hosts.flatMap((home) => appsOf(home.id).map((name) => ({ name, home }))),
      ]
        .filter((a) => reaches(a.home) || via.some((n) => n.id === a.home.id))
        .map((a) => [`${keyOf(a.home)}:${a.name.toLowerCase()}`, a]),
    ).values(),
  ];
  // An app offered in more than one place names where each lives.
  const homesOf = (name: string) => apps.filter((a) => a.name.toLowerCase() === name.toLowerCase()).length;
  const target = (e: End): Target => (e.id ? { id: e.id } : { itemId: e.itemId! });
  // A data center, cloud, SaaS or the internet, on the board or to add, that the steps before reach.
  // An app lives at a site group already drawn; offering every kind of site to add would bury the rest.
  const places = [
    ...s.nodesIn(whereSlots),
    ...s.presetsIn(whereSlots).filter(s.absent).map(s.endOf).filter((e) => e.kind !== "site"),
  ].filter(reaches);
  const placeChip = (e: End) => ({ key: keyOf(e), name: s.label(keyOf(e)) ?? "", icon: e.id ? nodeIcon(e) : addIcon(e) });
  // SaaS comes before the data centers and clouds the steps reach, so Enter puts an app reached through a security service in SaaS.
  const homes = [...via, ...places.filter((p) => p.kind === "saas"), ...places.filter((p) => p.kind === "datacenter" || p.kind === "cloud")].map(
    (home) => ({ ...placeChip(home), home }),
  );
  return (
    <>
      <Chips
        label="How"
        chips={[
          ...types.map((id) => ({ key: id, name: s.item(id)?.name ?? id, icon: null, on: flow.how === id, onClick: () => step({ how: id }) })),
          { key: DIRECT, name: "Direct", icon: <IconWorld />, on: flow.how === DIRECT, onClick: () => step({ how: DIRECT }) },
        ]}
      />
      {flow.how && flow.how !== DIRECT && (
        <Chips
          label="Through"
          chips={[
            ...s
              .nodesIn(throughSlots)
              .filter(fits)
              .map((n) => ({ key: n.id, name: n.name, icon: nodeIcon(n), on: flow.through === n.id, onClick: () => step({ through: { id: n.id } }) })),
            ...THROUGH_NEW.filter((id) => s.absent(id) && fits(s.endOf(id))).map((id) => ({
              key: id,
              name: s.item(id)?.name ?? id,
              icon: addIcon(s.endOf(id)),
              on: false,
              onClick: () => step({ through: { itemId: id } }),
            })),
            // Direct is the through point until another is picked.
            ...(DIRECT_ENDS.some(fits)
              ? [{ key: "direct", name: "Direct", icon: <IconArrowNarrowRight />, on: !flow.through, onClick: () => step({ through: null }) }]
              : []),
          ]}
        />
      )}
      {flow.how && (
        <Chips
          label="Where"
          chips={[
            ...places.map((p) => ({ ...placeChip(p), on: flow.where === p.id && !flow.app, onClick: () => step({ where: target(p) }) })),
            ...apps.map(({ name, home }) => {
              const at = s.label(keyOf(home)) ?? undefined;
              return {
                key: `${keyOf(home)}:${name.toLowerCase()}`,
                name: homesOf(name) > 1 ? `${name} · ${at}` : name,
                icon: nodeIcon(home),
                title: at,
                on: flow.where === home.id && flow.app?.toLowerCase() === name.toLowerCase(),
                onClick: () => step({ where: target(home), app: name }),
              };
            }),
          ]}
        >
          {homes.length > 0 && <NewApp homes={homes} onPick={(app, home) => step({ where: target(home), app })} />}
        </Chips>
      )}
    </>
  );
}

// A saved flow's steps. A step's chips show once the steps it hangs on are picked.
export function FlowSteps({ context, flow }: { context: FlowContext; flow: Flow }) {
  const who = context.view.nodes.find((n) => n.id === flow.who);
  return (
    <>
      <Who context={context} flow={flow} />
      {who && <Steps context={context} flow={flow} who={who} />}
    </>
  );
}

// The saved flows, each with its steps on a line, and a new flow starting from who.
export function FlowList(props: {
  context: FlowContext;
  entries: Entry[];
  onOpen: (entry: Entry) => void;
}) {
  // With no flows yet, the tray opens on a new one.
  const [adding, setAdding] = useState(props.entries.length === 0);
  const s = sources(props.context);
  return (
    <>
      <ul className="flex flex-col gap-1">
        {props.entries.map((e) => {
          const ghost = e.status === "ghost";
          const a = e.attrs as Record<string, string | undefined>;
          const steps = [
            s.label(a.who ?? null),
            a.how === DIRECT ? "Direct" : s.label(a.how ?? null),
            directThrough(e.attrs) ? "Direct" : s.label(a.through ?? null),
            a.app ?? s.label(a.where ?? null),
          ].filter(Boolean);
          const [who, ...rest] = steps;
          const where = rest.pop();
          const middle = rest.join(" · ");
          return (
            <li key={e.id}>
              <button
                type="button"
                onClick={() => props.onOpen(e)}
                className={cn(
                  "flex w-full flex-col rounded-lg border px-3 py-2 text-left hover:bg-muted",
                  ghost && "border-dashed text-muted-foreground",
                )}
              >
                <span className="flex items-center gap-2 text-sm font-medium">
                  {ghost && <IconGhost className="size-4" aria-label="Ghost" />}
                  {e.text}
                </span>
                {/* Who and where tell flows apart, so the middle steps, with their separator, give way first. */}
                <span className="flex min-w-0 gap-1 text-xs whitespace-nowrap text-muted-foreground">
                  <span className="min-w-0 truncate">{who}</span>
                  {middle && <span className="min-w-0 shrink-[1e6] truncate">· {middle}</span>}
                  {where && (
                    <>
                      <span>·</span>
                      <span className="min-w-0 truncate">{where}</span>
                    </>
                  )}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      {adding ? (
        <Who context={props.context} flow={null} />
      ) : (
        <Button
          variant="outline"
          size="icon-sm"
          className="self-start"
          aria-label="New flow"
          title="New flow"
          onClick={() => setAdding(true)}
        >
          <IconPlus />
        </Button>
      )}
    </>
  );
}
