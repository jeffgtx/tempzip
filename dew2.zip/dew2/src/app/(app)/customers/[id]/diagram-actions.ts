"use server";

import { z } from "zod";
import { requireUser } from "@/auth/current";
import { addDiagram, deleteDiagram } from "@/board/data";
import { diagramName } from "@/board/model";
import { runningMeeting } from "@/meetings/data";

const id = z.uuid();

// Each returns whether it took effect, or the new diagram's id.
export async function addDiagramAction(customerId: string, templateId: string, input: { name: string; copyOf?: string }) {
  const user = await requireUser();
  const parsed = z.object({ name: diagramName, copyOf: id.optional() }).safeParse(input);
  if (!id.safeParse(customerId).success || !parsed.success) return null;
  const meeting = await runningMeeting(user.id, customerId);
  return addDiagram(user.id, customerId, templateId, parsed.data, meeting?.id ?? null);
}

export async function deleteDiagramAction(customerId: string, diagramId: string) {
  const user = await requireUser();
  if (!id.safeParse(customerId).success || !id.safeParse(diagramId).success) return false;
  return deleteDiagram(user.id, customerId, diagramId);
}
