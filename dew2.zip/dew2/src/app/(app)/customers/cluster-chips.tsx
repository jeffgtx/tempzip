export type ClusterOption = { id: string; name: string };

export function ClusterChips({ clusters, ids }: { clusters: ClusterOption[]; ids: string[] }) {
  return (
    <ul className="flex flex-wrap gap-1">
      {clusters
        .filter((c) => ids.includes(c.id))
        .map((c) => (
          <li key={c.id} className="rounded-md bg-muted px-2 py-0.5 text-xs text-muted-foreground">
            {c.name}
          </li>
        ))}
    </ul>
  );
}
