"use client";

import { IconCheck, IconX } from "@tabler/icons-react";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { approveAction, rejectAction } from "./actions";

export function SuggestionForm(props: { id: string; name: string; aliases: string[]; category: string }) {
  const [state, approve, pending] = useActionState(approveAction.bind(null, props.id), {});
  return (
    <form action={approve} className="flex flex-col gap-2 p-3">
      <div className="flex items-center gap-1">
        <Input
          key={state.name}
          name="name"
          aria-label="Name"
          defaultValue={state.name ?? props.name}
          required
          maxLength={200}
          className="flex-1"
        />
        <Button type="submit" size="icon" disabled={pending} aria-label={`Approve ${props.name}`} title="Approve">
          <IconCheck />
        </Button>
        <Button
          type="submit"
          formAction={rejectAction.bind(null, props.id)}
          formNoValidate
          disabled={pending}
          variant="ghost"
          size="icon"
          aria-label={`Reject ${props.name}`}
          title="Reject"
        >
          <IconX />
        </Button>
      </div>
      <Input
        key={state.aliases}
        name="aliases"
        aria-label="Aliases"
        placeholder="Aliases, comma separated"
        defaultValue={state.aliases ?? props.aliases.join(", ")}
      />
      <span className="text-xs text-muted-foreground">{props.category}</span>
      {state.error && (
        <p role="alert" className="text-sm text-destructive">
          {state.error}
        </p>
      )}
    </form>
  );
}
