import { pendingSuggestions } from "@/catalog/suggestions";
import { getContent } from "@/content/load";
import { SuggestionForm } from "./suggestion-form";

export default async function AdminPage() {
  const suggestions = await pendingSuggestions();
  const categories = new Map(getContent().categories.map((c) => [c.id, c.name]));
  if (!suggestions.length) return null;
  return (
    <section aria-label="Suggestions" className="flex flex-col gap-2">
      <h2 className="text-sm font-medium text-muted-foreground">Suggestions</h2>
      <ul className="flex flex-col divide-y rounded-xl border">
        {suggestions.map((s) => (
          <li key={s.id}>
            <SuggestionForm {...s} category={categories.get(s.category) ?? s.category} />
          </li>
        ))}
      </ul>
    </section>
  );
}
