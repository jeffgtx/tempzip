"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { approveSuggestion, proposal, rejectSuggestion } from "@/catalog/suggestions";

// A refused approval hands back what the admin typed, since the form resets.
export type ReviewState = { error?: string; name?: string; aliases?: string };

export async function approveAction(suggestionId: string, _: ReviewState, form: FormData): Promise<ReviewState> {
  const typed = { name: String(form.get("name") ?? ""), aliases: String(form.get("aliases") ?? "") };
  const edit = proposal.safeParse({ name: typed.name, aliases: typed.aliases.split(",") });
  if (!z.uuid().safeParse(suggestionId).success) return {};
  if (!edit.success) return { ...typed, error: "A name, and up to 20 aliases of 100 characters each." };
  const refused = await approveSuggestion(suggestionId, edit.data);
  revalidatePath("/admin");
  return refused ? { ...typed, error: refused } : {};
}

export async function rejectAction(suggestionId: string) {
  if (z.uuid().safeParse(suggestionId).success) await rejectSuggestion(suggestionId);
  revalidatePath("/admin");
}
