import { requireUser } from "@/auth/current";
import { getContent } from "@/content/load";
import { listCustomers } from "@/customers/data";
import { CustomerList } from "./customer-list";

export default async function HomePage() {
  const user = await requireUser();
  const clusters = getContent().clusters.map(({ id, name }) => ({ id, name }));
  return <CustomerList customers={await listCustomers(user.id)} clusters={clusters} />;
}
