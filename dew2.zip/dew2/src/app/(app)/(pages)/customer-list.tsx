"use client";

import { IconPlus, IconSearch } from "@tabler/icons-react";
import Link from "next/link";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ClusterChips, type ClusterOption } from "../customers/cluster-chips";
import { CustomerDialog } from "../customers/customer-dialog";

type Customer = { id: string; name: string; accent: string | null; clusters: string[] };

export function CustomerList({ customers, clusters }: { customers: Customer[]; clusters: ClusterOption[] }) {
  const [query, setQuery] = useState("");
  const shown = customers.filter((c) => c.name.toLowerCase().includes(query.trim().toLowerCase()));

  return (
    <>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <IconSearch className="absolute top-2 left-2.5 size-4 text-muted-foreground" />
          <Input
            type="search"
            aria-label="Search customers"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-8"
          />
        </div>
        <CustomerDialog clusters={clusters}>
          <Button size="icon" aria-label="New customer" title="New customer">
            <IconPlus />
          </Button>
        </CustomerDialog>
      </div>
      <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((c) => (
          <li key={c.id}>
            <Link
              href={`/customers/${c.id}`}
              className="flex h-full flex-col gap-2 rounded-xl border border-l-4 p-4 transition-colors hover:bg-muted/50"
              style={c.accent ? { borderLeftColor: c.accent } : undefined}
            >
              <span className="font-medium">{c.name}</span>
              <ClusterChips clusters={clusters} ids={c.clusters} />
            </Link>
          </li>
        ))}
      </ul>
    </>
  );
}
