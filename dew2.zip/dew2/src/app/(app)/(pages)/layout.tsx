import { IconUserShield } from "@tabler/icons-react";
import Link from "next/link";
import { pendingSuggestions } from "@/catalog/suggestions";
import { Button } from "@/components/ui/button";

export default async function AppLayout({ children }: LayoutProps<"/">) {
  const waiting = (await pendingSuggestions().limit(1)).length > 0;
  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6 px-6 pb-12">
      <header className="flex h-14 items-center justify-between">
        <Link href="/" className="text-lg font-semibold tracking-tight">
          dew
        </Link>
        <nav className="flex items-center gap-1">
          <Button asChild variant="ghost" size="icon" className="relative">
            <Link href="/admin" aria-label={waiting ? "Admin, suggestions waiting" : "Admin"} title="Admin">
              <IconUserShield />
              {waiting && <span className="absolute top-0.5 right-0.5 size-2.5 rounded-full bg-destructive ring-2 ring-background" />}
            </Link>
          </Button>
        </nav>
      </header>
      {children}
    </div>
  );
}
