import { IconShieldCheckered, IconWorld } from "@tabler/icons-react";
import { cn } from "cn";
import { type Ref, type RefObject, useLayoutEffect, useRef } from "react";
import { DATACENTERS, place } from "@/board/architecture";
import type { Zone } from "@/board/attributes";
import { type Badge, type Service, type SummaryLine, type SummaryNode, type SummaryView, framed } from "@/board/summary";
import { BadgeIconFor, NodeIcon } from "@/components/node-icon";
import { whole } from "@/components/whole";
import { focusClass } from "./room-canvas";
import { Logo } from "./room-frame";
import { GAP, type Label, type Point, ROUND, type Rect, STYLES, curve, narrow, placeLabels } from "./room-lines";

const W = 1920;
const H = 1080;
const PAD = 64;
const TOP_Y = 150;
const BAND = [300, 850];
const HUB = { x: 660, y: 370, w: 600, h: 400 };
const HUB_BOX: Box = { ...HUB, zone: "hub" };
// A line label is at most 160px wide (max-w-40), and may sit beside its line by just over half that. At two lines
// it is this tall.
const LABEL_REACH = 88;
const LABEL_H = 45;
// Beneath the bottom row, the labels of the runs there sit in a tier under the nodes, a line of text GAP
// clear of the nodes and of the runs, which nest below it; the deepest keeps RIM above the canvas' edge.
const TIER = GAP + 24 + GAP;
const RIM = 24;
// Labels keep half the margin the nodes keep, so one can sit beneath the bottom row, or over a loop at its ends.
const MARGIN: Rect = { x: PAD / 2, y: PAD / 2, w: W - PAD, h: H - PAD };
// How far a lit box's focus outline reaches past its edge at the overview's 16px, where focusClass keeps to its floors,
// and how far it lifts the box.
const OUTLINE = { reach: 8, lift: 3 };
const SIZES = {
  // A full node holds its name, a line of detail and a row of badges.
  full: { top: [320, 136], left: [360, 140], right: [360, 140], bottom: [380, 150] },
  compact: { top: [256, 76], left: [320, 76], right: [320, 76], bottom: [256, 76] },
} as const;

type Box = Rect & { zone: Zone | "hub" };
type Side = "left" | "right" | "top" | "bottom";
type Size = (typeof SIZES)[keyof typeof SIZES];

const LOCAL = "conn-local-internet";

function boxes(view: SummaryView) {
  const placement = place(view.nodes, view.hub);
  const size = SIZES[placement.compact ? "compact" : "full"];
  const at = new Map<string, Box>();
  const more = new Map<Zone, Box>();
  for (const zone of ["top", "left", "right", "bottom"] as Zone[]) {
    const ids = [...placement.zones[zone], ...(placement.folded[zone] ? ["more"] : [])];
    const [w, h] = size[zone];
    const n = ids.length;
    ids.forEach((id, i) => {
      let box: Box;
      if (zone === "top" || zone === "bottom") {
        const gap = Math.min(48, (W - 2 * PAD - n * w) / Math.max(1, n - 1));
        const start = (W - (n * w + (n - 1) * gap)) / 2;
        box = { x: start + i * (w + gap), y: zone === "top" ? TOP_Y : H - PAD - h, w, h, zone };
      } else {
        const gap = Math.min(40, (BAND[1] - BAND[0] - n * h) / Math.max(1, n - 1));
        const start = (BAND[0] + BAND[1] - (n * h + (n - 1) * gap)) / 2;
        box = { x: zone === "left" ? PAD : W - PAD - w, y: start + i * (h + gap), w, h, zone };
      }
      if (id === "more") more.set(zone, box);
      else at.set(id, box);
    });
    for (const id of placement.folded[zone] ?? []) at.set(id, more.get(zone)!);
  }
  for (const id of placement.hub) at.set(id, HUB_BOX);
  // Data centers outside the hub are drawn as the one group node.
  for (const n of view.nodes) if (n.kind === "datacenter" && !at.has(n.id)) at.set(n.id, at.get(DATACENTERS)!);
  // A grouped node draws as its lead, so lines to either meet the group and a line between them isn't drawn.
  for (const n of view.nodes) if (n.group && !at.has(n.id) && at.has(n.group.lead)) at.set(n.id, at.get(n.group.lead)!);
  return { placement, at, more, size };
}

// Raises the bottom row as far as the runs beneath it and their labels' tier need, but by no more than the
// margin, nor than leaves the street above it, which holds the row's lines to the hub, a lane CLEAR of the hub
// and of what `reach`es up into it from the row, such as globes and loops and their labels; past that, the runs
// close up, though always below the tier and never nearer than TIGHT. Gives the streets, and how far below the
// row each run beneath it runs.
function rise(all: Box[], size: Size, depth: (number | null)[], reach: number) {
  const deepest = Math.max(0, ...depth.flatMap((d) => d ?? []));
  const street = H - PAD - size.bottom[1] - (HUB.y + HUB.h);
  const least = TIER - (PAD - RIM);
  const room = Math.max(least + deepest * TIGHT, street - reach - 2 * CLEAR);
  const lift = depth.every((d) => d === null) ? 0 : Math.min(PAD, least + deepest * LANE, room);
  const step = Math.min(LANE, (PAD - RIM + lift - TIER) / Math.max(1, deepest));
  for (const b of new Set(all)) if (b.zone === "bottom") b.y -= lift;
  const column = (zone: Zone) => all.some((b) => b.zone === zone);
  const streets: Streets = {
    left: column("left") ? PAD + size.left[0] : PAD,
    right: column("right") ? W - PAD - size.right[0] : W - PAD,
    gapLeft: [PAD + size.left[0], HUB.x],
    gapRight: [HUB.x + HUB.w, W - PAD - size.right[0]],
    top: [TOP_Y + size.top[1], HUB.y],
    bottom: [HUB.y + HUB.h, H - PAD - size.bottom[1] - lift],
  };
  return { streets, below: depth.map((d) => (d === null ? null : TIER + d * step)) };
}

// Runs beneath the bottom row nest: the narrowest first, each takes the lane below those of the runs it meets,
// so one whose span holds another's runs deeper and their legs don't cross. Runs meeting at a node take
// different lanes too, so they don't read as one line passing under it. Gives each its lane, counting down.
function nest(ends: [Box, Box][]) {
  const runs = ends.flatMap(([a, b], i) =>
    a.zone === "bottom" && b.zone === "bottom" ? [{ i, span: [center(a).x, center(b).x].sort((p, q) => p - q) }] : [],
  );
  const depth: (number | null)[] = ends.map(() => null);
  const placed: typeof runs = [];
  for (const run of runs.sort((p, q) => p.span[1] - p.span[0] - (q.span[1] - q.span[0]))) {
    const met = placed.filter((o) => o.span[0] <= run.span[1] && run.span[0] <= o.span[1]);
    depth[run.i] = 1 + Math.max(-1, ...met.map((o) => depth[o.i]!));
    placed.push(run);
  }
  return depth;
}

// The open runs beside the rows and columns: the columns' inner edges, and the bands of the
// gaps either side of the hub and of the streets above and below the middle band.
type Band = [number, number];
type Streets = { left: number; right: number; gapLeft: Band; gapRight: Band; top: Band; bottom: Band };
const mid = ([lo, hi]: Band) => (lo + hi) / 2;

const center = (b: Box) => ({ x: b.x + b.w / 2, y: b.y + b.h / 2 });
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const NORMAL: Record<Side, [number, number]> = { left: [-1, 0], right: [1, 0], top: [0, -1], bottom: [0, 1] };

// Where a line leaves a box toward another: the facing side, at its middle, or for the
// larger box in line with the smaller one but INSET from its corners, then moved to the line's port.
const INSET = 24;
function anchor(box: Box, other: Box, side: Side, offset: number) {
  const along = side === "left" || side === "right" ? "y" : "x";
  const size = along === "y" ? "h" : "w";
  const own = box[size] > other[size] ? clamp(center(other)[along], box[along] + INSET, box[along] + box[size] - INSET) : center(box)[along];
  const p = along === "y" ? { x: side === "left" ? box.x : box.x + box.w, y: own + offset } : { x: own + offset, y: side === "top" ? box.y : box.y + box.h };
  return p;
}

// A spoke's lines leave from its side facing the hub, so they never cross the spokes beside it.
const INWARD: Record<Zone, Side> = { left: "right", right: "left", top: "bottom", bottom: "top" };
const facing = (box: Box, side: Side): Side => (box.zone === "hub" ? side : INWARD[box.zone]);

// A line between a spoke and the hub curves straight in from the spoke's port.
function route(a: Box, b: Box, port: Port) {
  const ca = center(a);
  const cb = center(b);
  const dx = cb.x - ca.x;
  const dy = cb.y - ca.y;
  const across = Math.abs(dx) * 0.6 > Math.abs(dy);
  const sa = facing(a, across ? (dx > 0 ? "right" : "left") : dy > 0 ? "bottom" : "top");
  const sb = facing(b, across ? (dx > 0 ? "left" : "right") : dy > 0 ? "top" : "bottom");
  const offset = a.zone === "hub" ? port(b, sb, a) : port(a, sa, b);
  const p0 = anchor(a, b, sa, offset);
  const p3 = anchor(b, a, sb, offset);
  const d = Math.max(40, Math.hypot(p3.x - p0.x, p3.y - p0.y) * 0.4);
  const p1 = { x: p0.x + NORMAL[sa][0] * d, y: p0.y + NORMAL[sa][1] * d };
  const p2 = { x: p3.x + NORMAL[sb][0] * d, y: p3.y + NORMAL[sb][1] * d };
  return curve(p0, p1, p2, p3);
}

// Lines between two spokes, and lines from a destination or site group the side columns
// overhang, run along the streets and turn at rounded corners, since a curve would cross
// the hub or the nodes beside it. Any other line to the hub curves straight in.
function streetRoute(a: Box, b: Box, s: Streets, lane: Lane, port: Port) {
  const row = (box: Box) => box.zone === "top" || box.zone === "bottom";
  const overhangs = (box: Box) => row(box) && (center(box).x < s.left || center(box).x > s.right);
  if ((a.zone === "hub" || b.zone === "hub") && !overhangs(a) && !overhangs(b)) return null;
  const [e, o] = row(a) ? [a, b] : [b, a];
  return row(e) ? fromRow(e, o, s, lane, port) : betweenColumns(e, o, s, lane, port);
}

// Takes the lane for a run along a channel (a street, a gap or a way into a hub corner): a
// coordinate across the given axis within the channel's band, for the stretch the run spans.
type Lane = (channel: string, across: "x" | "y", band: Band, span: [number, number], prefer?: number, side?: 1 | -1) => number;
// Where along a box's side a line meets it, as an offset from the side's middle.
type Port = (box: Box, side: Side, other: Box) => number;

const LANE = 14;
// Runs any nearer than this, at their 4px width, read as one line.
const TIGHT = 6;
const CLEAR = 12;
const PORT = 18;

// A run takes a lane in a stretch of the band that the obstacles reaching into the channel, such as nodes, globes
// and loops, leave open along its span: of the stretches with room for a lane CLEAR of them, the one nearest where
// it would rather run, else nearest the band's middle; failing that, the widest. There it takes where it would
// rather run, else the stretch's middle, keeping LANE from the runs beside it and CLEAR of the obstacles, or where
// the stretch is too full, as far from both as it can. A run kept to a `side` of those beside it (-1 lower, 1
// higher) first takes the nearest whole lane that way. With nothing open, it takes the band's middle.
function lanes(obstacles: Rect[]): Lane {
  const taken = new Map<string, { at: number; from: number; to: number }[]>();
  return (channel, across, band, [p, q], want, side) => {
    const [from, to] = [Math.min(p, q), Math.max(p, q)];
    let open = [band];
    for (const r of obstacles) {
      const [s0, s1, c0, c1] = across === "y" ? [r.x, r.x + r.w, r.y, r.y + r.h] : [r.y, r.y + r.h, r.x, r.x + r.w];
      if (s1 <= from || s0 >= to) continue;
      open = open.flatMap(([lo, hi]): Band[] => [[lo, Math.min(hi, c0)], [Math.max(lo, c1), hi]]).filter(([lo, hi]) => hi > lo);
    }
    const target = want ?? mid(band);
    const width = ([lo, hi]: Band) => hi - lo;
    const off = ([lo, hi]: Band) => Math.max(0, lo + CLEAR - target, target - hi + CLEAR);
    const roomy = open.filter((b) => width(b) >= 2 * CLEAR).sort((a, b) => off(a) - off(b));
    const [lo, hi] = roomy[0] ?? open.sort((a, b) => width(b) - width(a))[0] ?? [mid(band), mid(band)];
    const inset = Math.min(CLEAR, (hi - lo) / 2);
    const prefer = clamp(want ?? (lo + hi) / 2, lo + inset, hi - inset);
    // Runs that overlap, allowing for the corners they turn.
    const beside = (taken.get(channel) ?? []).filter((r) => r.from < to + 24 && r.to > from - 24).map((r) => r.at);
    const room = (v: number) => Math.min(LANE, ...beside.map((u) => Math.abs(u - v)), ((v - lo) * LANE) / CLEAR, ((hi - v) * LANE) / CLEAR);
    let at = prefer;
    for (let v = prefer; side && v >= lo && v <= hi && room(at) < LANE; v += 2 * side) if (room(v) === LANE) at = v;
    for (let d = 2; d <= hi - lo && room(at) < LANE; d += 2)
      for (const v of [prefer - d, prefer + d]) if (v >= lo && v <= hi && room(v) > room(at)) at = v;
    taken.set(channel, [...(taken.get(channel) ?? []), { at, from, to }]);
    return at;
  };
}

const sideKey = (box: Box, side: Side) => `${box.x},${box.y},${side}`;

type Outlet = Rect & { box: Box };

// How far the ports along a box's side shift: the least that keeps them CLEAR of what sits out from that side, such
// as its globes and loops and their labels, and INSET from its corners; none where no shift does.
function shift(box: Box, side: Side, fan: number[], outlets: Outlet[]) {
  const [axis, size] = side === "top" || side === "bottom" ? (["x", "w"] as const) : (["y", "h"] as const);
  const out = (r: Rect) =>
    side === "top" ? r.y + r.h <= box.y : side === "bottom" ? r.y >= box.y + box.h : side === "left" ? r.x + r.w <= box.x : r.x >= box.x + box.w;
  const taken = outlets.filter((r) => r.box === box && out(r)).map((r) => [r[axis] - CLEAR, r[axis] + r[size] + CLEAR]);
  if (!taken.length) return 0;
  const fits = (d: number) =>
    fan.every((o) => {
      const p = center(box)[axis] + o + d;
      return p >= box[axis] + INSET && p <= box[axis] + box[size] - INSET && taken.every(([lo, hi]) => p < lo || p > hi);
    });
  for (let d = 0; d <= box[size]; d += 2) for (const s of [d, -d]) if (fits(s)) return s;
  return 0;
}

// Routes each pair of boxes, given how far below the bottom row each run beneath it runs. Lines meeting a
// node side spread along it in the order of where they lead, so they don't cross at the node, clear of the
// globes and loops out of it; that takes a first pass to find them. Lines round the hub take their lanes
// last, so they can keep inside the lines that turn off the gaps into the side columns.
function routes(pairs: [Box, Box][], s: Streets, nodes: Rect[], outlets: Outlet[], below: (number | null)[]) {
  const row = (box: Box) => box.zone === "top" || box.zone === "bottom";
  const around = ([a, b]: [Box, Box]) => row(a) && row(b) && a.zone !== b.zone;
  const order = pairs.map((_, i) => i).sort((i, j) => Number(around(pairs[i])) - Number(around(pairs[j])));
  const build = (port: (i: number) => Port, lane: Lane) => {
    const one = (i: number) => {
      const [a, b] = pairs[i];
      if (below[i] !== null) return beneath(a, b, below[i], port(i));
      const points = streetRoute(a, b, s, lane, port(i));
      if (!points) {
        const c = route(a, b, port(i));
        return { ...c, track: c.along };
      }
      return { path: rounded(points), mid: longest(points), along: sample(points), track: points };
    };
    const built: ReturnType<typeof one>[] = [];
    for (const i of order) built[i] = one(i);
    return built;
  };
  const meeting = new Map<string, { i: number; box: Box; side: Side; from: number; toward: number; length: number }[]>();
  build(
    (i) => (box, side, other) => {
      const axis = side === "top" || side === "bottom" ? "x" : "y";
      const k = sideKey(box, side);
      const entry = { i, box, side, from: center(box)[axis], toward: center(other)[axis], length: axis === "x" ? box.w : box.h };
      meeting.set(k, [...(meeting.get(k) ?? []), entry]);
      return 0;
    },
    (_channel, _across, band) => mid(band),
  );
  // Runs beneath the bottom row leave a node as nested brackets: those heading left, then those heading
  // right, the deeper of each nearer the others. Lines headed the same way keep their own order, not the
  // order they take lanes in.
  const heading = (m: { from: number; toward: number }) => Math.sign(m.toward - m.from);
  const offsets = new Map<string, number>();
  for (const [k, list] of meeting) {
    const step = Math.min(PORT, (list[0].length - 2 * INSET) / Math.max(1, list.length - 1));
    const fan = list.map((_, j) => (j - (list.length - 1) / 2) * step);
    const d = shift(list[0].box, list[0].side, fan, outlets);
    [...list]
      .sort(
        (p, q) =>
          (below[p.i] === null ? p.toward - q.toward : heading(p) - heading(q) || heading(p) * (below[q.i]! - below[p.i]!)) ||
          p.i - q.i,
      )
      .forEach(({ i }, j) => offsets.set(`${i}|${k}`, fan[j] + d));
  }
  return build((i) => (box, side) => offsets.get(`${i}|${sideKey(box, side)}`) ?? 0, lanes([...nodes, ...outlets]));
}

// A run beneath the bottom row drops from each node through the labels' tier to its lane. Its label sits on
// its drop from the node it leaves, else elsewhere under that node, as it passes under others.
function beneath(a: Box, b: Box, below: number, port: Port) {
  const edge = a.y + a.h;
  const [ax, bx] = [center(a).x + port(a, "bottom", b), center(b).x + port(b, "bottom", a)];
  const y = edge + below;
  const track = [
    { x: ax, y: edge },
    { x: ax, y },
    { x: bx, y },
    { x: bx, y: edge },
  ];
  const along = sample(track).filter((p) => Math.abs(p.x - center(a).x) <= a.w / 2 - LABEL_REACH);
  return { path: rounded(track), mid: { x: ax, y: edge + TIER / 2 }, along, track };
}

// In a street above the hub too narrow to hold a label either side of a run along its middle, runs out of the top row
// to other spokes keep to the row's side, leaving the hub's side to the runs into the hub and to the labels of those
// runs and of the lines that curve up into the row from the hub.
const hugs = (box: Box, s: Streets) => (box.zone === "top" && s.top[1] - s.top[0] < 2 * (LABEL_H + GAP) ? s.top[0] : undefined);

function fromRow(e: Box, o: Box, s: Streets, lane: Lane, port: Port): Point[] {
  if (o.zone === e.zone) {
    // Along the top row's street.
    const edge = e.y + e.h;
    const ex = center(e).x + port(e, "bottom", o);
    const ox = center(o).x + port(o, "bottom", e);
    const y = lane("top", "y", s.top, [ex, ox], hugs(e, s));
    return [
      { x: ex, y: edge },
      { x: ex, y },
      { x: ox, y },
      { x: ox, y: edge },
    ];
  }
  const street = (box: Box) => (box.zone === "top" ? "top" : "bottom");
  const side = (box: Box): Side => (box.zone === "top" ? "bottom" : "top");
  const edge = (box: Box) => (box.zone === "top" ? box.y + box.h : box.y);
  const ex = center(e).x + port(e, side(e), o);
  if (o.zone === "hub") {
    // Into the hub's near corner, so lines from both sides stay apart, but a lane inside the curves
    // anchored there (INSET in, give or take their ports), so it doesn't run in beside them. A node's
    // later lines take street lanes above its first, so their drops nest rather than cross by stepping
    // inward from the top row and outward from the bottom one. The band ends CLEAR past the corner
    // since a lane keeps CLEAR of its band's ends.
    const left = center(e).x < W / 2;
    const corner = left ? o.x + INSET + PORT + LANE : o.x + o.w - INSET - PORT - LANE;
    const y = lane(street(e), "y", s[street(e)], [ex, corner]);
    const into = e.zone === "top" ? o.y : o.y + o.h;
    const band: Band = left === (e.zone === "top") ? [corner - CLEAR, o.x + o.w] : [o.x, corner + CLEAR];
    const x = lane(`hub ${street(e)} ${left}`, "x", band, [y, into], corner);
    return [{ x: ex, y: edge(e) }, { x: ex, y }, { x, y }, { x, y: into }];
  }
  if (o.zone === "left" || o.zone === "right") {
    const gap = o.zone === "left" ? "gapLeft" : "gapRight";
    const y = lane(street(e), "y", s[street(e)], [ex, mid(s[gap])], hugs(e, s));
    const oy = center(o).y + port(o, INWARD[o.zone], e);
    const x = lane(gap, "x", s[gap], [y, oy]);
    return [{ x: ex, y: edge(e) }, { x: ex, y }, { x, y }, { x, y: oy }, { x: o.zone === "left" ? o.x + o.w : o.x, y: oy }];
  }
  // Round the hub by whichever gap makes the shorter run, on the hub's side of the lanes already taken, so it runs
  // inside the lines that turn off the gap into a side column rather than cross them where they turn.
  const run = (gap: Band) => Math.abs(center(e).x - mid(gap)) + Math.abs(center(o).x - mid(gap));
  const gap = run(s.gapLeft) <= run(s.gapRight) ? "gapLeft" : "gapRight";
  const hubward = (box: Box) => (box.zone === "top" ? 1 : -1);
  const ox = center(o).x + port(o, side(o), e);
  const y1 = lane(street(e), "y", s[street(e)], [ex, mid(s[gap])], hugs(e, s), hubward(e));
  const y2 = lane(street(o), "y", s[street(o)], [ox, mid(s[gap])], hugs(o, s), hubward(o));
  const x = lane(gap, "x", s[gap], [y1, y2], undefined, gap === "gapLeft" ? 1 : -1);
  return [{ x: ex, y: edge(e) }, { x: ex, y: y1 }, { x, y: y1 }, { x, y: y2 }, { x: ox, y: y2 }, { x: ox, y: edge(o) }];
}

// Between the side columns: out to the gaps beside the hub, and across along the
// street nearer them when the columns differ.
function betweenColumns(e: Box, o: Box, s: Streets, lane: Lane, port: Port): Point[] {
  const gap = (box: Box) => (box.zone === "left" ? "gapLeft" : "gapRight");
  const inner = (box: Box) => (box.zone === "left" ? box.x + box.w : box.x);
  const ey = center(e).y + port(e, INWARD[e.zone as Zone], o);
  const oy = center(o).y + port(o, INWARD[o.zone as Zone], e);
  if (e.zone === o.zone) {
    const x = lane(gap(e), "x", s[gap(e)], [ey, oy]);
    return [{ x: inner(e), y: ey }, { x, y: ey }, { x, y: oy }, { x: inner(o), y: oy }];
  }
  const street = (ey + oy) / 2 < center(HUB_BOX).y ? "top" : "bottom";
  const y = lane(street, "y", s[street], [mid(s[gap(e)]), mid(s[gap(o)])]);
  const ex = lane(gap(e), "x", s[gap(e)], [ey, y]);
  const ox = lane(gap(o), "x", s[gap(o)], [oy, y]);
  return [{ x: inner(e), y: ey }, { x: ex, y: ey }, { x: ex, y }, { x: ox, y }, { x: ox, y: oy }, { x: inner(o), y: oy }];
}

function rounded(points: Point[], radius = ROUND) {
  const p = points.filter((q, i) => i === 0 || q.x !== points[i - 1].x || q.y !== points[i - 1].y);
  let path = `M ${p[0].x} ${p[0].y}`;
  for (let i = 1; i < p.length - 1; i++) {
    const [prev, at, next] = [p[i - 1], p[i], p[i + 1]];
    const into = Math.hypot(at.x - prev.x, at.y - prev.y);
    const out = Math.hypot(next.x - at.x, next.y - at.y);
    const r = Math.min(radius, into / 2, out / 2);
    path += ` L ${at.x - ((at.x - prev.x) / into) * r} ${at.y - ((at.y - prev.y) / into) * r}`;
    path += ` Q ${at.x} ${at.y} ${at.x + ((next.x - at.x) / out) * r} ${at.y + ((next.y - at.y) / out) * r}`;
  }
  return `${path} L ${p.at(-1)!.x} ${p.at(-1)!.y}`;
}

// Points every few pixels along a street route, where its label may sit.
// Each run's middle is among them: the spot furthest from both its turns.
function sample(points: Point[]) {
  return points.slice(1).flatMap((b, i) => {
    const a = points[i];
    const n = Math.max(1, Math.round(Math.hypot(b.x - a.x, b.y - a.y) / 8));
    const ts = Array.from({ length: n }, (_, k) => k / n);
    if (n % 2) ts.splice((n + 1) / 2, 0, 0.5);
    return ts.map((t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }));
  });
}

// A street route's label prefers its longest run.
function longest(points: Point[]) {
  let best = { x: points[0].x, y: points[0].y, length: -1 };
  for (let i = 1; i < points.length; i++) {
    const [a, b] = [points[i - 1], points[i]];
    const length = Math.hypot(b.x - a.x, b.y - a.y);
    if (length > best.length) best = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, length };
  }
  return { x: best.x, y: best.y };
}

// A local breakout: a short stub ending in a globe, clear of the lines to the hub. A row's leaves its
// outer corner into the street. A column's leaves its inner side into the gap beside the hub, since
// the gaps between stacked nodes can't hold a globe clear of both, above where its lines leave: just
// inside a full node's top, as a globe reaching into the narrow street above a full column leaves its
// lines one lane between them; level with a compact node's top, whose lines leave nearer it, or with
// its bottom when it sits below the hub, since its lines then rise to the hub.
function stub(box: Box, compact: boolean): { from: Point; to: Point; toward: Side } {
  if (box.zone === "left" || box.zone === "right") {
    const toward = INWARD[box.zone];
    const x = toward === "right" ? box.x + box.w : box.x;
    const y = !compact ? box.y + 16 : center(box).y > HUB.y + HUB.h ? box.y + box.h : box.y;
    return { from: { x, y }, to: { x: x + 24 * NORMAL[toward][0], y }, toward };
  }
  const toward = box.zone === "top" ? "bottom" : "top";
  const x = box.zone === "bottom" ? box.x + box.w - 40 : box.x + 40;
  const from = { x, y: toward === "top" ? box.y : box.y + box.h };
  return { from, to: { x, y: from.y + 24 * NORMAL[toward][1] }, toward };
}

// A box's breakouts, such as those of the groups folded into "+N more", line up from its stub's end
// the way the stub runs, each with its own globe.
const FLOW: Record<Side, string> = { right: "gap-4", left: "flex-row-reverse gap-4", top: "flex-col-reverse", bottom: "flex-col" };

// A site group's links among its own sites loop out of its node from the end of the side its breakout stub
// leaves free, clear of its lines to the hub; a box's further loops step in along that side, as all of them do
// by `inset` past another node's globe.
const LOOP = { foot: 10, width: 26, reach: 40, step: 36 };
type Loop = ReturnType<typeof curve> & { base: Point; out: Point; away: Point };
function loop(box: Box, compact: boolean, i: number, inset = 0): Loop {
  const { from, toward } = stub(box, compact);
  const axis = toward === "left" || toward === "right" ? "y" : "x";
  const mid = center(box)[axis];
  const end = clamp(2 * mid - from[axis], box[axis] + 16, box[axis] + box[axis === "y" ? "h" : "w"] - 16);
  const sign = Math.sign(end - mid);
  const base = { ...from, [axis]: end - sign * (inset + i * LOOP.step) };
  const out = { x: NORMAL[toward][0], y: NORMAL[toward][1] };
  const away = axis === "y" ? { x: 0, y: sign } : { x: sign, y: 0 };
  const p = (t: number, n: number) => ({ x: base.x + away.x * t + out.x * n, y: base.y + away.y * t + out.y * n });
  return { base, out, away, ...curve(p(-LOOP.foot, 0), p(-LOOP.width, LOOP.reach), p(LOOP.width, LOOP.reach), p(LOOP.foot, 0)) };
}

// Where a loop's label of a given size may centre: beside it along its node's side, away from where the node's other
// lines leave and, unlike a spot past its tip, out of the street they run along, yet as clear of the node as labels
// keep; failing that, past its tip, from there over to just still over it toward the node's middle, as further that
// way it would read as the label of the node's globe or of the lines leaving there.
function beside({ base, out, away }: Loop, w: number, h: number) {
  const extent = (u: Point) => (Math.abs(u.x) * w + Math.abs(u.y) * h) / 2;
  const at = (t: number, n: number) => ({ x: base.x + away.x * t + out.x * n, y: base.y + away.y * t + out.y * n });
  const side = [0, 8, 16, 24].map((k) => at(20 + extent(away) + k, 16 + h / 2));
  const over: Point[] = [];
  for (let t = 20 + extent(away); t >= 12 - extent(away); t -= 8) over.push(at(t, LOOP.reach + extent(out)));
  return [...side, ...over];
}

export function RoomSummary({ view, logoUrl }: { view: SummaryView; logoUrl: string | null }) {
  const { placement, at, more, size } = boxes(view);
  const byId = new Map(view.nodes.map((n) => [n.id, n]));
  const membersOf = (id: string) => view.nodes.filter((n) => n.group?.lead === id);
  const outside = view.nodes.filter((n) => n.kind === "datacenter" && !placement.hub.includes(n.id));
  const pairs = new Map<string, SummaryLine[]>();
  // A picked flow lights its nodes and lines, a line drawn as one with its twin lighting both, and dims the rest.
  const lit = view.flow;
  const litLines = new Set(lit?.lines);
  const litBoxes = new Set(lit?.nodes.flatMap((id) => at.get(id) ?? []));
  const glow = (on: boolean) => (!lit ? undefined : on ? focusClass : "opacity-30");
  // A data center's links leave from the hub's edge when it sits in the hub, and a
  // link between two nodes drawn as one box isn't drawn. A local breakout is always a stub, and a site group's
  // link among its own sites a loop. Alike lines between the same two boxes, such as a site's SD-WAN to both
  // data centers in the hub, draw as one, as do alike breakouts or loops of one box.
  const own = (line: SummaryLine) => line.to === line.from;
  for (const line of view.lines) {
    const from = at.get(line.from);
    const to = line.type === LOCAL || own(line) ? null : line.to ? at.get(line.to) : undefined;
    if (!from || to === undefined || from === to) continue;
    const key = to ? [from, to].map((b) => `${b.x},${b.y}`).sort().join("|") : `${own(line) ? "loop" : "stub"}:${from.x},${from.y}`;
    const group = pairs.get(key) ?? [];
    const twin = group.findIndex((l) => l.type === line.type && l.label === line.label);
    if (twin < 0) group.push(line);
    else if (litLines.has(line.id)) litLines.add(group[twin].id);
    pairs.set(key, group);
  }
  const lines = [...pairs.values()].flat();
  const spokes = lines.filter((l) => l.type !== LOCAL && !own(l));
  const ends = spokes.map((l): [Box, Box] => [at.get(l.from)!, at.get(l.to!)!]);
  // The breakouts and loops out of each box as it stands, and what of them lanes keep clear of.
  const outlets = () => {
    const stubs = [...new Set(lines.filter((l) => l.type === LOCAL).map((l) => at.get(l.from)!))].map((box) => ({
      box,
      breakouts: lines.filter((l) => l.type === LOCAL && at.get(l.from) === box),
      ...stub(box, placement.compact),
    }));
    // Lanes keep clear of the globes' labels too, which run from the globe away from the node. A column's
    // globes sit level with an edge of their node, so lanes take them as reaching along its side, and a
    // street the node reaches into passes them as it does the node, not between them and it.
    const globes = stubs.map(({ box, breakouts, to, toward }) => {
      const sizes = breakouts.map((l) => 40 + 10 * l.label.length);
      if (toward === "left" || toward === "right") {
        const w = sizes.reduce((a, b) => a + 16 + b);
        const [top, bottom] = [Math.min(box.y, to.y - 16), Math.max(box.y + box.h, to.y + 16)];
        return { box, x: toward === "left" ? to.x + 16 - w : to.x - 16, y: top, w, h: bottom - top };
      }
      const h = 36 * sizes.length - 4;
      return { box, x: to.x - 16, y: toward === "top" ? to.y + 16 - h : to.y - 16, w: Math.max(...sizes), h };
    });
    // A row's globe label runs toward the next node, so a loop there steps in past it.
    const inset = (box: Box, n: number) => {
      let d = 0;
      for (let pass = 0; pass <= n * globes.length; pass++) {
        const push = Array.from({ length: n }, (_, i) => loop(box, placement.compact, i, d)).flatMap(({ along, away }) => {
          const xs = along.map((p) => p.x);
          const ys = along.map((p) => p.y);
          const r = { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
          return globes.flatMap((g) => {
            const meets = g.box !== box && r.x < g.x + g.w + GAP && g.x - GAP < r.x + r.w && r.y < g.y + g.h + GAP && g.y - GAP < r.y + r.h;
            if (!meets) return [];
            const [lo, size] = away.x ? (["x", "w"] as const) : (["y", "h"] as const);
            return [away[lo] < 0 ? g[lo] + g[size] + GAP - r[lo] : r[lo] + r[size] - g[lo] + GAP];
          });
        });
        if (!push.length) break;
        d += Math.max(...push);
      }
      return d;
    };
    const loops = lines.filter(own).map((line, _, all) => {
      const box = at.get(line.from)!;
      const mine = all.filter((l) => at.get(l.from) === box);
      return { line, box, ...loop(box, placement.compact, mine.indexOf(line), inset(box, mine.length)) };
    });
    // And of the loops and their labels, taken where a label of that many characters would rather sit.
    const looped = loops.flatMap((l) => {
      const [w, h] = [Math.min(160, 16 + 10 * l.line.label.length), 24];
      const spots = beside(l, w, h);
      const inside = ({ x, y }: Point) => Math.abs(x - MARGIN.x - MARGIN.w / 2) <= (MARGIN.w - w) / 2 && Math.abs(y - MARGIN.y - MARGIN.h / 2) <= (MARGIN.h - h) / 2;
      const spot = spots.find(inside) ?? spots[0];
      const xs = l.along.map((p) => p.x);
      const ys = l.along.map((p) => p.y);
      const [x, y] = [Math.min(...xs), Math.min(...ys)];
      return [
        { box: l.box, x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y },
        { box: l.box, x: spot.x - w / 2, y: spot.y - h / 2, w, h },
      ];
    });
    return { stubs, loops, around: [...globes, ...looped] };
  };
  const reach = Math.max(0, ...outlets().around.flatMap((r) => (r.box.zone === "bottom" ? [r.box.y - r.y] : [])));
  const { streets, below } = rise([...at.values(), ...more.values()], size, nest(ends), reach);
  const { stubs, loops, around } = outlets();
  // An empty hub still shows, as a placeholder lines and labels keep clear of.
  const nodes = [...new Set([HUB_BOX, ...at.values(), ...more.values()])];
  const paths = routes(ends, streets, nodes, around, below);
  const style = (line: SummaryLine) => STYLES[line.type ?? ""] ?? { color: "#a1a1aa" };
  const dim = (line: SummaryLine) => !!lit && !litLines.has(line.id);
  const drawn = [
    ...spokes.map((line, i) => ({ line, d: paths[i].path, on: litLines.has(line.id) })),
    ...stubs.map(({ breakouts: [line, ...rest], from, to }) => ({
      line,
      d: `M ${from.x} ${from.y} L ${to.x} ${to.y}`,
      on: [line, ...rest].some((l) => litLines.has(l.id)),
    })),
    ...loops.map(({ line, path }) => ({ line, d: path, on: litLines.has(line.id) })),
  ];

  // Labels settle on their lines once their real sizes are known, and again once the fonts are in. Every line
  // drawn is in the way of the labels but its own; a loop's label sits beside it, never on it.
  const root = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const settle = () => {
      if (!root.current) return;
      const rect = (el: HTMLElement) => ({ x: el.offsetLeft, y: el.offsetTop, w: el.offsetWidth, h: el.offsetHeight });
      const texts = [...root.current.querySelectorAll<HTMLElement>("[data-fixed]")].map(rect);
      const labels = [...root.current.querySelectorAll<HTMLElement>("[data-label]")];
      labels.forEach(narrow);
      const track = (el: HTMLElement): Label => {
        const [i, w, h] = [Number(el.dataset.label), el.offsetWidth, el.offsetHeight];
        if (i < paths.length) return { w, h, ...paths[i] };
        const loop = loops[i - paths.length];
        const along = beside(loop, w, h);
        return { w, h, mid: along[0], along, beside: true, track: loop.along };
      };
      const tracks = [...paths.map((p) => p.track), ...stubs.map((s) => [s.from, s.to]), ...loops.map((l) => l.along)];
      const outlined = nodes.map((b) =>
        litBoxes.has(b)
          ? { x: b.x - OUTLINE.reach, y: b.y - OUTLINE.reach - OUTLINE.lift, w: b.w + 2 * OUTLINE.reach, h: b.h + 2 * OUTLINE.reach }
          : b,
      );
      const spots = placeLabels(labels.map(track), [...outlined, ...texts], tracks, MARGIN);
      labels.forEach((el, i) => Object.assign(el.style, { left: `${spots[i].x}px`, top: `${spots[i].y}px` }));
    };
    settle();
    void document.fonts.ready.then(settle);
  });

  return (
    <div ref={root} className="relative h-full">
      <header data-fixed className="absolute top-12 left-16 flex h-20 items-center">
        <div>
          <h2 className="text-5xl font-semibold">{view.name}</h2>
          {lit && <p className="text-2xl text-neutral-400">{lit.name}</p>}
        </div>
      </header>
      {logoUrl && <Logo url={logoUrl} className="absolute top-12 right-16" />}
      <svg className="absolute inset-0" width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
        {/* A lit line's halo lies under every line, so it hides none that crosses it. */}
        {drawn
          .filter(({ on }) => lit && on)
          .map(({ line, d }) => (
            <path
              key={`halo ${line.id}`}
              d={d}
              fill="none"
              strokeWidth={(style(line).width ?? 4) + 12}
              strokeLinecap="round"
              strokeOpacity={0.6}
              style={{ stroke: "var(--room-accent)", filter: "blur(2px)" }}
            />
          ))}
        {drawn.map(({ line, d, on }) => (
          <path
            key={line.id}
            d={d}
            fill="none"
            stroke={style(line).color}
            strokeWidth={(style(line).width ?? 4) + (lit && on ? 2 : 0)}
            strokeDasharray={style(line).dash}
            strokeLinecap="round"
            opacity={lit && !on ? 0.3 : undefined}
          />
        ))}
      </svg>
      {placement.hub.length > 0 ? (
        <Hub box={HUB_BOX} nodes={placement.hub.map((id) => byId.get(id)!)} glow={glow} lit={(id) => !!lit?.nodes.includes(id)} />
      ) : (
        <div className="absolute rounded-3xl border-2 border-dashed border-white/10" style={frame(HUB_BOX)} />
      )}
      {[...at.entries()]
        .filter(([id, box]) => box.zone !== "hub" && byId.has(id) && byId.get(id)!.kind !== "datacenter" && !byId.get(id)!.group)
        .filter(([id]) => !Object.values(placement.folded).some((ids) => ids?.includes(id)))
        .map(([id, box]) => {
          const members = membersOf(id);
          const node = byId.get(id)!;
          return (
            <Node
              key={id}
              box={box}
              node={members.length ? framed(node, members) : node}
              compact={placement.compact}
                  className={glow(litBoxes.has(box))}
            />
          );
        })}
      {outside.length > 0 && at.get(DATACENTERS) && (
        <Node
          box={at.get(DATACENTERS)!}
          node={group(outside)}
          compact={placement.compact}
          className={glow(litBoxes.has(at.get(DATACENTERS)!))}
        />
      )}
      {[...more.entries()].map(([zone, box]) => (
        <div
          key={zone}
          className={cn(
            "absolute flex items-center justify-center rounded-2xl border-2 border-white/15 bg-[#151518] text-[26px] font-semibold",
            glow(litBoxes.has(box)),
          )}
          style={frame(box)}
        >
          +{placement.folded[zone]!.length} more
        </div>
      ))}
      {/* Labels sit above the nodes they run past. The first globe sits on the stub's end, with its label beside it,
      wrapping where it meets the canvas' edge. A dimmed label or globe dims only its content, so its backdrop still masks
      the line beneath. */}
      {stubs.map(({ breakouts, to, toward }) => (
        <div
          key={breakouts[0].id}
          data-fixed
          className={cn("absolute flex gap-1 text-lg", FLOW[toward], breakouts.every(dim) ? "text-neutral-300/30" : "text-neutral-300")}
          style={{
            ...(toward === "left" ? { right: W - to.x - 16 } : { left: to.x - 16 }),
            ...(toward === "top" ? { bottom: H - to.y - 16 } : { top: to.y - 16 }),
          }}
        >
          {breakouts.map((line) => (
            <span key={line.id} className={cn("flex items-center gap-2", toward === "left" && "flex-row-reverse")}>
              <IconWorld
                className="size-8 shrink-0 rounded-full bg-[#0b0b0d]"
                strokeOpacity={breakouts.every(dim) ? 0.3 : undefined}
                style={{ color: style(line).color }}
              />
              {line.label}
            </span>
          ))}
        </div>
      ))}
      {/* Near the canvas' right edge an absolute box shrinks, so labels keep their own width to measure true. */}
      {[...spokes.map((line, i) => ({ line, spot: paths[i].mid })), ...loops.map(({ line, mid }) => ({ line, spot: mid }))].map(
        ({ line, spot }, i) =>
          line.label && (
            <div
              key={line.id}
              data-label={i}
              className={cn(
                "absolute w-max max-w-40 -translate-x-1/2 -translate-y-1/2 rounded-md bg-[#0b0b0d] px-2 text-center text-lg leading-tight text-balance",
                dim(line) ? "text-neutral-300/30" : "text-neutral-300",
              )}
              style={{ left: spot.x, top: spot.y }}
            >
              {line.label}
            </div>
          ),
      )}
    </div>
  );
}

// The data centers outside the hub, as one node with their badges added up.
function group(dcs: SummaryNode[]): SummaryNode {
  const badges = new Map<string, Badge & { n: number }>();
  for (const b of dcs.flatMap((d) => d.badges)) {
    const [label, times] = b.label.split(" ×");
    const prior = badges.get(label);
    badges.set(label, { ...b, label, n: (prior?.n ?? 0) + Number(times ?? 1) });
  }
  return {
    ...dcs[0],
    id: DATACENTERS,
    name: dcs.length > 1 ? "Data centers" : dcs[0].name,
    count: dcs.length > 1 ? dcs.length : null,
    detail: dcs.length > 1 ? [dcs.map((d) => d.name).join(" · ")] : dcs[0].detail,
    badges: [...badges.values()].map(({ n, ...b }) => ({ ...b, label: n > 1 ? `${b.label} ×${n}` : b.label })),
  };
}

const frame = (box: { x: number; y: number; w: number; h: number }) => ({
  left: box.x,
  top: box.y,
  width: box.w,
  height: box.h,
});

// A long name steps down in size, then takes two lines, before it's cut short.
const FIT = [
  [1, 1],
  [0.93, 1],
  [0.86, 1],
  [0.86, 2],
  [0.79, 2],
  [0.71, 2],
] as const;
type Step = readonly [scale: number, lines: number];

// Steps the font size of `box` from `base` until the line-clamped `el` fits, among the steps that leave
// the rest `room`; failing that, the smallest of those cuts it short.
function fit(el: HTMLElement, box: HTMLElement, base: number, room: () => boolean, steps: readonly Step[]) {
  const breaks = (anywhere: boolean) => {
    el.style.overflowWrap = anywhere ? "anywhere" : "";
    for (const token of el.querySelectorAll("span")) token.style.whiteSpace = anywhere && token.offsetWidth > el.clientWidth ? "normal" : "";
  };
  breaks(false);
  const apply = ([scale, lines]: Step) => {
    const size = Math.round(base * scale);
    box.style.fontSize = `${size}px`;
    el.style.webkitLineClamp = String(lines);
    return size;
  };
  let last = steps[0];
  for (const step of steps) {
    const size = apply(step);
    if (!room()) continue;
    last = step;
    // Glyphs reach a little past their lines, so only a part-line more counts as cut off.
    if (el.scrollWidth <= el.clientWidth && el.scrollHeight - el.clientHeight < size / 2) return;
  }
  apply(last);
  // Only a word wider than the node breaks, hyphenated or not, so the cut shows an ellipsis.
  breaks(true);
}

// The last line of detail, such as the apps a node lists, steps down and takes two lines too, while the node has
// room. Without room for it, the lines before it, such as a cloud's region count, which its zoom names, give way.
function useFitLast(detail: RefObject<HTMLElement | null>, base: number, room: (line: HTMLElement) => boolean) {
  useLayoutEffect(() => {
    const line = detail.current?.lastElementChild as HTMLElement | null;
    if (!line) return;
    const before = [...detail.current!.children].slice(0, -1) as HTMLElement[];
    fit(line, line, base, () => room(line), FIT);
    if (before.length && !room(line)) {
      for (const el of before) el.hidden = true;
      fit(line, line, base, () => room(line), FIT);
    }
    // Cleanups run before the next render's fits, so the name, which fits first, meets this line at its own size.
    return () => {
      for (const el of before) el.hidden = false;
      Object.assign(line.style, { fontSize: "", webkitLineClamp: "" });
    };
  });
}

// A Detail line has room while it stays in the first column, in view.
const inView = (line: HTMLElement) => line.offsetLeft === line.parentElement!.offsetLeft;

// Fits the name, stepping the font size of `box` or of the name itself.
export function useFit<T extends HTMLElement>(base: number, room = () => true, steps: readonly Step[] = FIT) {
  const box = useRef<T>(null);
  const name = useRef<HTMLSpanElement>(null);
  useLayoutEffect(() => fit(name.current!, box.current ?? name.current!, base, room, steps));
  return { box, name };
}

function Node(props: { box: Box; node: SummaryNode; compact: boolean; className?: string }) {
  const { box, node, compact } = props;
  const count = node.count === null ? null : `${node.kind === "people" ? "" : "×"}${node.count.toLocaleString("en-US")}`;
  const detail = useRef<HTMLDivElement>(null);
  // The name keeps the first line of detail in view, such as the users per site.
  const { box: row, name } = useFit<HTMLDivElement>(
    28,
    () => !detail.current || detail.current.clientHeight >= detail.current.firstElementChild!.clientHeight,
  );
  useFitLast(detail, 20, inView);
  return (
    <div
      className={cn(
        "absolute flex flex-col rounded-2xl border-2 border-white/15 bg-[#151518]",
        compact ? "justify-center px-5" : "gap-1 px-5 py-3",
        props.className,
      )}
      style={frame(box)}
    >
      <div ref={row} className="flex shrink-0 items-center gap-[0.43em] text-[28px] leading-tight font-semibold">
        <NodeIcon category={node.category} itemId={node.itemId} className="size-[1.3em] shrink-0 text-neutral-300" />
        <span ref={name} className="line-clamp-1 flex-1">
          {whole(node.name)}
        </span>
        {count && <span className="tabular-nums">{count}</span>}
      </div>
      {!compact && node.detail.length > 0 && (
        <Detail ref={detail} lines={node.detail} className="text-xl leading-snug *:last:line-clamp-1 *:last:whitespace-normal" />
      )}
      {!compact && <Badges badges={node.badges} services={node.services} />}
    </div>
  );
}

// Lines that don't fit drop whole, badges keeping their row: each line takes the full width, so one
// past the height wraps into a second column the overflow hides, and the empty ::before lets even
// the first line wrap away.
export function Detail({ lines, className, ref }: { lines: string[]; className: string; ref?: Ref<HTMLDivElement> }) {
  return (
    <div ref={ref} className={cn("flex min-h-0 flex-col flex-wrap gap-x-8 overflow-hidden text-neutral-400 before:w-full", className)}>
      {lines.map((d) => (
        <p key={d} className="w-full shrink-0 truncate">
          {d}
        </p>
      ))}
    </div>
  );
}

const BADGE = "flex items-center gap-1.5 rounded-lg border-2 border-white/15 bg-white/[0.06] px-2.5 text-lg whitespace-nowrap";

// Badges, then services, keep to one row, unless told to wrap; those that don't fit are counted in a last "+N".
function Badges({ badges, services, wrap = false }: { badges: Badge[]; services: Service[]; wrap?: boolean }) {
  const list = useRef<HTMLUListElement>(null);
  const all = [...badges, ...services];
  useLayoutEffect(() => {
    if (wrap || !all.length) return;
    const items = [...list.current!.children] as HTMLElement[];
    const more = items.pop()!;
    for (const li of items) li.hidden = false;
    more.hidden = true;
    // The list moves down as its second row goes, so each pass compares with its top anew.
    const ul = list.current!;
    let shown = items.findIndex((li) => li.offsetTop > ul.offsetTop);
    if (shown < 0) return;
    more.hidden = false;
    for (; shown >= 0; shown--) {
      items.forEach((li, i) => (li.hidden = i >= shown));
      more.textContent = `+${items.length - shown}`;
      if (more.offsetTop === ul.offsetTop) break;
    }
  });
  if (!all.length) return null;
  return (
    <ul ref={list} className="mt-auto flex shrink-0 flex-wrap gap-2">
      {badges.map((b) => (
        <li key={b.id} title={b.label} className={cn(BADGE, "max-w-full")}>
          <BadgeIconFor icon={b.icon} className="size-5 shrink-0" />
          <span className="truncate">{b.label}</span>
        </li>
      ))}
      {services.map((s) => (
        <li key={s.id} title={s.label} className={cn(BADGE, "min-h-8 px-1.5")}>
          <NodeIcon category="security-function" itemId={s.itemId} className="size-5" />
        </li>
      ))}
      {!wrap && <li hidden className={BADGE} />}
    </ul>
  );
}

// The hub shows its data centers as tiles, in three columns past four; past six, the last tile counts the rest.
// A security service and what's grouped with it stack, lead on top. A picked flow lights the tiles on its path,
// or the whole hub when it shows one node or the flow passes none of its tiles.
function Hub(props: { box: Box; nodes: SummaryNode[]; glow: (on: boolean) => string | undefined; lit: (id: string) => boolean }) {
  const { box, nodes, glow } = props;
  const lit = (ns: SummaryNode[]) => ns.some((n) => props.lit(n.id));
  const group = nodes.find((n) => n.group)?.group;
  const [only] = nodes.length === 1 ? nodes : [];
  const tiles = nodes.length > 6 ? nodes.slice(0, 5) : nodes;
  const three = nodes.length > 4;
  const tiled = !only && lit(nodes);
  return (
    <div
      className={cn("absolute flex flex-col gap-5 rounded-3xl border-2 border-white/25 bg-[#1b1b20] p-6", !tiled && glow(lit(nodes)))}
      style={frame(box)}
    >
      {only ? (
        <Only node={only} />
      ) : (
        <>
          <div className="flex items-center gap-3 text-[30px] font-semibold">
            {group ? (
              <>
                <IconShieldCheckered className="size-9 shrink-0 text-neutral-200" />
                {group.name}
              </>
            ) : (
              `Data centers ×${nodes.length}`
            )}
          </div>
          <div className={cn("grid min-h-0 flex-1 auto-rows-fr", group ? "grid-cols-1 gap-4" : three ? "grid-cols-3 gap-2" : "grid-cols-2 gap-4")}>
            {tiles.map((n) => (
              <Tile key={n.id} node={n} narrow={three} className={tiled ? glow(lit([n])) : undefined} />
            ))}
            {nodes.length > tiles.length && (
              <div
                className={cn(
                  "flex items-center justify-center rounded-2xl border-2 border-white/15 bg-[#151518] text-2xl font-semibold",
                  tiled && glow(lit(nodes.slice(tiles.length))),
                )}
              >
                +{nodes.length - tiles.length} more
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

// One security service or data center is the hub itself.
function Only({ node }: { node: SummaryNode }) {
  const { name } = useFit(34);
  const detail = useRef<HTMLDivElement>(null);
  // The line has room while the hub, its offset parent, still holds everything.
  useFitLast(detail, 24, (line) => line.offsetParent!.scrollHeight <= line.offsetParent!.clientHeight);
  return (
    <div className="my-auto flex min-w-0 flex-col gap-4">
      <div className="flex items-center gap-4">
        {node.kind === "security" ? (
          <IconShieldCheckered className="size-11 shrink-0 text-neutral-200" />
        ) : (
          <NodeIcon category={node.category} itemId={node.itemId} className="size-11 shrink-0 text-neutral-200" />
        )}
        <span ref={name} className="line-clamp-1 text-[34px] leading-tight font-semibold">
          {node.name}
        </span>
      </div>
      {node.detail.length > 0 && (
        <div ref={detail} className="flex flex-col gap-4 text-2xl text-neutral-400 *:last:line-clamp-1 *:not-last:truncate">
          {node.detail.map((d) => (
            <p key={d}>{d}</p>
          ))}
        </div>
      )}
      <Badges badges={node.badges} services={node.services} wrap />
    </div>
  );
}

function Tile({ node, narrow, className }: { node: SummaryNode; narrow: boolean; className?: string }) {
  const { name } = useFit(24);
  const detail = useRef<HTMLDivElement>(null);
  useFitLast(detail, 18, inView);
  return (
    <div
      className={cn(
        "flex min-h-0 min-w-0 flex-col gap-1 overflow-hidden rounded-2xl border-2 border-white/15 bg-[#151518]",
        narrow ? "p-3" : "p-4",
        className,
      )}
    >
      <div className="flex shrink-0 items-center gap-2">
        <NodeIcon category={node.category} itemId={node.itemId} className="size-7 shrink-0 text-neutral-300" />
        <span ref={name} className="line-clamp-1 text-2xl leading-tight font-semibold">
          {node.name}
        </span>
      </div>
      {node.detail.length > 0 && (
        <Detail ref={detail} lines={node.detail} className="text-lg leading-snug *:last:line-clamp-1 *:last:whitespace-normal" />
      )}
      <Badges badges={node.badges} services={node.services} />
    </div>
  );
}
