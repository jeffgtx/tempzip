import { cn } from "cn";
import { Fragment } from "react";
import type { BoardView, ViewEntry, ViewSlot } from "@/board/view";
import { CoverageIcon } from "@/components/coverage-icon";
import { MARK, MarkIcon } from "@/components/mark-icon";
import { VERDICT, VerdictIcon } from "@/components/verdict-icon";
import { focusClass, useFit } from "./room-canvas";
import { Frame } from "./room-frame";

// The strip and the rows step down together, from one size on every board and group, so a board's groups read alike.
// Neither shrinks below its chips, or a crowded strip would spill over the rows unseen by the fit.
export function RoomGrid({ board, logoUrl }: { board: Extract<BoardView, { layout: "grid" }>; logoUrl: string | null }) {
  const fit = useFit<HTMLDivElement>(28);
  return (
    <Frame logoUrl={logoUrl} title={board.name}>
      <div ref={fit} className="flex h-full flex-col gap-[0.85em] *:shrink-0">
        {board.strip && <Named slot={board.strip} />}
        {board.columns ? <Columns board={board} columns={board.columns} /> : <Cells board={board} />}
      </div>
    </Frame>
  );
}

// The template's rows and columns, each slot a cell named above its entries and only as tall as they
// need. A crowded row takes the height it needs.
function Cells({ board }: { board: Extract<BoardView, { layout: "grid" }> }) {
  return (
    <div className="grid content-start gap-[0.7em]" style={{ gridTemplateRows: `repeat(${board.rows.length}, auto)` }}>
      {board.rows.map((row, i) => (
        <div key={i} className="grid gap-[0.7em]" style={{ gridTemplateColumns: `repeat(${row.length}, minmax(0, 1fr))` }}>
          {row.map((slot) => (
            <Named key={slot.id} slot={slot} />
          ))}
        </div>
      ))}
    </div>
  );
}

// A slot as a cell named above its entries.
function Named({ slot }: { slot: ViewSlot }) {
  const { entries } = slot;
  const verdict = slot.verdict ? VERDICT[slot.verdict] : null;
  return (
    <div
      className={cn(
        "flex min-h-[5em] flex-col gap-[0.6em] rounded-3xl p-[1em]",
        verdict?.tint ?? (entries.length > 0 && "bg-white/[0.03]"),
        !entries.length && "border-2 border-dashed border-white/10",
        slot.focused && focusClass,
      )}
    >
      <h3 className={cn("flex items-center gap-[0.4em] font-medium", verdict?.text ?? (!entries.length && "text-neutral-500"))}>
        {slot.verdict && <VerdictIcon verdict={slot.verdict} className="size-[1.1em] shrink-0" />}
        {slot.name}
      </h3>
      <Chips entries={entries} />
    </div>
  );
}

// The template's headed columns, each row named after its first slot.
function Columns({ board, columns }: { board: Extract<BoardView, { layout: "grid" }>; columns: string[] }) {
  return (
    <div
      className="grid content-start gap-[0.85em]"
      style={{
        gridTemplateColumns: `8.5em repeat(${columns.length}, minmax(0, 1fr))`,
        gridTemplateRows: `auto repeat(${board.rows.length}, auto)`,
      }}
    >
      <div />
      {columns.map((c) => (
        <h2 key={c} className="text-[1.07em] leading-tight font-medium text-neutral-400">
          {c}
        </h2>
      ))}
      {board.rows.map((row) => (
        <Fragment key={row[0].id}>
          <h3 className="pt-[0.4em] text-[1.07em] leading-tight font-medium">{row[0].name}</h3>
          {row.map((slot) => (
            <Cell key={slot.id} slot={slot} />
          ))}
        </Fragment>
      ))}
    </div>
  );
}

function Cell({ slot }: { slot: ViewSlot }) {
  return (
    <div
      className={cn(
        "min-h-[3.6em] rounded-3xl p-[0.85em]",
        slot.entries.length ? "bg-white/[0.03]" : "border-2 border-dashed border-white/10",
        slot.focused && focusClass,
      )}
    >
      <Chips entries={slot.entries} />
    </div>
  );
}

// Sized in em, so a chip follows the size its board fits at. The radius stops growing with
// height, so a wrapped chip stays a rounded rectangle clear of its text.
function Chips({ entries }: { entries: ViewEntry[] }) {
  return (
    <ul className="flex flex-wrap gap-[0.5em]">
      {entries.map((e) => (
        <li
          key={e.id}
          className={cn(
            "flex items-center gap-[0.4em] rounded-[1.2em] border-2 border-white/15 bg-white/[0.07] px-[0.85em] py-[0.35em] leading-tight wrap-anywhere",
            e.mark && MARK[e.mark].room.border,
            e.focused && focusClass,
          )}
        >
          {e.mark && <MarkIcon mark={e.mark} className={cn("size-[1.1em] shrink-0", MARK[e.mark].room.text)} />}
          {e.coverage && <CoverageIcon level={e.coverage} className={cn("size-[1.2em] shrink-0", e.goal && "text-neutral-500")} />}
          {e.goal && <CoverageIcon level={e.goal} className="size-[1.2em] shrink-0 text-(--room-accent)" />}
          {e.label}
          {e.count !== null && <span className="shrink-0 whitespace-nowrap opacity-70">×{e.count.toLocaleString("en-US")}</span>}
          {e.detail.map((d, i) => (
            <span key={i} className="shrink-0 whitespace-nowrap text-[0.8em] text-neutral-400">
              {d}
            </span>
          ))}
        </li>
      ))}
    </ul>
  );
}
