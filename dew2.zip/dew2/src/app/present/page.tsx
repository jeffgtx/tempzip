import { JoinForm } from "./join-form";
import { Room } from "./room";

export const metadata = { title: "dew2 room" };

export default async function PresentPage({ searchParams }: PageProps<"/present">) {
  const { code } = await searchParams;
  return typeof code === "string" && code ? <Room key={code} code={code} /> : <JoinForm />;
}
