"use client";

import { IconArrowRight } from "@tabler/icons-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// A code that didn't work stays in the field, so the customer can fix the digit they mistyped.
export function JoinForm({ error, tried = "" }: { error?: string; tried?: string }) {
  const [code, setCode] = useState(tried);
  return (
    <main className="grid min-h-screen place-items-center bg-neutral-950 p-6 text-neutral-100">
      {/* A page load, not a client navigation, so a code already in the URL is checked again, as after its meeting ends. */}
      <form action="/present" className="flex w-full max-w-60 flex-col gap-3">
        <Input
          aria-label="Join code"
          name="code"
          inputMode="numeric"
          autoComplete="off"
          autoFocus
          required
          pattern="\d{6}"
          maxLength={6}
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
          className="h-12 border-neutral-700 text-center font-mono text-2xl tracking-[0.4em] md:text-2xl"
        />
        {error && (
          <p role="alert" className="text-center text-sm text-red-400">
            {error}
          </p>
        )}
        <Button type="submit" variant="secondary" aria-label="Join">
          <IconArrowRight />
        </Button>
      </form>
    </main>
  );
}
