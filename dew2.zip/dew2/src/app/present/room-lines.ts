// Line styles by connection type.
export const STYLES: Record<string, { dash?: string; width?: number; color: string }> = {
  "conn-mpls": { color: "#d4d4d8" },
  "conn-sd-wan": { dash: "16 12", color: "#60a5fa" },
  "conn-remote-network": { dash: "16 12", color: "#60a5fa" },
  "conn-local-internet": { dash: "1 10", color: "#a1a1aa" },
  "conn-egress": { dash: "1 10", color: "#a1a1aa" },
  "conn-remote-access": { dash: "18 9 2 9", color: "#4ade80" },
  "conn-agent": { dash: "18 9 2 9", color: "#4ade80" },
  "conn-explicit-proxy": { dash: "18 9 2 9", color: "#4ade80" },
  "conn-prisma-browser": { dash: "18 9 2 9", color: "#4ade80" },
  "conn-direct-connect": { color: "#a78bfa" },
  "conn-expressroute": { color: "#a78bfa" },
  "conn-cloud-interconnect": { color: "#a78bfa" },
  "conn-fastconnect": { color: "#a78bfa" },
  "conn-site-vpn": { dash: "16 12", color: "#a78bfa" },
  "conn-dci": { color: "#a78bfa" },
  "conn-service-connection": { width: 9, color: "#e4e4e7" },
  "conn-ztna-connector": { width: 9, color: "#e4e4e7" },
  "conn-colo-connect": { width: 9, color: "#e4e4e7" },
};

export type Point = { x: number; y: number };
export type Rect = { x: number; y: number; w: number; h: number };

// A cubic curve's path, its middle, and points along it where its label may sit.
export function curve(p0: Point, p1: Point, p2: Point, p3: Point) {
  const at = (t: number) => {
    const [k0, k1, k2, k3] = [(1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t ** 2, t ** 3];
    return { x: k0 * p0.x + k1 * p1.x + k2 * p2.x + k3 * p3.x, y: k0 * p0.y + k1 * p1.y + k2 * p2.y + k3 * p3.y };
  };
  return {
    path: `M ${p0.x} ${p0.y} C ${p1.x} ${p1.y} ${p2.x} ${p2.y} ${p3.x} ${p3.y}`,
    mid: at(0.5),
    along: Array.from({ length: 41 }, (_, k) => at(k / 40)),
  };
}

const overlap = (a: Rect, b: Rect) =>
  Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
// Beside a line, a label's centre sits up to just over half its size off it; failing that, up to its whole size off
// it, or off a corner diagonally. A label reads best on its line, so a spot beside it costs as much as a long way
// along it, and one further off twice that.
const BESIDE = 400;
const NEAR = [0.3, 0.55].flatMap((f) => [[0, f], [0, -f], [f, 0], [-f, 0]]);
const STEPS = [0, 0.55, -0.55, 1, -1];
const FAR = STEPS.flatMap((fx) => STEPS.map((fy) => [fx, fy])).filter(([fx, fy]) => Math.max(Math.abs(fx), Math.abs(fy)) === 1 || (fx && fy));
const SHIFTS = [[0, 0, 0], ...NEAR.map(([fx, fy]) => [fx, fy, BESIDE]), ...FAR.map(([fx, fy]) => [fx, fy, 2 * BESIDE])];
// A label nearer another line than its own reads as that line's, so it costs more than any spot on or beside its own
// that only comes closer than GAP to a node, and more than crossing another line on its own. A crossing costs more for
// each pixel of the line it hides. Lying along another line, through the label the long way or along its edge, or
// hiding another line's turn or end, leaves that line reading as broken off, which is worse; hiding its own line's turn
// breaks the line it labels, which is worse still. One closer than GAP to another label reads as one with it, and one
// on a node is cut by it, the worst of all.
const CROSS = 100_000;
const HIDE = 1000;
const TURN = 3 * CROSS;
const OWN_TURN = 8 * CROSS;
const TOUCH = 10 * CROSS;
// Lines turn at corners rounded to this radius.
export const ROUND = 20;

// Labels closer than this read as one label, as the label of the line beside them, or as cut by a node.
export const GAP = 16;
const grow = (r: Rect, dx: number, dy: number) => ({ x: r.x - dx, y: r.y - dy, w: r.w + 2 * dx, h: r.h + 2 * dy });
const apart = (r: Rect) => grow(r, GAP, GAP);
const length = (along: Point[]) => along.reduce((sum, p, k) => sum + (k && Math.hypot(p.x - along[k - 1].x, p.y - along[k - 1].y)), 0);

// The part of the segment from a to b inside r, or null where it passes outside r.
function clip(a: Point, b: Point, r: Rect): Segment | null {
  let [t0, t1] = [0, 1];
  const [dx, dy] = [b.x - a.x, b.y - a.y];
  for (const [p, q] of [[-dx, a.x - r.x], [dx, r.x + r.w - a.x], [-dy, a.y - r.y], [dy, r.y + r.h - a.y]]) {
    if (p === 0) {
      if (q < 0) return null;
    } else if (p < 0) t0 = Math.max(t0, q / p);
    else t1 = Math.min(t1, q / p);
    if (t0 > t1) return null;
  }
  return [
    { x: a.x + t0 * dx, y: a.y + t0 * dy },
    { x: a.x + t1 * dx, y: a.y + t1 * dy },
  ];
}
const cuts = (a: Point, b: Point, r: Rect) => clip(a, b, r) !== null;
const toRect = (p: Point, r: Rect) => Math.hypot(Math.max(r.x - p.x, 0, p.x - r.x - r.w), Math.max(r.y - p.y, 0, p.y - r.y - r.h));
// How far the segment from a to b passes from r.
function distance(a: Point, b: Point, r: Rect) {
  if (cuts(a, b, r)) return 0;
  const [dx, dy] = [b.x - a.x, b.y - a.y];
  const toSegment = (x: number, y: number) => {
    const t = Math.min(1, Math.max(0, ((x - a.x) * dx + (y - a.y) * dy) / (dx * dx + dy * dy || 1)));
    return Math.hypot(a.x + t * dx - x, a.y + t * dy - y);
  };
  const [right, bottom] = [r.x + r.w, r.y + r.h];
  return Math.min(toRect(a, r), toRect(b, r), toSegment(r.x, r.y), toSegment(right, r.y), toSegment(r.x, bottom), toSegment(right, bottom));
}
const nearest = (line: Point[], r: Rect) => {
  let least = Infinity;
  for (let k = 1; k < line.length && least > 0; k++) least = Math.min(least, distance(line[k - 1], line[k], r));
  return least;
};
const holds = (r: Rect, p: Point) => p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h;
const span = ([a, b]: Segment) => Math.hypot(b.x - a.x, b.y - a.y);
type Segment = [Point, Point];
// Where a line turns, unlike the slight bends between the points along a curve: the middle of the rounded corner it
// draws there.
function corners(line: Point[]) {
  const heading = (k: number) => Math.atan2(line[k + 1].y - line[k].y, line[k + 1].x - line[k].x);
  const bend = (k: number) => Math.abs(((heading(k) - heading(k - 1) + 3 * Math.PI) % (2 * Math.PI)) - Math.PI);
  return line.flatMap((at, k) => {
    if (k === 0 || k === line.length - 1 || bend(k) <= Math.PI / 6) return [];
    const [prev, next] = [line[k - 1], line[k + 1]];
    const r = Math.min(ROUND, span([prev, at]) / 2, span([at, next]) / 2);
    const [a, b] = [prev, next].map((p) => ({ x: at.x + ((p.x - at.x) * r) / span([p, at]), y: at.y + ((p.y - at.y) * r) / span([p, at]) }));
    return [{ x: (a.x + 2 * at.x + b.x) / 4, y: (a.y + 2 * at.y + b.y) / 4 }];
  });
}
// Whether a line hiding `hidden` of itself in its runs through a label's halo `r` lies along the label rather than
// crosses it. A crossing passes from one side to the opposite one the short way; a run that leaves by the side it
// came in or one beside it, for longer than GAP, skims the label's edge.
function liesAlong(runs: Segment[], hidden: number, r: Rect) {
  const [a, b] = [runs[0][0], runs.at(-1)![1]];
  const side = (p: Point) => {
    const d = [p.x - r.x, p.y - r.y, r.x + r.w - p.x, r.y + r.h - p.y];
    return d.indexOf(Math.min(...d));
  };
  if (Math.abs(side(a) - side(b)) !== 2) return hidden > GAP;
  return hidden > (Math.abs(b.y - a.y) * r.w + Math.abs(b.x - a.x) * r.h) / span([a, b]) + 1;
}

export type Label = {
  w: number;
  h: number;
  mid: Point;
  // Where its centre may sit: points along its line, or beside them; or, for a label that sits beside
  // its line rather than on it, such as a loop's, only these spots, which are beside it already.
  along: Point[];
  beside?: boolean;
  // The whole line it labels, where `along` is only part of it or beside it.
  track?: Point[];
};
const CANVAS: Rect = { x: 0, y: 0, w: 1920, h: 1080 };

// Centres each measured label within `bounds` on a point along its own line, or beside it, nearest the
// spot it prefers among those GAP clear of the fixed rects, the other labels and every other line drawn,
// `lines`, which default to the labelled ones; when none is clear, where it overlaps least, coming closer
// than GAP to a fixed rect counting far less than overlapping. A short line has few spots, so the shortest
// place first; then each label still closer than GAP to another or to a fixed rect moves to its best spot
// among them all, until none moves.
export function placeLabels(labels: Label[], fixed: Rect[], lines = labels.map((l) => l.along), bounds = CANVAS): Point[] {
  const box = (i: number, p: Point) => ({ x: p.x - labels[i].w / 2, y: p.y - labels[i].h / 2, w: labels[i].w, h: labels[i].h });
  const crowd = (p: Rect, r: Rect) => 1000 * overlap(p, r) + 10 * overlap(apart(p), r);
  const cut = (p: Rect, r: Rect) => crowd(p, r) + (overlap(p, r) > 0 ? TOUCH : 0);
  const place = (i: number, placed: Rect[]) => {
    const { w, h, mid, along, beside, track } = labels[i];
    const own = track ?? (beside ? null : along);
    const turns = own ? corners(own) : [];
    // Sitting nearer another line than its own costs more than crossing a line, which hides no more of it than this.
    const nearer = CROSS + HIDE * Math.hypot(w + GAP, h + GAP);
    const xs = along.map((p) => p.x);
    const ys = along.map((p) => p.y);
    const [x, y] = [Math.min(...xs), Math.min(...ys)];
    const reach = 2 * Math.max(w, h) + GAP;
    const area = grow({ x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y }, reach, reach);
    // Only the stretches and turns of other lines within reach of its spots can get in its way.
    const others = lines.flatMap((line) => {
      const near = line === own ? [] : line.slice(1).flatMap((p, k): Segment[] => (cuts(line[k], p, area) ? [[line[k], p]] : []));
      const marks = [line[0], ...corners(line), line.at(-1)!].filter((p) => holds(area, p));
      return near.length ? [{ near, marks }] : [];
    });
    const spots = along
      .flatMap((p) =>
        (beside ? [SHIFTS[0]] : SHIFTS).map(([fx, fy, off]) => ({
          on: p,
          x: p.x + fx * w,
          y: p.y + fy * h,
          cost: Math.hypot(p.x - mid.x, p.y - mid.y) + off,
        })),
      )
      .sort((a, b) => a.cost - b.cost);
    let best = { ...mid, cost: Infinity };
    for (const spot of spots) {
      // Overlaps only add to a spot's distance, so no spot further than the best can beat it.
      if (spot.cost >= best.cost) break;
      const r = box(i, spot);
      if (r.x < bounds.x || r.y < bounds.y || r.x + w > bounds.x + bounds.w || r.y + h > bounds.y + bounds.h) continue;
      let cost = spot.cost + fixed.reduce((sum, p) => sum + cut(p, r), 0);
      for (const p of placed) cost += crowd(p, r) + (overlap(apart(p), r) > 0 ? TOUCH : 0);
      const over = grow(r, GAP / 2, GAP / 2);
      if (turns.some((p) => holds(over, p))) cost += OWN_TURN;
      if (cost >= best.cost) continue;
      // Off its line, it reads as the label of any other line not clearly further off, unless it only crosses that
      // line from just beside its own. A spot off a point of its own line is no further from that line than from the
      // point, so only lines that near need its exact distance.
      const most = beside ? Infinity : toRect(spot.on, r) + GAP / 2;
      const close = others.filter((line) => most === Infinity || line.near.some(([a, b]) => cuts(a, b, grow(r, most, most))));
      const aside = own && close.length ? nearest(own, r) : 0;
      const near = grow(r, aside + GAP / 2, aside + GAP / 2);
      for (const line of close) {
        if (!line.near.some(([a, b]) => cuts(a, b, near))) continue;
        const gap = Math.min(...line.near.map(([a, b]) => distance(a, b, r)));
        if (gap >= aside + GAP / 2) continue;
        const reads = aside > 0 && (gap > 0 || aside > GAP / 2);
        const runs = line.near.map(([a, b]) => clip(a, b, over)).filter((run) => run !== null);
        const hidden = runs.reduce((sum, run) => sum + span(run), 0);
        const broken = line.marks.filter((p) => holds(over, p)).length + (runs.length && liesAlong(runs, hidden, over) ? 1 : 0);
        cost += (reads ? nearer : CROSS) + HIDE * hidden + TURN * broken;
      }
      if (cost < best.cost) best = { ...spot, cost };
    }
    return { x: best.x, y: best.y };
  };
  const order = labels.map((_, i) => i).sort((a, b) => length(labels[a].along) - length(labels[b].along));
  const at: Point[] = [];
  for (const i of order) at[i] = place(i, order.filter((j) => at[j]).map((j) => box(j, at[j])));
  for (let moved = true, pass = 0; moved && pass < labels.length; pass++) {
    moved = false;
    for (const i of order) {
      const placed = order.filter((j) => j !== i).map((j) => box(j, at[j]));
      if (![...fixed, ...placed].some((r) => overlap(apart(r), box(i, at[i])) > 0)) continue;
      const next = place(i, placed);
      moved ||= next.x !== at[i].x || next.y !== at[i].y;
      at[i] = next;
    }
  }
  return at;
}

// A label that wraps keeps the width it wrapped at, so it narrows to the least that keeps its lines, hiding no
// more of the lines under it than its text needs.
export function narrow(el: HTMLElement) {
  el.style.width = "";
  const height = el.offsetHeight;
  if (height < 1.5 * parseFloat(getComputedStyle(el).lineHeight)) return;
  let [lo, hi] = [0, el.offsetWidth];
  while (hi - lo > 1) {
    const w = Math.floor((lo + hi) / 2);
    el.style.width = `${w}px`;
    if (el.offsetHeight > height || el.scrollWidth > el.clientWidth) lo = w;
    else hi = w;
  }
  el.style.width = `${hi}px`;
}
