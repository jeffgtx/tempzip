"use client";

import { cn } from "cn";
import { type ReactNode, useEffect, useLayoutEffect, useRef, useState } from "react";

export const WIDTH = 1920;
export const HEIGHT = 1080;
// Its hue is far from every colour in room-lines.ts, so a changed line stands out from unchanged ones.
const DEFAULT_ACCENT = "#fb923c";

// The OKLCH chroma of a #rrggbb colour.
function chroma(hex: string) {
  const [r, g, b] = [1, 3, 5].map((i) => {
    const c = parseInt(hex.slice(i, i + 2), 16) / 255;
    return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b);
  const m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b);
  const s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
  return Math.hypot(1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s, 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s);
}

// A black, white or grey accent would make changes look like quiet items, so those use the default.
export const accentOrDefault = (accent: string | null) => (accent && chroma(accent) >= 0.04 ? accent : DEFAULT_ACCENT);

// What the SE has selected in the cockpit: an outline in the accent, clear of the item's edge and casting no glow, so it reads
// apart from the accent an item carries on its own border or fill for heard, lit or changed. It sets no border or shadow,
// which would replace a quiet item's dashes or a level's glow. It keeps to a floor in px, so small text, such as the
// overview's or a full grid's, doesn't thin it to a hairline.
export const focusClass =
  "opacity-100 outline-[length:max(0.12em,4px)] outline-offset-[max(0.15em,4px)] outline-solid outline-(--room-accent) -translate-y-[0.15em]";

// The room's fixed 1920×1080 logical canvas in the customer's theme.
export function RoomStage({ accent, style, children }: { accent: string | null; style?: React.CSSProperties; children: ReactNode }) {
  return (
    <div
      className="overflow-hidden bg-[#0b0b0d] text-neutral-100"
      style={
        {
          width: WIDTH,
          height: HEIGHT,
          // Lifted to at least 72% lightness so any accent reads on the near-black base.
          "--room-accent": `oklch(from ${accentOrDefault(accent)} max(l, 0.72) c h)`,
          ...style,
        } as React.CSSProperties
      }
    >
      {children}
    </div>
  );
}

// The stage scaled and letterboxed to fit its container.
export function RoomCanvas({ accent, className, children }: { accent: string | null; className?: string; children: ReactNode }) {
  const outer = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0);
  useEffect(() => {
    const el = outer.current!;
    const observer = new ResizeObserver(() => setScale(Math.min(el.clientWidth / WIDTH, el.clientHeight / HEIGHT)));
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={outer} className={cn("relative overflow-hidden bg-black", className)}>
      <RoomStage
        accent={accent}
        style={{ position: "absolute", top: "50%", left: "50%", transform: `translate(-50%, -50%) scale(${scale})` }}
      >
        {children}
      </RoomStage>
    </div>
  );
}

// Sets the element's font size to the largest whole px up to `size` at which its content fits its
// height, so the canvas doesn't cut off what the customer said; sizes in em inside it follow. A
// layout effect, so the PNG export's synchronous offscreen render fits too.
export function useFit<T extends HTMLElement>(size: number) {
  const ref = useRef<T>(null);
  useLayoutEffect(() => {
    const el = ref.current!;
    const fits = (px: number) => {
      el.style.fontSize = `${px}px`;
      return el.scrollHeight <= el.clientHeight;
    };
    if (fits(size)) return;
    let [lo, hi] = [1, size];
    while (hi - lo > 1) {
      const px = Math.floor((lo + hi) / 2);
      if (fits(px)) lo = px;
      else hi = px;
    }
    el.style.fontSize = `${lo}px`;
  });
  return ref;
}
