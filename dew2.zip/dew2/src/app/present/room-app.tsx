import { IconBrain, IconDatabase, IconDevices, IconShieldCheck, IconTool, IconUsers } from "@tabler/icons-react";
import { cn } from "cn";
import { Fragment } from "react";
import type { AppRow, AppView, Placed } from "@/board/zooms";
import { NodeIcon } from "@/components/node-icon";
import { whole } from "@/components/whole";
import { useFit } from "./room-canvas";
import { Frame } from "./room-frame";

// The radius stops growing with height, so a wrapped chip stays a rounded rectangle.
const CHIP = "rounded-[1em] bg-white/[0.08] px-[0.7em] py-[0.15em] leading-tight wrap-anywhere";
const QUIET = "border-dashed border-white/10 opacity-45";
// Each column is as wide as what it holds. A line keeps a minimum length so it still reads as a line with nothing on it, and
// a built app's names take the rest, so they don't narrow as the text steps down. The cockpit draws the zoom in the same
// columns.
export const BOUGHT_COLUMNS = "grid-cols-[auto_minmax(5em,auto)_auto] justify-center";
export const BUILT_COLUMNS = "grid-cols-[auto_minmax(5em,auto)_auto_minmax(5em,auto)_1fr]";
export const ROW_ICONS: Record<AppRow["key"], typeof IconBrain> = { models: IconBrain, tools: IconTool, data: IconDatabase };

// Who uses the app on the left, then the app: on the right of a bought app, or in the middle of a built one, with what it
// calls on its right. Each line of traffic between them carries the capabilities placed on it. Sized in em, so the whole
// picture steps down as it fills.
export function RoomApp({ view, logoUrl }: { view: AppView; logoUrl: string | null }) {
  const fit = useFit<HTMLDivElement>(26);
  const { at } = view;
  return (
    <Frame logoUrl={logoUrl} title={view.title} subtitle={view.subtitle.join(" · ") || null}>
      {view.kind === "bought" ? (
        <div ref={fit} className={cn("grid h-full grid-rows-[1fr_1fr_1fr] gap-y-[0.75em]", BOUGHT_COLUMNS)}>
          <Users users={view.users} endpoints={at.endpoints} />
          <Line placed={[...at.access, ...at.prompts]} quiet={!view.users.length} className="col-start-2 row-span-3 row-start-1" />
          <Box view={view} placed={[...at.tenant, ...at.build]} className="col-start-3 row-span-3 row-start-1 self-center" />
        </div>
      ) : (
        // The rows share the height the tallest needs rather than the canvas's, so the box spanning them stays as tall as
        // its content while every line out still meets it.
        <div ref={fit} className="flex h-full flex-col justify-center">
          <div className={cn("grid gap-y-[0.75em]", BUILT_COLUMNS)} style={{ gridTemplateRows: `repeat(${view.rows.length}, 1fr)` }}>
            <UserChips users={view.users} className="col-start-1 row-span-full items-end self-center" />
            <Line placed={[...at.prompts, ...at.access]} quiet={!view.users.length} className="col-start-2 row-span-full" />
            <Box view={view} placed={[...at.build, ...at.tenant]} className="col-start-3 row-span-full" />
            {view.rows.map((row, i) => {
              const Icon = ROW_ICONS[row.key];
              return (
                <Fragment key={row.key}>
                  <Line placed={row.placed} quiet={!row.names.length} className="col-start-4" style={{ gridRowStart: i + 1 }} />
                  <div
                    className={cn(
                      "col-start-5 flex items-center gap-[0.4em] self-center justify-self-start rounded-[0.8em] border-2 border-white/15 bg-[#151518] p-[0.6em]",
                      !row.names.length && QUIET,
                    )}
                    style={{ gridRowStart: i + 1 }}
                  >
                    <Icon className="size-[1.3em] shrink-0 text-neutral-300" />
                    <div className="flex flex-wrap gap-[0.4em]">
                      {row.names.map((n) => (
                        <span key={n} className={CHIP}>
                          {n}
                        </span>
                      ))}
                    </div>
                  </div>
                </Fragment>
              );
            })}
          </div>
        </div>
      )}
    </Frame>
  );
}

// The app, headed by its icon and name as a node is, holding what acts on the app rather than on its traffic.
function Box({ view, placed, className }: { view: AppView; placed: Placed[]; className: string }) {
  return (
    <div
      className={cn("flex flex-col gap-[0.4em] rounded-[1.2em] border-2 border-dashed border-white/20 bg-white/[0.03] p-[0.75em]", className)}
    >
      <p className="flex items-center gap-[0.43em] leading-tight font-semibold">
        <NodeIcon category={view.icon.category} itemId={view.icon.itemId} className="size-[1.3em] shrink-0 text-neutral-300" />
        <span>{whole(view.title)}</span>
      </p>
      {placed.map((p) => (
        <Capability key={p.id} placed={p} />
      ))}
    </div>
  );
}

// Who uses a bought app, framed by the devices they and their agents run on, with what protects those devices on the frame's
// edge. The frame ends halfway down the last two rows, which share the endpoints' height, so they straddle its edge however
// tall they wrap.
function Users({ users, endpoints }: { users: string[]; endpoints: Placed[] }) {
  return (
    <div className="col-start-1 row-span-3 row-start-1 grid grid-rows-[auto_1fr_1fr] self-center">
      <div className="relative col-start-1 row-span-2 row-start-1 rounded-[1.2em] border-2 border-dashed border-white/15">
        <IconDevices className="absolute top-[0.6em] left-[0.6em] size-[1.4em] text-neutral-400" />
      </div>
      <UserChips users={users} className="col-start-1 row-start-1 items-start p-[0.75em] pt-[2.4em]" />
      {endpoints.length > 0 && (
        <div className="col-start-1 row-span-2 row-start-2 flex flex-col gap-[0.4em] px-[0.75em]">
          {endpoints.map((p) => (
            <Capability key={p.id} placed={p} />
          ))}
        </div>
      )}
    </div>
  );
}

function UserChips({ users, className }: { users: string[]; className: string }) {
  return (
    <ul className={cn("flex flex-col gap-[0.4em]", className)}>
      {users.length ? (
        users.map((u) => (
          <li key={u} className={cn(CHIP, "border-2 border-white/15")}>
            {u}
          </li>
        ))
      ) : (
        <li className={cn(CHIP, "border-2", QUIET)}>
          <IconUsers className="size-[1.2em]" />
        </li>
      )}
    </ul>
  );
}

// A line of traffic, with the capabilities placed on it standing across it, centred and as wide as the widest needs.
// It runs quiet while nothing is named at its far end.
function Line(props: { placed: Placed[]; quiet: boolean; className: string; style?: React.CSSProperties }) {
  return (
    <div className={cn("relative grid content-center justify-center gap-[0.4em] px-[0.75em]", props.className)} style={props.style}>
      <div
        className={cn(
          "absolute inset-x-0 top-1/2 -translate-y-1/2 border-t-[3px] border-neutral-500",
          props.quiet && "border-dashed border-white/20",
        )}
      />
      {props.placed.map((p) => (
        <Capability key={p.id} placed={p} />
      ))}
    </div>
  );
}

// In place reads settled, as any card; proposed carries the accent, as a planned coverage does.
function Capability({ placed }: { placed: Placed }) {
  return (
    <div
      className={cn(
        "relative rounded-[0.6em] border-2 px-[0.6em] py-[0.35em]",
        placed.inPlace
          ? "border-white/15 bg-[#151518]"
          : "border-(--room-accent) bg-[color-mix(in_oklch,var(--room-accent)_14%,#151518)]",
      )}
    >
      <p className="flex items-center gap-[0.35em] leading-tight font-medium">
        <IconShieldCheck className={cn("size-[1.1em] shrink-0", placed.inPlace ? "text-neutral-400" : "text-(--room-accent)")} />
        <span>{whole(placed.name)}</span>
      </p>
      {placed.products.length > 0 && (
        <p className="mt-[0.15em] text-[0.8em] leading-snug text-neutral-400">{whole(placed.products.join(" · "))}</p>
      )}
    </div>
  );
}
