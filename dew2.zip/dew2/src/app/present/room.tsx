"use client";

import { IconPlayerPause } from "@tabler/icons-react";
import { useEffect, useRef, useState } from "react";
import type { RoomSnapshot } from "@/meetings/room";
import { JoinForm } from "./join-form";
import { RoomCanvas } from "./room-canvas";
import { RoomView } from "./room-view";

const POLL_MS = 2000;
// While the server fails, polls slow down to this rather than hammering it.
const MAX_POLL_MS = 60_000;
// Polling is a fallback, so streaming is tried again after this long.
const POLL_FOR_MS = 60_000;
// A dropped stream reconnects by itself, so a few errors in a row, not one, mean streaming has failed.
const ERRORS_BEFORE_POLLING = 3;
// The server pings every 15 seconds; silence for longer means the stream has hung.
const STALL_MS = 40_000;
// A room tab left open after its meeting checks the database around the clock, so one that sees no change for this long stops.
const IDLE_MS = 30 * 60_000;

type Status = "live" | "paused" | "ended" | "invalid";

export function Room({ code }: { code: string }) {
  const [snapshot, setSnapshot] = useState<RoomSnapshot | null>(null);
  const [status, setStatus] = useState<Status>("live");
  // Kept across a pause, so resuming fetches only what changed and an ended meeting reads as ended.
  const version = useRef("");

  useEffect(() => {
    if (status !== "live") return;
    let stopped = false;
    let source: EventSource | undefined;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let stall: ReturnType<typeof setTimeout> | undefined;
    let idle: ReturnType<typeof setTimeout> | undefined;
    let errors = 0;
    let delay = POLL_MS;
    let pollingSince = 0;

    const changed = () => {
      clearTimeout(idle);
      idle = setTimeout(() => setStatus("paused"), IDLE_MS);
    };
    // "gone" once the code no longer works; "failed" when the server or network did.
    const fetchSnapshot = async (): Promise<"ok" | "failed" | "gone"> => {
      try {
        const response = await fetch(`/api/room?code=${code}&version=${version.current}`);
        if (stopped) return "gone";
        if (response.status === 404) setStatus(version.current ? "ended" : "invalid");
        else if (response.ok) {
          if (response.status === 200) {
            const next = (await response.json()) as RoomSnapshot;
            if (stopped) return "gone";
            apply(next);
          }
          return "ok";
        } else return "failed";
        return "gone";
      } catch {
        return "failed";
      }
    };
    const apply = (next: RoomSnapshot) => {
      if (next.version !== version.current) changed();
      version.current = next.version;
      setSnapshot(next);
    };
    const poll = async () => {
      source?.close();
      clearTimeout(stall);
      pollingSince ||= Date.now();
      const result = await fetchSnapshot();
      if (stopped || result === "gone") return;
      if (Date.now() - pollingSince >= POLL_FOR_MS) return stream();
      delay = result === "ok" ? POLL_MS : Math.min(delay * 2, MAX_POLL_MS);
      timer = setTimeout(poll, delay);
    };
    const alive = () => {
      errors = 0;
      clearTimeout(stall);
      stall = setTimeout(poll, STALL_MS);
    };
    const stream = () => {
      pollingSince = 0;
      errors = 0;
      source = new EventSource(`/api/room/events?code=${code}`);
      source.onopen = alive;
      source.addEventListener("ping", alive);
      source.onmessage = (e) => {
        alive();
        apply(JSON.parse(e.data));
      };
      source.addEventListener("end", () => {
        source?.close();
        clearTimeout(stall);
        setStatus("ended");
      });
      source.onerror = () => {
        if (source?.readyState === EventSource.CLOSED || ++errors >= ERRORS_BEFORE_POLLING) void poll();
      };
    };

    changed();
    // One plain request checks the code first, so a wrong code costs one attempt, not two.
    void fetchSnapshot().then((result) => {
      if (result !== "gone" && !stopped) stream();
    });
    return () => {
      stopped = true;
      source?.close();
      clearTimeout(timer);
      clearTimeout(stall);
      clearTimeout(idle);
    };
  }, [code, status]);

  useEffect(() => {
    if (status !== "paused") return;
    const resume = () => setStatus("live");
    window.addEventListener("keydown", resume);
    return () => window.removeEventListener("keydown", resume);
  }, [status]);

  if (status === "invalid") return <JoinForm error="That code isn't running." tried={code} />;
  // The next meeting has a new code.
  if (status === "ended") return <JoinForm />;
  return (
    <>
      <RoomCanvas accent={snapshot?.customer.accent ?? null} className="fixed inset-0">
        {snapshot?.board && <RoomView board={snapshot.board} logoUrl={snapshot.customer.logoUrl} />}
      </RoomCanvas>
      {status === "paused" && (
        <button
          type="button"
          aria-label="Resume"
          title="Resume"
          onClick={() => setStatus("live")}
          className="fixed inset-0 grid cursor-pointer place-items-center bg-neutral-950/70 text-neutral-100"
        >
          <IconPlayerPause className="size-24" />
        </button>
      )}
    </>
  );
}
