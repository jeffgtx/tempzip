import { IconCalendar, IconClock, IconMessage2, IconUser } from "@tabler/icons-react";
import { cn } from "cn";
import type { LitGroupView } from "@/board/lit-map";
import type { BoardView, Concern, LitView, Step } from "@/board/view";
import { RoomApp } from "./room-app";
import { focusClass, useFit } from "./room-canvas";
import { Frame } from "./room-frame";
import { RoomGrid } from "./room-grid";
import { RoomSummary } from "./room-summary";
import { RoomZoom } from "./room-zoom";

// The accent at a strength from 1 to 3, for the ranked list's and the lit map's levels.
const glow = (level: number) =>
  cn(
    level === 1 && "border-[color-mix(in_oklch,var(--room-accent)_45%,transparent)] bg-[color-mix(in_oklch,var(--room-accent)_8%,transparent)]",
    level === 2 && "border-[color-mix(in_oklch,var(--room-accent)_75%,transparent)] bg-[color-mix(in_oklch,var(--room-accent)_18%,transparent)]",
    level === 3 &&
      "border-(--room-accent) bg-[color-mix(in_oklch,var(--room-accent)_30%,transparent)] shadow-[0_0_40px_color-mix(in_oklch,var(--room-accent)_35%,transparent)]",
  );
const quiet = "border-dashed border-white/15 opacity-40";
const empty = <div className="h-full rounded-3xl border-2 border-dashed border-white/10" />;
// A group has no edge of its own, so its outline stands clear of its cards' lit borders.
const groupFocus = cn(focusClass, "rounded-3xl outline-offset-[0.5em]");

export function RoomView({ board, logoUrl }: { board: BoardView; logoUrl: string | null }) {
  switch (board.layout) {
    case "grid":
      return <RoomGrid board={board} logoUrl={logoUrl} />;
    case "hub-and-spoke":
      return <RoomSummary view={board} logoUrl={logoUrl} />;
    case "zoom":
      return <RoomZoom view={board} logoUrl={logoUrl} />;
    case "ai-app":
      return <RoomApp view={board} logoUrl={logoUrl} />;
    case "ranked-list":
      return (
        <Frame logoUrl={logoUrl} title={board.name}>
          {board.concerns.length ? <Concerns concerns={board.concerns} /> : empty}
        </Frame>
      );
    case "lit-map":
      return (
        <Frame logoUrl={logoUrl} title={board.name}>
          <LitMap groups={board.groups} />
        </Frame>
      );
    case "lit-group":
      return (
        <Frame logoUrl={logoUrl} title={board.name} subtitle={board.summary}>
          <LitGroup capabilities={board.capabilities} />
        </Frame>
      );
    case "list": {
      const minutes = board.steps.reduce((sum, s) => sum + (s.minutes ?? 0), 0);
      return (
        <Frame logoUrl={logoUrl} title={board.name} subtitle={minutes ? `${minutes} min` : null}>
          {board.steps.length ? <Steps steps={board.steps} /> : empty}
        </Frame>
      );
    }
  }
}

function Concerns({ concerns }: { concerns: Concern[] }) {
  const fit = useFit<HTMLOListElement>(40);
  return (
    <ol ref={fit} className="flex h-full flex-col gap-[0.57em]">
      {concerns.map((c) => (
        <RankedConcern key={c.id} concern={c} />
      ))}
    </ol>
  );
}

// Nothing said is plain; not a concern is quiet; 1 to 3 glow and show their bars.
function RankedConcern({ concern }: { concern: Concern }) {
  const { level } = concern;
  return (
    <li
      className={cn(
        "flex items-center gap-[0.85em] rounded-2xl border-2 border-white/15 bg-white/[0.05] px-[1em] py-[0.57em] leading-tight wrap-anywhere",
        level === 0 ? quiet : level && glow(level),
        concern.focused && focusClass,
      )}
    >
      {!!level && (
        <span className="flex h-[1.15em] shrink-0 items-end gap-1">
          {[1, 2, 3].map((bar) => (
            <span
              key={bar}
              className={cn("w-2 rounded-sm", bar <= level ? "bg-(--room-accent)" : "bg-white/15")}
              style={{ height: `${bar * 33}%` }}
            />
          ))}
        </span>
      )}
      {concern.label}
    </li>
  );
}

function Steps({ steps }: { steps: Step[] }) {
  const fit = useFit<HTMLOListElement>(32);
  return (
    <ol ref={fit} className="flex h-full flex-col gap-[0.5em]">
      {steps.map((s, i) => (
        <li
          key={s.id}
          className={cn("flex items-center gap-[1em] rounded-3xl bg-white/[0.05] px-[1em] py-[0.625em]", s.focused && focusClass)}
        >
          <span className="grid size-[1.75em] shrink-0 place-items-center rounded-full bg-(--room-accent) font-semibold text-black">
            {i + 1}
          </span>
          <span className="flex-1 wrap-anywhere">{s.label}</span>
          <span className="flex w-[12em] items-center gap-[0.25em] text-neutral-300">
            {s.owner && (
              <>
                <IconUser className="size-[1em] shrink-0" />
                {s.owner === "us" ? "Us" : s.owner === "them" ? "You" : s.owner}
              </>
            )}
          </span>
          <span className="flex w-[5.5em] items-center gap-[0.25em] text-neutral-300">
            {s.due && (
              <>
                <IconCalendar className="size-[1em] shrink-0" />
                {new Date(`${s.due}T00:00`).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
              </>
            )}
            {s.minutes && (
              <>
                <IconClock className="size-[1em] shrink-0" />
                {s.minutes} min
              </>
            )}
          </span>
        </li>
      ))}
    </ol>
  );
}

// Groups fill four columns in order, split so the tallest is as short as it can be and none sits empty while another holds
// two groups. The split ignores focus, so a selected capability's summary lengthens its own column without moving a group;
// the text steps down until the tallest column fits.
function columns(groups: LitView[], count = 4): LitView[][] {
  const weights = groups.map((g) => 1 + (g.summary ? 1 : 0) + g.capabilities.length);
  const fits = (max: number) => {
    let cols = 1;
    let sum = 0;
    for (const w of weights) {
      if (sum + w > max) {
        cols++;
        sum = 0;
      }
      sum += w;
    }
    return cols <= count;
  };
  let max = Math.max(0, ...weights);
  while (!fits(max)) max++;
  const cols: LitView[][] = [[]];
  let sum = 0;
  groups.forEach((g, i) => {
    const filled = cols.at(-1)!.length > 0;
    if (filled && (sum + weights[i] > max || groups.length - i <= count - cols.length)) {
      cols.push([]);
      sum = 0;
    }
    cols.at(-1)!.push(g);
    sum += weights[i];
  });
  return cols;
}

function LitMap({ groups }: { groups: LitView[] }) {
  const fit = useFit<HTMLDivElement>(24);
  return (
    <div ref={fit} className="grid h-full grid-cols-4 items-start gap-6">
      {columns(groups).map((col, i) => (
        <div key={i} className="flex flex-col">
          {col.map((g) => (
            <section key={g.id} className={cn("mb-[1.33em]", g.focused && groupFocus)}>
              <h3 className="mb-[0.5em] leading-[1.33] font-medium text-neutral-400">{g.name}</h3>
              {g.summary && <p className="-mt-[0.25em] mb-[0.5em] text-[0.75em] leading-snug text-neutral-500">{g.summary}</p>}
              <ul className="flex flex-col gap-[0.5em]">
                {g.capabilities.map((c) => (
                  <Capability key={c.id} capability={c} />
                ))}
              </ul>
            </section>
          ))}
        </div>
      ))}
    </div>
  );
}

function Capability({ capability }: { capability: LitView["capabilities"][number] }) {
  const { level } = capability;
  return (
    <li className={cn("rounded-2xl border-2 px-[0.83em] py-[0.5em]", level ? glow(level) : quiet, capability.focused && focusClass)}>
      <p className="leading-tight font-medium">{capability.name}</p>
      {capability.focused && capability.summary && (
        <p className="mt-[0.3em] text-[0.75em] leading-snug text-neutral-300">{capability.summary}</p>
      )}
    </li>
  );
}

function LitGroup({ capabilities }: { capabilities: LitGroupView["capabilities"] }) {
  const fit = useFit<HTMLUListElement>(28);
  return (
    <ul ref={fit} className={cn("grid h-full content-start gap-6", capabilities.length > 4 ? "grid-cols-3" : "grid-cols-2")}>
      {capabilities.map((c) => (
        <li
          key={c.id}
          className={cn("flex flex-col gap-[0.5em] rounded-3xl border-2 p-[1em]", c.level ? glow(c.level) : quiet, c.focused && focusClass)}
        >
          <p className="leading-tight font-medium">{c.name}</p>
          <ul className="flex flex-wrap gap-[0.33em] text-[0.75em]">
            {c.products.map((p) => (
              <li key={p} className="rounded-full bg-white/10 px-[0.75em] py-[0.2em]">
                {p}
              </li>
            ))}
          </ul>
          {c.summary && <p className="text-[0.75em] text-neutral-300">{c.summary}</p>}
          {c.concerns.map((concern) => (
            <p key={concern.key} className="flex items-center gap-[0.33em] text-[0.75em]">
              <IconMessage2 className="size-[1em] shrink-0 text-(--room-accent)" />
              {concern.label}
            </p>
          ))}
        </li>
      ))}
    </ul>
  );
}
