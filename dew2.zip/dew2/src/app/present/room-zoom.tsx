import {
  IconApps,
  IconBuilding,
  IconCloudNetwork,
  IconCloudQuestion,
  IconDevices,
  IconFilter,
  IconFirewallCheck,
  IconGauge,
  IconLockAccess,
  IconLockOpen,
  IconLogin2,
  IconLogout2,
  IconMapPin,
  IconMapPinQuestion,
  IconPlugConnected,
  IconRoute,
  IconShieldCheck,
  IconTags,
  IconUsers,
  IconWorld,
} from "@tabler/icons-react";
import { cn } from "cn";
import { useLayoutEffect, useRef } from "react";
import type { ZoomCard, ZoomIcon, ZoomView } from "@/board/zooms";
import { BadgeIconFor, NodeIcon } from "@/components/node-icon";
import { whole } from "@/components/whole";
import { Logo } from "./room-frame";
import { type Point, STYLES, curve, narrow as narrowLabel, placeLabels } from "./room-lines";
import { Detail, useFit } from "./room-summary";

const W = 1920;
const TOP = 230;
const BOTTOM = 1030;
const PAD = 72;
// Columns whose lines carry labels stand further apart, so the line shows either side of its label.
const GAP = 90;
const LABELED_GAP = 300;
const ROW = 56;
const SPACE = 16;
// A column with more cards than fit at the smallest size folds the rest into a last "+N more" card.
const perColumn = (bottom: number) => Math.floor((bottom - TOP + SPACE) / (ROW + SPACE));
// A box's tiles, such as a security service's services, stand in rows under its cards.
const TILE = { w: 112, h: 88, gap: 12 };
// A long title steps down in size, then takes two lines, before it's cut short, so it stays clear of the cards.
const FIT = [
  [48, 1],
  [40, 1],
  [36, 2],
] as const;
// The subtitle steps down too, and takes a second line only beside a one-line title.
const SUBTITLE_FIT = [
  [24, 1],
  [20, 1],
  [16, 1],
  [16, 2],
] as const;
// A card's name takes two lines, and steps down in size before a word breaks or the name is cut short.
const NAME_FIT = [
  [1, 2],
  [0.93, 2],
  [0.86, 2],
  [0.79, 2],
  [0.71, 2],
] as const;

const GLYPHS = {
  users: IconUsers,
  device: IconDevices,
  circuit: IconPlugConnected,
  internet: IconWorld,
  apps: IconApps,
  network: IconCloudNetwork,
  transport: IconRoute,
  access: IconLockAccess,
  region: IconMapPin,
  unplaced: IconMapPinQuestion,
  unnetworked: IconCloudQuestion,
  sites: IconBuilding,
  bandwidth: IconGauge,
  open: IconLockOpen,
  filtered: IconFilter,
  inspected: IconShieldCheck,
  tags: IconTags,
  onramp: IconLogin2,
  offramp: IconLogout2,
};

// A column's "+N more" is drawn as a card, quiet as the cards it holds are.
const CARD = "absolute rounded-2xl border-2 border-white/15 bg-[#151518]";
// Only the content dims, so a box's outline or a line beneath doesn't show through.
const QUIET = "border-dashed border-white/10 bg-[#0b0b0d] *:opacity-45";

type Box = { x: number; y: number; w: number; h: number };
type Placed = Box & { column: number };
type Stack = { x: number; w: number; cards: Box[] };

// Columns share the width, and cards stand centred in their column.
function layout(view: ZoomView) {
  const n = view.columns.length;
  const columnOf = new Map(view.columns.flatMap((cards, i) => cards.map((c) => [c.id, i] as const)));
  const box = view.box && { ...view.box, last: view.box.column + (view.box.span ?? 1) - 1 };
  if (box && !columnOf.has(box.id)) columnOf.set(box.id, box.column);
  // A line meets a box that outlines several columns on the side facing the line's other end.
  const sideOf = (id: string, other: number | undefined) =>
    box && id === box.id && other !== undefined && other > box.last ? box.last : columnOf.get(id);
  const gaps = Array.from({ length: Math.max(0, n - 1) }, (_, i) =>
    view.lines.some((l) => {
      const [a, b] = [sideOf(l.from, columnOf.get(l.to)), sideOf(l.to, columnOf.get(l.from))];
      return l.label && a !== undefined && b !== undefined && Math.min(a, b) <= i && Math.max(a, b) > i;
    })
      ? LABELED_GAP
      : GAP,
  );
  const sum = (widths: number[]) => widths.reduce((t, g) => t + g, 0);
  const edgeOf = (b: NonNullable<typeof box>) => (b.boundary ? (view.columns[b.last + 1] ?? []) : []);
  // A box in an outer column keeps its frame inside the margin.
  const [inLeft, inRight] = box ? [box.column === 0 ? 32 : 0, !edgeOf(box).length && box.last === n - 1 ? 32 : 0] : [0, 0];
  const room = W - 2 * PAD - inLeft - inRight;
  const w = Math.min(400, (room - sum(gaps)) / n);
  // Labelled gaps share the width capped cards leave, so a crowded gap's labels have room along their lines.
  const spare = (room - n * w - sum(gaps)) / (gaps.filter((g) => g === LABELED_GAP).length || 1);
  const widths = gaps.map((g) => (g === LABELED_GAP ? g + spare : g));
  const xs = widths.reduce((acc, g) => [...acc, acc.at(-1)! + w + g], [(W - n * w - sum(widths) + inLeft - inRight) / 2]);
  const at = new Map<string, Placed>();
  const shown: ZoomCard[] = [];
  const folds: (Placed & { count: number })[] = [];
  const folded = new Set<string>();
  const [left, right] = box
    ? [xs[box.column] - 32, edgeOf(box).length ? xs[box.last + 1] + w / 2 : xs[box.last] + w + 32]
    : [0, 0];
  const perRow = Math.max(1, Math.floor((right - left - 32 + TILE.gap) / (TILE.w + TILE.gap)));
  const tileRows = box ? Math.ceil(view.tiles.length / perRow) : 0;
  const reserve = tileRows ? tileRows * (TILE.h + TILE.gap) + 16 : 0;
  view.columns.forEach((cards, column) => {
    const bottom = box && column >= box.column && column <= box.last ? BOTTOM - reserve : BOTTOM;
    const rows = Math.min(cards.length, perColumn(bottom));
    const roomy = 80 + 24 * Math.max(0, ...cards.map((c) => c.detail.length + (c.stats.length ? 1 : 0)));
    const h = Math.max(ROW, Math.min(roomy, (bottom - TOP - (rows - 1) * SPACE) / rows));
    const gap = Math.min(28, (bottom - TOP - rows * h) / Math.max(1, rows - 1));
    const top = (TOP + bottom - (rows * h + (rows - 1) * gap)) / 2;
    const boxes = Array.from({ length: rows }, (_, i) => ({ x: xs[column], y: top + i * (h + gap), w, h, column }));
    // The fold's card stands in for the cards it holds, lines and all.
    cards.forEach((c, i) => at.set(c.id, boxes[Math.min(i, rows - 1)]));
    const kept = cards.length > rows ? rows - 1 : rows;
    shown.push(...cards.slice(0, kept));
    if (kept < rows) folds.push({ ...boxes[kept], count: cards.length - kept });
    for (const c of cards.slice(kept)) folded.add(c.id);
  });

  // The box outlines its columns and tiles, and reaches the middle of the next column on a boundary.
  let frame: Box | null = null;
  const tiles: { card: ZoomCard; box: Box }[] = [];
  if (box) {
    const { column, last } = box;
    const inside = view.columns.slice(column, last + 1).flat().map((c) => at.get(c.id)!);
    const edge = edgeOf(box).map((c) => at.get(c.id)!);
    const under = Math.max(...inside.map((b) => b.y + b.h)) + 16 + TILE.gap;
    const middle = (xs[column] + xs[last] + w) / 2;
    view.tiles.forEach((card, i) => {
      const row = Math.floor(i / perRow);
      const inRow = Math.min(perRow, view.tiles.length - row * perRow);
      const start = middle - (inRow * TILE.w + (inRow - 1) * TILE.gap) / 2;
      tiles.push({ card, box: { x: start + (i % perRow) * (TILE.w + TILE.gap), y: under + row * (TILE.h + TILE.gap), w: TILE.w, h: TILE.h } });
    });
    const top = Math.min(...inside.map((b) => b.y), ...edge.map((b) => b.y)) - 64;
    const bottom = Math.max(
      ...inside.map((b) => b.y + b.h + 32),
      ...edge.map((b) => b.y + b.h + 32),
      ...tiles.map((t) => t.box.y + t.box.h + 24),
    );
    frame = { x: left, y: top, w: right - left, h: bottom - top };
    if (!at.has(box.id)) at.set(box.id, { ...frame, column });
  }
  const stacks = view.columns.map((cards, column) => ({ x: xs[column], w, cards: [...new Set(cards.map((c) => at.get(c.id)!))] }));
  return { at, shown, folds, folded, frame, tiles, stacks, narrow: w < 340 };
}

// Lines sharing a side of a card leave it from points spread down that side, in
// the order of where they lead, so parallel lines and their labels stay apart.
// Alike lines between the same two cards, such as those of the cards a fold holds, draw as one.
// A fold's lines go unlabelled: their labels would crowd the fold and name links of cards it hides.
function route(view: ZoomView, at: Map<string, Placed>, folded: Set<string>, stacks: Stack[]) {
  const alike = new Map<string, ZoomView["lines"][number]>();
  for (const each of view.lines) {
    const line = folded.has(each.from) || folded.has(each.to) ? { ...each, label: "" } : each;
    const [a, b] = [at.get(line.from), at.get(line.to)];
    if (!a || !b || a === b) continue;
    const key = [a.x, a.y, b.x, b.y, line.type, line.label, line.backup].join("|");
    if (!alike.has(key)) alike.set(key, line);
  }
  const lines = [...alike.values()];
  const ends = lines.flatMap((line) => {
    const a = at.get(line.from)!;
    const b = at.get(line.to)!;
    if (a.column === b.column) return [];
    const [l, r] = a.column < b.column ? [a, b] : [b, a];
    return [{ line, l, r, yl: l.y + l.h / 2, yr: r.y + r.h / 2 }];
  });
  const spreadOn = (side: "l" | "r") => {
    const groups = new Map<Box, typeof ends>();
    for (const e of ends) groups.set(e[side], [...(groups.get(e[side]) ?? []), e]);
    for (const [box, group] of groups) {
      const other = side === "l" ? "r" : "l";
      group
        .sort((p, q) => p[other].y + p[other].h / 2 - (q[other].y + q[other].h / 2))
        .forEach((e, i) => (e[side === "l" ? "yl" : "yr"] = box.y + (box.h * (i + 1)) / (group.length + 1)));
    }
  };
  spreadOn("l");
  spreadOn("r");
  // A line within a column, such as from one edge device to the next, joins the cards' facing edges.
  const stacked = lines.flatMap((line) => {
    const a = at.get(line.from)!;
    const b = at.get(line.to)!;
    if (a.column !== b.column) return [];
    const [u, d] = a.y < b.y ? [a, b] : [b, a];
    const [p0, p3] = [{ x: u.x + u.w / 2, y: u.y + u.h }, { x: u.x + u.w / 2, y: d.y }];
    return [{ line, ...curve(p0, p0, p3, p3) }];
  });
  return [
    ...ends.map(({ line, l, r, yl, yr }) => ({ line, ...thread({ x: l.x + l.w, y: yl }, { x: r.x, y: yr }, stacks) })),
    ...stacked,
  ];
}

const level = (a: Point, b: Point) => {
  const d = (b.x - a.x) * 0.45;
  return curve(a, { x: a.x + d, y: a.y }, { x: b.x - d, y: b.y }, b);
};
const CLEAR = 12;

// A line that skips a column threads it level through the space between its cards nearest the line's
// path, or above or below them, so it never passes behind a card.
function thread(p0: Point, p3: Point, stacks: Stack[]) {
  const direct = level(p0, p3);
  const between = stacks.filter((s) => s.x >= p0.x && s.x + s.w <= p3.x);
  const behind = (p: Point) =>
    between.some((s) => s.cards.some((c) => p.x >= c.x && p.x <= c.x + c.w && p.y > c.y - CLEAR && p.y < c.y + c.h + CLEAR));
  if (!direct.along.some(behind)) return direct;
  const waypoints = between.flatMap((s) => {
    const straight = p0.y + ((p3.y - p0.y) * (s.x + s.w / 2 - p0.x)) / (p3.x - p0.x);
    const cards = [...s.cards].sort((a, b) => a.y - b.y);
    const openings = [
      cards[0].y - 2 * CLEAR,
      ...cards.slice(1).map((c, i) => (cards[i].y + cards[i].h + c.y) / 2),
      cards.at(-1)!.y + cards.at(-1)!.h + 2 * CLEAR,
    ];
    const clear = !cards.some((c) => straight > c.y - CLEAR && straight < c.y + c.h + CLEAR);
    const y = clear ? straight : openings.reduce((best, o) => (Math.abs(o - straight) < Math.abs(best - straight) ? o : best));
    return [{ x: s.x, y }, { x: s.x + s.w, y }];
  });
  const points = [p0, ...waypoints, p3];
  const parts = points.slice(1).map((p, i) => level(points[i], p));
  const along = parts.flatMap((c, i) => (i ? c.along.slice(1) : c.along));
  return {
    path: parts.map((c, i) => (i ? c.path.replace(/^M \S+ \S+ /, "") : c.path)).join(" "),
    mid: along[Math.floor(along.length / 2)],
    along,
  };
}

export function RoomZoom({ view, logoUrl }: { view: ZoomView; logoUrl: string | null }) {
  const { at, shown, folds, folded, frame, tiles, stacks, narrow } = layout(view);
  const lines = route(view, at, folded, stacks);
  const title = useRef<HTMLHeadingElement>(null);
  const subtitle = useRef<HTMLParagraphElement>(null);
  const subtitleText = view.subtitle.join(" · ");
  // A cloud's flow chips take the header's width, so it fits again as they come and go.
  const chips = view.inspected.map((c) => c.id).join();
  // The header fits again when its width changes, such as once the logo has loaded.
  const heading = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const fit = (el: HTMLElement, steps: readonly (readonly [number, number])[], lines = 2) => {
      let used = 1;
      for (const [size, clamp] of steps) {
        if (clamp > lines) break;
        el.style.fontSize = `${size}px`;
        el.style.webkitLineClamp = String(clamp);
        used = clamp;
        if (el.scrollHeight - el.clientHeight < size / 2) break;
      }
      return used;
    };
    const run = () => void fit(subtitle.current!, SUBTITLE_FIT, fit(title.current!, FIT) > 1 ? 1 : 2);
    run();
    let width = heading.current!.clientWidth;
    const observer = new ResizeObserver(() => {
      if (heading.current!.clientWidth === width) return;
      width = heading.current!.clientWidth;
      run();
    });
    observer.observe(heading.current!);
    return () => observer.disconnect();
  }, [view.title, subtitleText, chips]);

  // Labels settle on their lines, clear of the cards, once their real sizes are known, and again
  // once the fonts are in, unless a later render has replaced the lines the labels are drawn from.
  const root = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    let current = true;
    const settle = () => {
      if (!current || !root.current) return;
      const labels = [...root.current.querySelectorAll<HTMLElement>("[data-label]")];
      labels.forEach(narrowLabel);
      // A caption's offsetLeft is its centre, since its translate isn't layout.
      const heads = [...root.current.querySelectorAll<HTMLElement>("[data-head]")].map((el) => ({
        x: el.offsetLeft - el.offsetWidth / 2,
        y: el.offsetTop,
        w: el.offsetWidth,
        h: el.offsetHeight,
      }));
      const spots = placeLabels(
        labels.map((el) => ({ w: el.offsetWidth, h: el.offsetHeight, ...lines[Number(el.dataset.label)] })),
        [
          ...shown.map((c) => at.get(c.id)!),
          ...folds,
          ...tiles.map((t) => t.box),
          ...heads,
          // Labelled lines meet the subject's dashed frame from outside, so their labels stay out of it:
          // inside, a label reads as part of the subject, and across its edge as cut by it.
          ...(frame ? [frame] : []),
        ],
        lines.map((l) => l.along),
      );
      labels.forEach((el, i) => Object.assign(el.style, { left: `${spots[i].x}px`, top: `${spots[i].y}px` }));
    };
    settle();
    void document.fonts.ready.then(settle);
    return () => {
      current = false;
    };
  });

  return (
    <div ref={root} className="relative h-full text-left">
      <header className="absolute top-12 right-16 left-16 flex items-center gap-10">
        <div ref={heading} className="min-w-0">
          <h2 ref={title} className="line-clamp-1 text-5xl font-semibold">
            {view.title}
          </h2>
          <p ref={subtitle} className="mt-2 line-clamp-1 text-neutral-400">
            {subtitleText}
          </p>
        </div>
        {view.inspected.length > 0 && (
          <div className="flex shrink-0 items-center gap-3">
            <IconFirewallCheck aria-label="Inspected" className="size-9 text-neutral-400" />
            <ul className="flex gap-3">
              {view.inspected.map((c) => (
                <li
                  key={c.id}
                  className={cn(
                    "flex items-center gap-2 rounded-xl border-2 border-white/20 px-4 py-2 text-[22px] whitespace-nowrap",
                    c.quiet && "border-dashed opacity-45",
                  )}
                >
                  <ZoomCardIcon icon={c.icon} className="size-6 shrink-0" />
                  {c.name}
                </li>
              ))}
            </ul>
          </div>
        )}
        {logoUrl && <Logo url={logoUrl} className="ml-auto" />}
      </header>
      {view.heads.map((h) => (
        <div
          key={h.glyph}
          data-head
          className="absolute flex -translate-x-1/2 items-center gap-3 text-[22px] whitespace-nowrap text-neutral-400"
          style={{ left: stacks[h.column].x + stacks[h.column].w / 2, top: stacks[h.column].cards[0].y - 48 }}
        >
          <ZoomCardIcon icon={{ glyph: h.glyph }} className="size-7" />
          {h.name}
        </div>
      ))}
      {frame && view.box && (
        <div
          className="absolute rounded-3xl border-2 border-dashed border-white/20 bg-white/[0.03]"
          style={{ left: frame.x, top: frame.y, width: frame.w, height: frame.h }}
        >
          <NodeIcon category={view.box.icon.category} itemId={view.box.icon.itemId} className="m-4 size-9 text-neutral-400" />
        </div>
      )}
      <svg className="absolute inset-0" width={W} height={1080} viewBox={`0 0 ${W} 1080`}>
        {lines.map(({ line, path }, i) => {
          const style = (line.type && STYLES[line.type]) || { color: "#71717a", width: 3 };
          return (
            <path
              key={i}
              d={path}
              fill="none"
              stroke={style.color}
              strokeWidth={style.width ?? 4}
              strokeDasharray={line.backup ? "10 10" : style.dash}
              strokeLinecap="round"
            />
          );
        })}
      </svg>
      {shown.map((c) => (
        <Card key={c.id} card={c} box={at.get(c.id)!} narrow={narrow} />
      ))}
      {tiles.map(({ card, box }) => (
        <div
          key={card.id}
          className={cn(
            CARD,
            "flex flex-col items-center justify-center gap-1 px-2",
            card.quiet && QUIET,
          )}
          style={{ left: box.x, top: box.y, width: box.w, height: box.h }}
        >
          <ZoomCardIcon icon={card.icon} className="size-8 shrink-0 text-neutral-300" />
          <span className="line-clamp-2 text-center text-base leading-tight">{card.name}</span>
        </div>
      ))}
      {folds.map((f) => {
        const held = view.columns[f.column].slice(-f.count);
        return (
          <div
            key={f.column}
            className={cn(
              CARD,
              "flex items-center justify-center text-[26px] font-semibold",
              held.every((c) => c.quiet) && QUIET,
            )}
            style={{ left: f.x, top: f.y, width: f.w, height: f.h }}
          >
            <span>+{f.count} more</span>
          </div>
        );
      })}
      {lines.map(
        ({ line, mid }, i) =>
          line.label && (
            <div
              key={i}
              data-label={i}
              className="absolute max-w-40 -translate-x-1/2 -translate-y-1/2 rounded-md bg-[#0b0b0d] px-2 text-center text-lg leading-tight text-balance text-neutral-300"
              style={{ left: mid.x, top: mid.y }}
            >
              {line.label}
            </div>
          ),
      )}
    </div>
  );
}

export function ZoomCardIcon({ icon, className }: { icon: ZoomIcon; className: string }) {
  if ("node" in icon) return <NodeIcon category={icon.node.category} itemId={icon.node.itemId} className={className} />;
  if ("badge" in icon) return <BadgeIconFor icon={icon.badge} className={className} />;
  const Glyph = GLYPHS[icon.glyph];
  return <Glyph className={className} />;
}

// A line of detail too long for its card, such as "Active/active · Virtual wire" on a narrow one, steps
// down a little before it's cut short.
function shrink(line: HTMLElement) {
  line.style.fontSize = "";
  const base = parseFloat(getComputedStyle(line).fontSize);
  for (let size = base - 1; line.scrollWidth > line.clientWidth && size >= base * 0.8; size--) line.style.fontSize = `${size}px`;
}

function Card(props: { card: ZoomCard; box: Box; narrow: boolean }) {
  const { card, box, narrow } = props;
  // Below 80px a card's text and icon step down, so it keeps a line or two of detail under its name.
  const crowded = box.h < 80;
  const detail = useRef<HTMLDivElement>(null);
  // The name keeps the first line of detail in view, such as an edge device's HA.
  const { box: row, name } = useFit<HTMLDivElement>(
    narrow || crowded ? 22 : 26,
    () => !detail.current?.firstElementChild || detail.current.clientHeight >= detail.current.firstElementChild.clientHeight,
    NAME_FIT,
  );
  useLayoutEffect(() => [...detail.current!.children].forEach((line) => shrink(line as HTMLElement)));
  return (
    <div
      className={cn(CARD, "flex flex-col justify-center px-5", card.quiet && QUIET)}
      style={{ left: box.x, top: box.y, width: box.w, height: box.h }}
    >
      <div ref={row} className={cn("flex items-center gap-3 font-semibold", narrow || crowded ? "text-[22px]" : "text-[26px]")}>
        <ZoomCardIcon icon={card.icon} className={cn("shrink-0 text-neutral-300", crowded ? "size-7" : "size-8")} />
        <span ref={name} className="line-clamp-2 flex-1 leading-tight">{whole(card.name)}</span>
        {card.count && <span className="tabular-nums">{card.count}</span>}
      </div>
      {card.stats.length > 0 && (
        <div className={cn("flex gap-4 tabular-nums text-neutral-300", narrow ? "text-xl" : "text-2xl")}>
          {card.stats.map((s) => {
            const Glyph = GLYPHS[s.glyph];
            return (
              <span key={s.glyph} className="flex items-center gap-1.5">
                <Glyph className="size-6 shrink-0 text-neutral-400" />
                {s.value}
              </span>
            );
          })}
        </div>
      )}
      {/* A line height in whole pixels lays out the same in a PNG. A narrow card's type keeps a line such
          as "Active/active · Redirect" whole. */}
      <Detail
        ref={detail}
        lines={card.detail}
        className={cn("justify-center", crowded ? "pl-10 text-base leading-5" : narrow ? "pl-11 text-base leading-6" : "pl-11 text-xl leading-6")}
      />
    </div>
  );
}
