import type { ReactNode } from "react";

export function Frame({
  logoUrl,
  title,
  subtitle,
  children,
}: {
  logoUrl: string | null;
  title: string;
  subtitle?: string | null;
  children: ReactNode;
}) {
  return (
    <div className="flex h-full flex-col gap-10 p-16">
      <header className="flex min-h-20 items-center gap-10">
        <div className="min-w-0 flex-1">
          <h2 className="text-5xl font-semibold">{title}</h2>
          {subtitle && <p className="text-2xl text-neutral-400">{subtitle}</p>}
        </div>
        {logoUrl && <Logo url={logoUrl} />}
      </header>
      <div className="min-h-0 flex-1">{children}</div>
    </div>
  );
}

export function Logo({ url, className }: { url: string; className?: string }) {
  // eslint-disable-next-line @next/next/no-img-element -- a data URL
  return <img src={url} alt="" className={`max-h-20 max-w-80 shrink-0 object-contain ${className ?? ""}`} />;
}
