import { countName } from "@/board/architecture";
import { ownRecords } from "@/board/attributes";
import type { ConcernRow } from "@/board/concerns";
import { DIRECT, directThrough } from "@/board/flows";
import { type LitGroup, named } from "@/board/lit-map";
import { type BoardData, type Entry, entriesIn } from "@/board/model";
import type { BoardTemplate } from "@/content/schema";

type Slot = BoardTemplate["slots"][number];
type Scalar = Exclude<Slot["attributes"][number], { type: "records" }>;

export type NoteEntry = {
  label: string;
  attrs: Record<string, unknown>;
  // The slot's declared attributes, written out, for boards whose entries carry fields.
  fields?: { name: string; value: string }[];
  note: string | null;
};
export type NotesData = {
  customer: string;
  // The meeting's date where the SE was.
  date: string;
  timeZone: string;
  startedAt: string;
  endedAt: string;
  // What the SE jotted about the meeting.
  memo: string | null;
  boards: { name: string; layout: BoardTemplate["layout"]; sections: { name: string; entries: NoteEntry[] }[] }[];
};

// High to low, then those with nothing said, then those that are not a concern, each in the board's order.
const rank = (level: number | null) => (level === null ? 0.5 : level === 0 ? -1 : level);
const ranked = (rows: ConcernRow<Entry>[]) => rows.toSorted((a, b) => rank(b.level) - rank(a.level));
const LEVEL_NAMES = ["Not a concern", "Low", "Medium", "High"];

export function buildNotes(input: {
  customer: string;
  timeZone: string;
  startedAt: Date;
  endedAt: Date;
  memo?: string | null;
  // A diagram is titled by its name.
  boards: { template: BoardTemplate; name?: string | null; data: BoardData; lit?: LitGroup[]; concerns?: { name: string; rows: ConcernRow<Entry>[] }[] }[];
  label: (e: Entry) => string;
  // Names of the catalog items fields pick, and labels of the entries they refer to.
  name: (itemId: string) => string;
  entry: (entryId: string) => string;
  category?: (itemId: string) => string | undefined;
}): NotesData {
  // A name the SE gives only qualifies the item, so both show, as in "Prod OU (AWS)".
  const label = (e: Entry) => {
    const name = typeof e.attrs.name === "string" && e.attrs.name;
    const item = input.label(e);
    return !name || name === item ? item : `${name} (${item})`;
  };
  // The room draws live entries only, so a reference to a ghost reads as unset and a record through one is dropped. An
  // entry whose zoom is on request and not added shows none of its fields, which wait for the zoom to come back.
  const ghosts = new Set(input.boards.flatMap((b) => b.data.entries.filter((e) => e.status !== "live").map((e) => e.id)));
  const ghost = (a: Scalar, value: unknown) => a.type === "ref" && ghosts.has(String(value));
  const shownAttrs = (slot: Slot, attrs: Entry["attrs"]): Entry["attrs"] => {
    const hidden = slot.zoomOnRequest && attrs.zoom !== true;
    const shown = { ...attrs };
    for (const a of slot.attributes) {
      if (hidden || (a.type !== "records" && ghost(a, attrs[a.key]))) delete shown[a.key];
      else if (a.type === "records" && Array.isArray(attrs[a.key]))
        shown[a.key] = (attrs[a.key] as Record<string, unknown>[]).filter((r) => !a.fields.some((f) => ghost(f, r[f.key])));
    }
    return shown;
  };
  // The entry's own records a field can point at, such as a cloud's networks.
  type Own = (key: string) => { id: string; name: string }[];
  const show = (a: Scalar, value: unknown, own: Own) =>
    value === null || value === undefined || value === ""
      ? ""
      : a.type === "pick"
        ? input.name(String(value))
        : a.type === "ref"
          ? input.entry(String(value))
          : a.type === "record"
            ? (own(a.of).find((r) => r.id === value)?.name ?? "")
            : a.type === "number"
              ? Number(value).toLocaleString("en-US")
              : String(value);
  // A record leads with its first field; later picks read together in brackets, a count as "×N", and a
  // reference last with its field's name, as in "Agent tunnel (Prisma Agent) to Prisma Access", or
  // to its own entry "between" it, as in "MPLS between Branches".
  const pointer = (f: Scalar) => f.type === "ref" || f.type === "record";
  const record = (fields: Scalar[], r: Record<string, unknown>, own: Own, self: string) => {
    const later = (f: Scalar, i: number) => f.type === "pick" && i > 0;
    const picks = fields.filter((f, i) => later(f, i)).map((f) => show(f, r[f.key], own)).filter(Boolean);
    let bracketed = false;
    const parts = fields.map((f, i) => {
      const shown = show(f, r[f.key], own);
      if (!shown || pointer(f)) return "";
      if (!later(f, i)) return f.key === "count" ? `×${shown}` : shown;
      if (bracketed) return "";
      bracketed = true;
      return `(${picks.join(", ")})`;
    });
    const refs = fields.filter((f) => pointer(f) && show(f, r[f.key], own));
    const lead = (f: Scalar) => (r[f.key] === self ? "between" : f.name.toLowerCase());
    return [...parts, ...refs.map((f) => `${lead(f)} ${show(f, r[f.key], own)}`)].filter(Boolean).join(" ");
  };
  // Records that are only a pick from a set order, such as a cloud's inspected flows, read in that order once each, as
  // the room shows them. Records with more to them, such as hosted apps, can share a pick or have none, so all read.
  const inOrder = (fields: Scalar[], records: Record<string, unknown>[]) => {
    const [only] = fields;
    if (fields.length !== 1 || only.type !== "pick" || !only.items) return records;
    return only.items.flatMap((item) => records.filter((r) => r[only.key] === item).slice(0, 1));
  };
  // A flow reads Direct as the builder shows it: as its how, or as its through point when it goes straight to where.
  const direct = (key: string, attrs: Entry["attrs"]) => (key === "how" && attrs.how === DIRECT) || (key === "through" && directThrough(attrs));
  const fields = (slot: Slot, e: Entry, attrs: Entry["attrs"], flow: boolean) => {
    const own: Own = (key) => ownRecords(slot, attrs, key);
    return slot.attributes
      .filter((a) => a.key !== "name")
      .map((a) => ({
        name: (a.key === "count" && e.itemId && countName(input.category?.(e.itemId))) || a.name,
        value:
          flow && direct(a.key, e.attrs)
            ? "Direct"
            : a.type === "records"
              ? inOrder(a.fields, (attrs[a.key] as Record<string, unknown>[] | undefined) ?? [])
                  .map((r) => record(a.fields, r, own, e.id))
                  .filter(Boolean)
                  .join("; ")
              : show(a, attrs[a.key], own),
      }))
      .filter((f) => f.value);
  };
  const board = ({ template, data, lit, concerns }: (typeof input.boards)[number]) => {
    if (concerns)
      return concerns.map((g) => ({
        name: g.name,
        // A concern in the customer's words was said, so it is listed with nothing picked too.
        entries: ranked(g.rows.filter((r) => r.level !== null || r.entry?.note || (r.entry && !r.itemId))).map((r) => ({
          label: r.entry ? label(r.entry) : input.name(r.itemId!),
          attrs: { level: r.level },
          note: r.entry?.note ?? null,
        })),
      }));
    if (lit)
      return lit.filter((g) => !g.hidden).map((g) => ({
        name: g.name,
        entries: g.capabilities
          .filter((c) => c.level > 0)
          .map((c) => ({ label: c.name, attrs: { level: c.level, concerns: c.concerns.filter(named).map((k) => k.label) }, note: null })),
      }));
    const flows = template.layout === "hub-and-spoke" ? template.flows : undefined;
    return template.slots.map((slot) => ({
      name: slot.name,
      entries: entriesIn(data, slot.id)
        .filter((e) => e.status === "live")
        .map((e) => {
          const attrs = shownAttrs(slot, e.attrs);
          return {
            label: label(e),
            attrs,
            ...(slot.attributes.length ? { fields: fields(slot, e, attrs, slot.id === flows) } : {}),
            note: e.note,
          };
        }),
    }));
  };
  return {
    customer: input.customer,
    // en-CA formats dates as YYYY-MM-DD.
    date: input.startedAt.toLocaleDateString("en-CA", { timeZone: input.timeZone }),
    timeZone: input.timeZone,
    startedAt: input.startedAt.toISOString(),
    endedAt: input.endedAt.toISOString(),
    memo: input.memo?.trim() || null,
    boards: input.boards.map((b) => ({ name: b.name ?? b.template.name, layout: b.template.layout, sections: board(b) })),
  };
}

const capitalize = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const ownerName = (owner: string) => (owner === "us" || owner === "them" ? capitalize(owner) : owner);

const dueDate = (due: string, meetingDate: string) =>
  new Date(due).toLocaleDateString("en-US", {
    timeZone: "UTC",
    month: "short",
    day: "numeric",
    ...(due.slice(0, 4) !== meetingDate.slice(0, 4) && { year: "numeric" }),
  });

export function entryDetails(layout: BoardTemplate["layout"], attrs: Record<string, unknown>, meetingDate: string): string[] {
  switch (layout) {
    case "ranked-list":
      return typeof attrs.level === "number" ? [LEVEL_NAMES[attrs.level]] : [];
    case "lit-map":
      return [`${attrs.level}/3`, (attrs.concerns as string[]).join(", ")].filter(Boolean);
    case "list":
      return [
        attrs.owner && ownerName(String(attrs.owner)),
        typeof attrs.due === "string" && attrs.due && dueDate(attrs.due, meetingDate),
        attrs.minutes && `${attrs.minutes} min`,
      ]
        .filter(Boolean)
        .map(String);
    default:
      return typeof attrs.mark === "string" ? [capitalize(attrs.mark)] : [];
  }
}

// Typed text keeps its lines. Markdown joins a paragraph's lines unless each ends in a hard break: two spaces, which unlike
// a backslash leave nothing behind when the next line starts a list instead.
const keepLines = (text: string) => text.split("\n").map((line, i, all) => (line.trim() && all[i + 1]?.trim() ? `${line}  ` : line));

export function notesMarkdown(notes: NotesData): string {
  const lines = [`# ${notes.customer}`, "", notes.date];
  if (notes.memo) lines.push("", ...keepLines(notes.memo));
  for (const board of notes.boards) {
    const filled = board.sections.filter((s) => s.entries.length);
    if (!filled.length) continue;
    lines.push("", `## ${board.name}`);
    for (const section of filled) {
      // A board of one list needs no heading for it.
      if (board.sections.length > 1) lines.push("", `**${section.name}**`);
      lines.push("");
      for (const e of section.entries) {
        lines.push(`- ${[e.label, ...entryDetails(board.layout, e.attrs, notes.date)].join(" · ")}`);
        lines.push(...(e.fields ?? []).map((f) => `  - ${f.name}: ${f.value}`));
        if (e.note) lines.push(...keepLines(e.note).map((l) => `  > ${l}`));
      }
    }
  }
  return lines.join("\n") + "\n";
}
