import { and, desc, eq, inArray, isNotNull, lte, or } from "drizzle-orm";
import { concernGroups, impliedConcerns, reattached } from "@/board/concerns";
import { templateById } from "@/board/data";
import { litMap } from "@/board/lit-map";
import { type BoardData, type Entry, type Op, applyOp, entriesIn, entryIds, zoomOf } from "@/board/model";
import { placed } from "@/board/propagation";
import { pickedIds } from "@/board/summary";
import { type BoardView, type ViewSource, concernsTemplate, litContent, sourcedView } from "@/board/view";
import { itemNames } from "@/catalog/data";
import { getContent, railSections } from "@/content/load";
import type { BoardTemplate } from "@/content/schema";
import { db } from "@/db";
import { boards, catalogItems, commits, customers, meetings, notes } from "@/db/schema";
import { moreZoom } from "@/meetings/data";
import { type NotesData, buildNotes, notesMarkdown } from "./notes";

const validZone = (timeZone: string) => {
  try {
    new Intl.DateTimeFormat("en", { timeZone });
    return true;
  } catch {
    return false;
  }
};

// A meeting's boards rebuilt from the commits: as they stood at its End, so changes made after the meeting never reach
// its notes, or while it runs, as they stand. Commits the meeting queued offline arrive after End and still count.
async function meetingRecord(ownerId: string, meetingId: string) {
  const [meeting] = await db
    .select({
      customerId: meetings.customerId,
      customer: customers.name,
      startedAt: meetings.startedAt,
      endedAt: meetings.endedAt,
      endSeq: meetings.endSeq,
      visited: meetings.visited,
      shown: meetings.shown,
      shownGroups: meetings.shownGroups,
      memo: meetings.memo,
      earlier: notes.data,
    })
    .from(meetings)
    .innerJoin(customers, eq(customers.id, meetings.customerId))
    .leftJoin(notes, eq(notes.meetingId, meetings.id))
    .where(and(eq(meetings.id, meetingId), eq(meetings.ownerId, ownerId)));
  if (!meeting) return null;
  const atEnd =
    meeting.endSeq !== null ? lte(commits.seq, meeting.endSeq) : meeting.endedAt && lte(commits.createdAt, meeting.endedAt);

  const [log, rows] = await Promise.all([
    db
      .select({ boardId: commits.boardId, op: commits.op, meetingId: commits.meetingId })
      .from(commits)
      .where(
        and(
          eq(commits.ownerId, ownerId),
          eq(commits.customerId, meeting.customerId),
          atEnd ? or(atEnd, eq(commits.meetingId, meetingId)) : undefined,
        ),
      )
      .orderBy(commits.seq),
    db
      .select({ id: boards.id, templateId: boards.templateId, name: boards.name, position: boards.position, entryId: boards.entryId })
      .from(boards)
      .where(and(eq(boards.ownerId, ownerId), eq(boards.customerId, meeting.customerId))),
  ]);
  const data = new Map<string, BoardData>();
  // The meeting each entry was added in, as the server records it.
  const addedIn = new Map<string, string | null>();
  const record = (op: Op, meeting: string | null) => {
    if (op.type === "batch") op.ops.forEach((o) => record(o, meeting));
    else if (op.type === "put") op.entries.forEach((e) => addedIn.set(e.id, meeting));
  };
  const changed = new Set<string>();
  for (const c of log) {
    data.set(c.boardId, applyOp(data.get(c.boardId) ?? { entries: [] }, c.op as Op));
    record(c.op as Op, c.meetingId);
    if (c.meetingId === meetingId) entryIds(c.op as Op).forEach((id) => changed.add(id));
  }

  const touched = new Set([...meeting.shown, ...log.filter((c) => c.meetingId === meetingId).map((c) => c.boardId)]);
  const order = railSections(getContent().clusters.map((c) => c.id)).flatMap((s) => s.boards);
  const shown = rows
    // A zoom holds no entries: its board's notes cover what it showed.
    .filter((b) => touched.has(b.id) && templateById(b.templateId) && templateById(b.templateId)!.layout !== "zoom")
    .sort((a, b) => order.indexOf(a.templateId) - order.indexOf(b.templateId) || (a.position ?? 0) - (b.position ?? 0));
  const templateOf = (boardId: string) => templateById(rows.find((r) => r.id === boardId)?.templateId ?? "");
  // A concern only an answer implies has no entry to name it.
  const presets = shown.flatMap((b) => {
    const template = templateById(b.templateId)!;
    return template.layout === "ranked-list" ? template.slots[0].presets : [];
  });
  // As in the room, boards still awaiting their return-visit choice at End light and imply nothing.
  const settled = [...data].filter(
    ([boardId, board]) =>
      meeting.visited.includes(boardId) ||
      !board.entries.some((e) => e.status === "live" && ![null, meetingId].includes(addedIn.get(e.id) ?? null)),
  );
  const pending = (templateId: string) =>
    rows.some((r) => r.templateId === templateId && data.has(r.id) && !settled.some(([boardId]) => boardId === r.id));
  const ids = [...new Set([...[...data.values()].flatMap((d) => d.entries.flatMap((e) => (e.itemId ? [e.itemId] : []))), ...presets])];
  const categories = new Map(
    ids.length
      ? (
          await db
            .select({ id: catalogItems.id, category: catalogItems.category })
            .from(catalogItems)
            .where(inArray(catalogItems.id, ids))
        ).map((r) => [r.id, r.category])
      : [],
  );
  const categoryOf = (id: string) => categories.get(id);
  const answered = settled.flatMap(([boardId, board]) =>
    templateOf(boardId) ? placed(boardId, templateOf(boardId)!, board, categoryOf) : [],
  );
  return { meeting, log, rows, data, changed, shown, templateOf, presets, settled, pending, categoryOf, answered };
}

type MeetingRecord = NonNullable<Awaited<ReturnType<typeof meetingRecord>>>;

// The date is the SE's, in the time zone given or kept from the last generation.
async function notesOf(record: MeetingRecord, timeZone?: string) {
  const { meeting, data, shown, templateOf, presets, settled, pending, categoryOf, answered } = record;
  const all = [...data.values()].flatMap((d) => d.entries);
  const names = await itemNames([
    ...new Set([
      ...[...data].flatMap(([boardId, board]) => (templateOf(boardId) ? pickedIds(templateOf(boardId)!, board) : [])),
      ...presets,
    ]),
  ]);
  const itemLabel = (e: Entry) => (e.itemId ? (names[e.itemId] ?? e.itemId) : e.text!);
  // A lit map's own entries hold levels too, so only a ranked list's count as concerns.
  const concerns = settled
    .filter(([boardId]) => templateOf(boardId)?.layout === "ranked-list")
    .flatMap(([, board]) => board.entries.filter((e) => e.status === "live"));
  const zone = [timeZone, (meeting.earlier as NotesData | null)?.timeZone].find((z) => z && validZone(z)) ?? "UTC";
  return buildNotes({
    customer: meeting.customer,
    timeZone: zone,
    startedAt: meeting.startedAt,
    endedAt: meeting.endedAt ?? new Date(),
    memo: meeting.memo,
    boards: shown.map((b) => {
      const template = templateById(b.templateId)!;
      const board = data.get(b.id) ?? { entries: [] };
      if (template.layout === "ranked-list") {
        const slot = template.slots[0];
        const groups = slot.categories.map((id) => getContent().categories.find((c) => c.id === id)!);
        const live = entriesIn(board, slot.id).filter((e) => e.status === "live");
        const implied = impliedConcerns(template, answered, getContent());
        return { template, name: b.name, data: board, concerns: concernGroups(slot, groups, live, categoryOf, implied) };
      }
      if (template.layout !== "lit-map") return { template, name: b.name, data: board };
      const overrides = board.entries.filter((e) => e.status === "live");
      const ranked = concernsTemplate(template);
      // While the ranked list awaits its return-visit choice, its concerns imply nothing, as in the room.
      const implied = ranked && !pending(ranked.id) ? impliedConcerns(ranked, answered, getContent()) : new Set<string>();
      return { template, data: board, lit: litMap({ ...litContent(template), concerns, implied, overrides }) };
    }),
    label: itemLabel,
    name: (id) => names[id] ?? id,
    category: categoryOf,
    entry: (id) => {
      const e = all.find((x) => x.id === id);
      return e ? (typeof e.attrs.name === "string" && e.attrs.name) || itemLabel(e) : "";
    },
  });
}

// Generated at End and kept; regenerating rebuilds the boards as they stood at End.
export async function generateNotes(ownerId: string, meetingId: string, timeZone?: string) {
  const record = await meetingRecord(ownerId, meetingId);
  if (!record?.meeting.endedAt) return null;
  const data = await notesOf(record, timeZone);
  const values = { meetingId, ownerId, markdown: notesMarkdown(data), data };
  await db
    .insert(notes)
    .values(values)
    .onConflictDoUpdate({ target: notes.meetingId, set: { markdown: values.markdown, data: values.data, generatedAt: new Date() } });
  return { ...values, customerId: record.meeting.customerId };
}

async function getNotes(ownerId: string, meetingId: string) {
  const [row] = await db
    .select({ markdown: notes.markdown, data: notes.data })
    .from(notes)
    .where(and(eq(notes.meetingId, meetingId), eq(notes.ownerId, ownerId)));
  return row ? { ...row, data: row.data as NotesData } : null;
}

export type MeetingNotes = { meetingId: string; running: boolean; markdown: string; data: NotesData };

export async function customerMeetings(ownerId: string, customerId: string) {
  const rows = await db
    .select({ id: meetings.id, startedAt: meetings.startedAt })
    .from(meetings)
    .where(and(eq(meetings.ownerId, ownerId), eq(meetings.customerId, customerId)))
    .orderBy(desc(meetings.startedAt));
  return rows.map((m) => ({ id: m.id, startedAt: m.startedAt.toISOString() }));
}

// While the meeting runs, its notes are built from the meeting so far. Once it has ended they are those generated at
// End, or generated now if that failed.
export async function meetingNotes(
  ownerId: string,
  customerId: string,
  meetingId: string,
  timeZone: string,
): Promise<MeetingNotes | null> {
  const [meeting] = await db
    .select({ endedAt: meetings.endedAt })
    .from(meetings)
    .where(and(eq(meetings.id, meetingId), eq(meetings.ownerId, ownerId), eq(meetings.customerId, customerId)));
  if (!meeting) return null;
  if (meeting.endedAt) {
    const stored = (await getNotes(ownerId, meetingId)) ?? (await generateNotes(ownerId, meetingId, timeZone));
    return stored && { meetingId, running: false, markdown: stored.markdown, data: stored.data };
  }
  const record = await meetingRecord(ownerId, meetingId);
  if (!record) return null;
  const data = await notesOf(record, timeZone);
  return { meetingId, running: !record.meeting.endedAt, markdown: notesMarkdown(data), data };
}

export async function regenerateNotes(ownerId: string, customerId: string, meetingId: string, timeZone: string) {
  const generated = await generateNotes(ownerId, meetingId, timeZone);
  return generated?.customerId === customerId ? meetingNotes(ownerId, customerId, meetingId, timeZone) : null;
}

export async function saveMemo(ownerId: string, customerId: string, meetingId: string, memo: string, timeZone: string) {
  const [meeting] = await db
    .update(meetings)
    .set({ memo: memo.trim() ? memo : null })
    .where(and(eq(meetings.id, meetingId), eq(meetings.ownerId, ownerId), eq(meetings.customerId, customerId)))
    .returning({ endedAt: meetings.endedAt });
  if (!meeting) return null;
  if (meeting.endedAt) await generateNotes(ownerId, meetingId, timeZone);
  return meetingNotes(ownerId, customerId, meetingId, timeZone);
}

export type PackBoard = { name: string; view: BoardView };

// Whether a board's picture shows anything: an entry, a concern or capability at 1 or more, or on an entry's zoom
// anything besides that entry.
function holds(view: BoardView, entryId?: string) {
  switch (view.layout) {
    case "grid":
      return [view.strip, ...view.rows.flat()].some((slot) => slot?.entries.length);
    case "ranked-list":
      return view.concerns.some((c) => (c.level ?? 0) > 0);
    case "lit-map":
      return view.groups.some((g) => g.capabilities.some((c) => c.level > 0));
    case "lit-group":
      return view.capabilities.some((c) => c.level > 0);
    case "list":
      return view.steps.length > 0;
    case "hub-and-spoke":
      return view.nodes.length > 0;
    case "zoom":
      return [...view.inspected, ...view.tiles, ...view.columns.flat()].some((c) => !c.quiet && c.id !== entryId);
    case "ai-app":
      return [view.users, ...view.rows.map((r) => r.names), ...Object.values(view.at)].some((list) => list.length > 0);
  }
}

// Each board the meeting touched that holds anything, as the room showed it at End, or shows it while the meeting runs:
// a board in groups once for each group holding anything, the summary once for each diagram, and after its board the zoom
// of each entry, on the summary its "+N more", or on the lit map each capability group, the room showed or the meeting
// changed, named on the summary for its diagram too.
export async function meetingBoards(ownerId: string, customerId: string, meetingId: string): Promise<PackBoard[] | null> {
  const record = await meetingRecord(ownerId, meetingId);
  if (!record || record.meeting.customerId !== customerId) return null;
  const { meeting, log, rows, data, changed, shown, templateOf, settled, pending, categoryOf, answered } = record;
  const routed = new Set(getContent().items.filter((i) => i.routes.length).map((i) => i.id));
  const source: ViewSource = {
    data: async (boardId) => data.get(boardId) ?? { entries: [] },
    async zoomSource(zoom, entryId) {
      for (const [boardId, board] of data) {
        const entry = board.entries.find((e) => e.id === entryId);
        const template = templateOf(boardId);
        if (!entry || !template) continue;
        return zoomOf(template, entry.slot, entry.itemId && categoryOf(entry.itemId), entry.attrs) === zoom.id
          ? { boardId, template, name: rows.find((r) => r.id === boardId)!.name }
          : null;
      }
      return null;
    },
    implied: async (template) => (pending(template.id) ? new Set<string>() : impliedConcerns(template, answered, getContent())),
    concerns: async () =>
      settled
        .flatMap(([, board]) => board.entries)
        .filter((e) => e.status === "live" && ((e.itemId && routed.has(e.itemId)) || "routes" in e.attrs))
        .sort((a, b) => a.position - b.position),
    diagramName: async (boardId) => rows.find((r) => r.id === boardId)?.name ?? null,
  };

  const opened = new Set(rows.flatMap((r) => (r.entryId && meeting.shown.includes(r.id) ? [r.entryId] : [])));
  const attached = new Set(log.flatMap((c) => (c.meetingId === meetingId ? reattached(c.op as Op) : [])));
  const view = (template: BoardTemplate, boardId: string | null, pane: number, entryId: string | null = null) =>
    sourcedView(source, template, boardId, { pane }, entryId);
  const pictures = shown.flatMap((b): Promise<PackBoard | null>[] => {
    const template = templateById(b.templateId)!;
    const board = data.get(b.id) ?? { entries: [] };
    const groups =
      template.layout === "grid"
        ? (template.groups?.length ?? 0)
        : template.layout === "ranked-list"
          ? template.slots[0].categories.length
          : 0;
    const own = (groups ? [...Array(groups).keys()] : [0]).map((pane) =>
      view(template, b.id, pane).then((v) =>
        v && "name" in v && holds(v) ? { name: [template.name, groups ? v.name : b.name].filter(Boolean).join(" "), view: v } : null,
      ),
    );
    const more =
      template.layout === "hub-and-spoke" && template.more
        ? [
            view(template, b.id, 1).then((v) =>
              v?.layout === "zoom" &&
              holds(v) &&
              (meeting.shownGroups.includes(moreZoom(b.id)) || v.columns.flat().some((c) => changed.has(c.id)))
                ? { name: [b.name, "more"].filter(Boolean).join(" "), view: v }
                : null,
            ),
          ]
        : [];
    const zooms = template.slots.flatMap((slot) =>
      entriesIn(board, slot.id).flatMap((e) => {
        const touched = (opened.has(e.id) || changed.has(e.id)) && e.status === "live";
        const zoom = touched && zoomOf(template, slot.id, e.itemId && categoryOf(e.itemId), e.attrs);
        if (!zoom) return [];
        return [
          view(templateById(zoom)!, null, 0, e.id).then((v) =>
            (v?.layout === "zoom" || v?.layout === "ai-app") && holds(v, e.id)
              ? { name: [b.name, v.title].filter(Boolean).join(" "), view: v }
              : null,
          ),
        ];
      }),
    );
    // A level the meeting forced counts as an entry's change does, while the room still shows it, so a return visit's
    // ghosting or clean start changes no group. A hidden group's pane shows the map, as the room does, so gives no zoom.
    const reshaped = (id: string) =>
      attached.has(id) || board.entries.some((e) => e.itemId === id && e.status === "live" && changed.has(e.id));
    const groupZooms =
      template.layout === "lit-map"
        ? template.slots[0].presets.flatMap((group, i) =>
            meeting.shownGroups.includes(group) || getContent().items.some((c) => c.group === group && reshaped(c.id))
              ? [view(template, b.id, i + 1).then((v) => (v?.layout === "lit-group" && holds(v) ? { name: v.name, view: v } : null))]
              : [],
          )
        : [];
    return [...own, ...more, ...zooms, ...groupZooms];
  });
  return (await Promise.all(pictures)).filter((p) => p !== null);
}

// A commit queued offline can reach the server after its meeting ended; its notes catch up.
export async function refreshEndedNotes(ownerId: string, meetingIds: string[]) {
  if (!meetingIds.length) return;
  const ended = await db
    .select({ id: meetings.id })
    .from(meetings)
    .where(and(eq(meetings.ownerId, ownerId), inArray(meetings.id, meetingIds), isNotNull(meetings.endedAt)));
  for (const { id } of ended) await generateNotes(ownerId, id);
}
