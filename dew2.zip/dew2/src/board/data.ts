import { randomUUID } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { type SQL, and, eq, inArray, isNotNull, isNull, ne, sql } from "drizzle-orm";
import { getContent } from "@/content/load";
import type { BoardTemplate } from "@/content/schema";
import { db } from "@/db";
import { boards, catalogItems, commits, customers, entries, meetings } from "@/db/schema";
import { type Tx, transaction } from "@/db/transaction";
import { attrsSchema, copyEntries } from "./attributes";
import { type BoardData, type Commit, type Diagram, type Entry, type Op, invert, undoStacks, zoomOf } from "./model";
import { type Placed, placed } from "./propagation";

export const templateById = (id: string) => getContent().templates.find((t) => t.id === id);

// A board is made real the first time it is opened. The summary's diagrams are boards of their own; see ensureDiagrams.
export async function ensureBoard(ownerId: string, customerId: string, templateId: string) {
  const mine = and(
    eq(boards.ownerId, ownerId),
    eq(boards.customerId, customerId),
    eq(boards.templateId, templateId),
    isNull(boards.entryId),
    isNull(boards.name),
  );
  const [existing] = await db.select({ id: boards.id }).from(boards).where(mine);
  if (existing) return existing.id;
  await db
    .insert(boards)
    .values({ ownerId, customerId, templateId })
    .onConflictDoNothing({ target: [boards.customerId, boards.templateId], where: and(isNull(boards.entryId), isNull(boards.name)) });
  const [created] = await db.select({ id: boards.id }).from(boards).where(mine);
  return created.id;
}

export async function boardTemplate(ownerId: string, boardId: string) {
  const [row] = await db
    .select({ templateId: boards.templateId })
    .from(boards)
    .where(and(eq(boards.id, boardId), eq(boards.ownerId, ownerId)));
  return row && templateById(row.templateId);
}

// The board whose entry a zoom board zooms from.
export async function zoomedFrom(ownerId: string, zoomBoardId: string) {
  const [row] = await db
    .select({ boardId: entries.boardId })
    .from(boards)
    .innerJoin(entries, and(eq(entries.id, boards.entryId), eq(entries.ownerId, boards.ownerId)))
    .where(and(eq(boards.id, zoomBoardId), eq(boards.ownerId, ownerId)));
  return row?.boardId;
}

// The board an entry is on and the zoom it opens, if any. A zoom on request counts only once added, unless `unadded`.
async function entryZoom(ownerId: string, customerId: string, entryId: string, { unadded = false } = {}) {
  const [row] = await db
    .select({
      boardId: entries.boardId,
      slot: entries.slot,
      attrs: entries.attrs,
      templateId: boards.templateId,
      name: boards.name,
      category: catalogItems.category,
    })
    .from(entries)
    .innerJoin(boards, eq(boards.id, entries.boardId))
    .leftJoin(catalogItems, eq(catalogItems.id, entries.itemId))
    .where(and(eq(entries.id, entryId), eq(entries.ownerId, ownerId), eq(entries.customerId, customerId)));
  const template = row && templateById(row.templateId);
  const zoom = template && zoomOf(template, row.slot, row.category, unadded ? { zoom: true } : (row.attrs as Entry["attrs"]));
  return template && zoom ? { boardId: row.boardId, template, name: row.name, zoom: templateById(zoom)! } : null;
}

// The zoom follows the content, should it map the entry's category to another. A zoom on request is made before
// the commit adding it may have landed, so the cockpit decides from its own data whether the entry zooms.
export async function ensureZoomBoard(ownerId: string, customerId: string, entryId: string) {
  const found = await entryZoom(ownerId, customerId, entryId, { unadded: true });
  if (!found) return null;
  const [board] = await db
    .insert(boards)
    .values({ ownerId, customerId, templateId: found.zoom.id, entryId })
    .onConflictDoUpdate({ target: boards.entryId, targetWhere: isNotNull(boards.entryId), set: { templateId: found.zoom.id } })
    .returning({ id: boards.id });
  return { id: board.id, template: found.zoom };
}

// A zoom holds no entries: it shows those of the board its entry is on, with that board's name if it is a diagram.
export async function zoomSource(ownerId: string, customerId: string, zoom: BoardTemplate, entryId: string) {
  const found = await entryZoom(ownerId, customerId, entryId);
  return found?.zoom.id === zoom.id ? { boardId: found.boardId, template: found.template, name: found.name } : null;
}

const diagramsOf = (ownerId: string, customerId: string, templateId: string) =>
  and(
    eq(boards.ownerId, ownerId),
    eq(boards.customerId, customerId),
    eq(boards.templateId, templateId),
    isNull(boards.entryId),
    isNotNull(boards.name),
  );
const lockCustomer = (tx: Tx, ownerId: string, customerId: string) =>
  tx.select({ id: customers.id }).from(customers).where(and(eq(customers.id, customerId), eq(customers.ownerId, ownerId))).for("update");
const diagramColumns = { id: boards.id, name: boards.name, position: boards.position };

// A template's diagrams in order. A customer starts with one, Today, made the first time it's asked for.
export async function ensureDiagrams(ownerId: string, customerId: string, templateId: string): Promise<Diagram[]> {
  const list = () => db.select(diagramColumns).from(boards).where(diagramsOf(ownerId, customerId, templateId)).orderBy(boards.position);
  const found = await list();
  if (found.length) return found as Diagram[];
  await transaction(async (tx) => {
    await lockCustomer(tx, ownerId, customerId);
    const [any] = await tx.select({ id: boards.id }).from(boards).where(diagramsOf(ownerId, customerId, templateId));
    if (!any) await tx.insert(boards).values({ ownerId, customerId, templateId, name: "Today", position: 0 });
  });
  return (await list()) as Diagram[];
}

// A new diagram after the others, blank or a copy of one of them. The copy is a commit, so notes replay it and it
// belongs to the meeting running, for its return visits; adding a diagram can't be undone, so undo passes it by.
export async function addDiagram(
  ownerId: string,
  customerId: string,
  templateId: string,
  diagram: { name: string; copyOf?: string },
  meetingId: string | null,
) {
  const template = templateById(templateId);
  if (template?.layout !== "hub-and-spoke") return null;
  return transaction(async (tx) => {
    await lockCustomer(tx, ownerId, customerId);
    const existing = await tx.select(diagramColumns).from(boards).where(diagramsOf(ownerId, customerId, templateId));
    if (diagram.copyOf && !existing.some((d) => d.id === diagram.copyOf)) return null;
    const position = Math.max(-1, ...existing.map((d) => d.position ?? 0)) + 1;
    const [board] = await tx
      .insert(boards)
      .values({ ownerId, customerId, templateId, name: diagram.name, position })
      .returning({ id: boards.id });
    if (diagram.copyOf) {
      const source = await tx.select(entryColumns).from(entries).where(and(eq(entries.ownerId, ownerId), eq(entries.boardId, diagram.copyOf)));
      const copied = copyEntries(template, source as Entry[]);
      if (copied.length) {
        const op: Op = { type: "put", entries: copied, copy: true };
        const done = await commitIn(tx, ownerId, customerId, { id: randomUUID(), boardId: board.id, op, reverts: null, meetingId }, { exact: true });
        if ("rejected" in done) throw new Error(`copy rejected: ${done.rejected}`);
      }
    }
    return board.id;
  });
}

// Deleting a diagram takes its entries, zooms and commits with it; it can't be undone, and the last one stays.
export async function deleteDiagram(ownerId: string, customerId: string, id: string) {
  return transaction(async (tx) => {
    await lockCustomer(tx, ownerId, customerId);
    const [self] = await tx.select({ templateId: boards.templateId }).from(boards).where(and(eq(boards.id, id), eq(boards.ownerId, ownerId), isNotNull(boards.name)));
    if (!self) return false;
    const others = await tx.select({ id: boards.id }).from(boards).where(and(diagramsOf(ownerId, customerId, self.templateId), ne(boards.id, id)));
    if (!others.length) return false;
    await tx.delete(commits).where(and(eq(commits.ownerId, ownerId), eq(commits.boardId, id)));
    await tx.delete(boards).where(eq(boards.id, id));
    return true;
  });
}

const entryColumns = {
  id: entries.id,
  slot: entries.slot,
  position: entries.position,
  itemId: entries.itemId,
  text: entries.text,
  attrs: entries.attrs,
  note: entries.note,
  status: entries.status,
};

export async function boardData(ownerId: string, boardId: string): Promise<BoardData> {
  const rows = await db.select(entryColumns).from(entries).where(and(eq(entries.ownerId, ownerId), eq(entries.boardId, boardId)));
  return { entries: rows as Entry[] };
}

// The catalog items live on the customer's boards, but for one, such as the board that is open, or only on boards of these templates.
export async function placedOn(
  ownerId: string,
  customerId: string,
  { except, templates }: { except?: string; templates?: string[] },
): Promise<Placed[]> {
  if (templates && !templates.length) return [];
  const rows = await db
    .select({ ...entryColumns, boardId: entries.boardId, templateId: boards.templateId, category: catalogItems.category })
    .from(entries)
    .innerJoin(boards, eq(boards.id, entries.boardId))
    .leftJoin(catalogItems, eq(catalogItems.id, entries.itemId))
    .where(
      and(
        eq(entries.ownerId, ownerId),
        eq(entries.customerId, customerId),
        except ? ne(entries.boardId, except) : undefined,
        templates ? inArray(boards.templateId, templates) : undefined,
      ),
    );
  const categories = new Map(rows.map((r) => [r.itemId, r.category ?? undefined]));
  return [...new Set(rows.map((r) => r.boardId))].flatMap((id) => {
    const onBoard = rows.filter((r) => r.boardId === id);
    const template = templateById(onBoard[0].templateId);
    return template ? placed(id, template, { entries: onBoard as Entry[] }, (itemId) => categories.get(itemId)) : [];
  });
}

// The customer's boards that hold entries, for the rail's dots. A dismissed
// suggestion is stored as an entry but holds nothing.
export async function boardsWithEntries(ownerId: string, customerId: string) {
  return db
    .selectDistinct({ id: boards.id, templateId: boards.templateId })
    .from(boards)
    .innerJoin(entries, eq(entries.boardId, boards.id))
    .where(
      and(
        eq(boards.ownerId, ownerId),
        eq(boards.customerId, customerId),
        isNull(boards.entryId),
        ne(entries.status, "dismissed"),
      ),
    );
}

export type CommitResult = { id: string; seq: number } | { id: string; rejected: string };

export const applyCommit = (ownerId: string, customerId: string, commit: Commit) =>
  transaction((tx) => commitIn(tx, ownerId, customerId, commit));

// A commit made for the SE rather than by them, such as an approval, leaves the
// customer where it was in their list.
export async function commitIn(
  tx: Tx,
  ownerId: string,
  customerId: string,
  commit: Commit,
  // exact: the entries are the server's own, such as a diagram's copy, so a slot that has since narrowed still takes them.
  { bySe = true, exact = false } = {},
): Promise<CommitResult> {
  const customer = and(eq(customers.id, customerId), eq(customers.ownerId, ownerId));
  // One customer's commits take turns, so a commit sent twice at once lands once.
  await tx.select({ id: customers.id }).from(customers).where(customer).for("update");
  const [done] = await tx
    .select({ seq: commits.seq })
    .from(commits)
    .where(and(eq(commits.id, commit.id), eq(commits.ownerId, ownerId)));
  if (done) return { id: commit.id, seq: done.seq };

  const [board] = await tx
    .select({ templateId: boards.templateId })
    .from(boards)
    .where(and(eq(boards.id, commit.boardId), eq(boards.customerId, customerId), eq(boards.ownerId, ownerId)));
  const [meeting] = commit.meetingId
    ? await tx
        .select({ id: meetings.id })
        .from(meetings)
        .where(and(eq(meetings.id, commit.meetingId), eq(meetings.customerId, customerId), eq(meetings.ownerId, ownerId)))
    : [];
  if (!board) return { id: commit.id, rejected: "unknown board" };
  if (commit.meetingId && !meeting) return { id: commit.id, rejected: "unknown meeting" };

  const record = async (c: Commit) => {
    const [{ seq }] = await tx
      .update(customers)
      .set({ seq: sql`${customers.seq} + 1`, ...(bySe && { lastActiveAt: sql`now()` }) })
      .where(customer)
      .returning({ seq: customers.seq });
    await tx.insert(commits).values({ ...c, customerId, ownerId, seq });
    if (c.op.type === "diagrams") await writeDiagrams(tx, diagramsOf(ownerId, customerId, board.templateId), c.op);
    else await write(tx, { ownerId, customerId, boardId: c.boardId, meetingId: c.meetingId }, c.op);
    return seq;
  };
  // Undo and redo revert the top of their stack. A revert of anything else was made before the
  // cockpit saw a commit that has landed since, such as an approval, and would be taken as a new step.
  let restoring = exact;
  if (commit.reverts && commit.meetingId) {
    const made = (await tx
      .select({ id: commits.id, reverts: commits.reverts, boardId: commits.boardId, op: commits.op })
      .from(commits)
      .where(and(eq(commits.ownerId, ownerId), eq(commits.meetingId, commit.meetingId)))
      .orderBy(commits.seq)) as Pick<Commit, "id" | "reverts" | "boardId" | "op">[];
    const { undo, redo } = undoStacks(made);
    if (![undo.at(-1)?.id, redo.at(-1)?.id].includes(commit.reverts)) return { id: commit.id, rejected: "stale undo" };
    // An exact revert brings back what the server once accepted, even an entry its slot no longer
    // takes, such as a product kept in a field that has since narrowed.
    const reverted = made.find((c) => c.id === commit.reverts)!;
    restoring = reverted.boardId === commit.boardId && isDeepStrictEqual(commit.op, invert(reverted.op));
  }
  const problem = await check(tx, board.templateId, commit.boardId, commit.op, restoring);
  if (!problem) return { id: commit.id, seq: await record(commit) };

  // A revert that can't apply would be tried again on every press. An empty revert in its
  // place moves the stack past that step, while the cockpit still reloads to what the server has.
  if (commit.reverts && commit.meetingId) await record({ ...commit, id: randomUUID(), op: { type: "update", updates: [] } });
  return { id: commit.id, rejected: problem };
}

async function check(tx: Tx, templateId: string, boardId: string, op: Op, restoring: boolean): Promise<string | null> {
  if (op.type === "batch") {
    for (const part of op.ops) {
      const problem = await check(tx, templateId, boardId, part, restoring);
      if (problem) return problem;
    }
    return null;
  }
  const template = templateById(templateId);
  if (!template) return "unknown board";
  // Attributes are checked against the entry's slot; entries not on the board change nothing anyway,
  // and a slot the board lacks is fits()'s to report.
  const named = new Map(op.type === "put" ? op.entries.map((e) => [e.id, e.slot]) : []);
  const changed =
    op.type === "update"
      ? op.updates.filter((u) => u.set.attrs !== undefined).map((u) => ({ entryId: u.entryId, attrs: u.set.attrs }))
      : op.type === "put"
        ? op.entries.map((e) => ({ entryId: e.id, attrs: e.attrs }))
        : [];
  const unknown = changed.map((c) => c.entryId).filter((id) => !named.has(id));
  if (unknown.length)
    for (const row of await tx
      .select({ id: entries.id, slot: entries.slot })
      .from(entries)
      .where(and(eq(entries.boardId, boardId), inArray(entries.id, unknown))))
      named.set(row.id, row.slot);
  for (const c of changed) {
    const slot = named.get(c.entryId);
    if (slot && template.slots.some((s) => s.id === slot) && !attrsSchema(template, slot).safeParse(c.attrs).success)
      return "attributes don't fit the board";
  }

  if (op.type === "put") return fits(tx, template, op.entries, restoring);
  if (op.type !== "update") return null;
  const relinked = op.updates.filter((u) => u.set.itemId !== undefined || u.set.text !== undefined);
  if (!relinked.length) return null;
  const rows = await tx
    .select({ id: entries.id, slot: entries.slot, itemId: entries.itemId, text: entries.text })
    .from(entries)
    .where(and(eq(entries.boardId, boardId), inArray(entries.id, relinked.map((u) => u.entryId))));
  return fits(
    tx,
    template,
    rows.map((row) => {
      const { set } = relinked.find((u) => u.entryId === row.id)!;
      return { slot: row.slot, itemId: set.itemId === undefined ? row.itemId : set.itemId, text: set.text === undefined ? row.text : set.text };
    }),
    restoring,
  );
}

// Each entry is a catalog item its slot accepts, or free text.
async function fits(
  tx: Tx,
  template: BoardTemplate,
  list: { slot: string; itemId: string | null; text: string | null }[],
  restoring: boolean,
) {
  const slots = new Map(template.slots.map((s) => [s.id, s]));
  const itemIds = list.flatMap((e) => (e.itemId ? [e.itemId] : []));
  const categories = new Map(
    itemIds.length
      ? (
          await tx
            .select({ id: catalogItems.id, category: catalogItems.category })
            .from(catalogItems)
            .where(inArray(catalogItems.id, itemIds))
        ).map((i) => [i.id, i.category])
      : [],
  );
  for (const e of list) {
    const slot = slots.get(e.slot);
    if (!slot) return `unknown slot "${e.slot}"`;
    if ((e.itemId === null) === (e.text === null)) return "an entry is a catalog item or free text";
    if (e.itemId) {
      const category = categories.get(e.itemId);
      if (!category) return `unknown catalog item "${e.itemId}"`;
      if (!restoring && slot.categories.length && !slot.categories.includes(category))
        return `slot "${e.slot}" does not accept "${e.itemId}"`;
    }
  }
  return null;
}

// A rename or move is limited to the diagrams its board is among, so ids from elsewhere change nothing.
async function writeDiagrams(tx: Tx, among: SQL | undefined, op: Extract<Op, { type: "diagrams" }>) {
  for (const u of op.updates.filter((u) => Object.keys(u.set).length))
    await tx.update(boards).set(u.set).where(and(eq(boards.id, u.boardId), among));
}

// Every write is limited to the commit's board and owner, so ids from elsewhere change nothing.
async function write(
  tx: Tx,
  scope: { ownerId: string; customerId: string; boardId: string; meetingId: string | null },
  op: Exclude<Op, { type: "diagrams" }>,
): Promise<void> {
  const onBoard = and(eq(entries.ownerId, scope.ownerId), eq(entries.boardId, scope.boardId));

  switch (op.type) {
    case "batch":
      for (const part of op.ops) await write(tx, scope, part);
      return;
    case "put": {
      if (op.entries.length)
        await tx
          .insert(entries)
          .values(op.entries.map((e) => ({ ...e, ...scope })))
          .onConflictDoUpdate({
            target: entries.id,
            set: {
              slot: sql`excluded.slot`,
              position: sql`excluded.position`,
              itemId: sql`excluded.item_id`,
              text: sql`excluded.text`,
              attrs: sql`excluded.attrs`,
              note: sql`excluded.note`,
              status: sql`excluded.status`,
            },
            setWhere: onBoard,
          });
      return;
    }
    case "delete": {
      const ids = op.entries.map((e) => e.id);
      if (ids.length) await tx.delete(entries).where(and(onBoard, inArray(entries.id, ids)));
      return;
    }
    case "update":
      for (const u of op.updates.filter((u) => Object.keys(u.set).length))
        await tx
          .update(entries)
          .set(u.set)
          .where(and(onBoard, eq(entries.id, u.entryId)));
      return;
  }
}

export const meetingCommits = (ownerId: string, meetingId: string) =>
  db
    .select({
      id: commits.id,
      boardId: commits.boardId,
      op: commits.op,
      reverts: commits.reverts,
      meetingId: commits.meetingId,
    })
    .from(commits)
    .where(and(eq(commits.ownerId, ownerId), eq(commits.meetingId, meetingId)))
    .orderBy(commits.seq) as Promise<Commit[]>;
