import { z } from "zod";
import type { BoardTemplate } from "@/content/schema";
import { type Entry, MARKS, layoutAttrs } from "./model";

const ZONES = ["top", "left", "right", "bottom"] as const;
export type Zone = (typeof ZONES)[number];

type Attribute = BoardTemplate["slots"][number]["attributes"][number];
type Scalar = Exclude<Attribute, { type: "records" }>;

const scalar = (a: Scalar) => {
  switch (a.type) {
    case "number":
      return z.number().min(0).max(1e9);
    case "text":
      return z.string().trim().max(200);
    case "pick":
      return z.string().min(1).max(100);
    case "ref":
    case "record":
      return z.uuid();
  }
};

// An entry's records of one attribute that its record fields can point at, each named by its first text field.
export function ownRecords(slot: BoardTemplate["slots"][number], attrs: Entry["attrs"], key: string) {
  const a = slot.attributes.find((x) => x.key === key);
  const text = a?.type === "records" ? a.fields.find((f) => f.type === "text")?.key : undefined;
  const rows = Array.isArray(attrs[key]) ? (attrs[key] as Record<string, unknown>[]) : [];
  return rows.flatMap((r) => {
    const name = text && r[text];
    return typeof name === "string" && name ? [{ id: String(r.id), name }] : [];
  });
}

// A field the SE cleared, or a copy's reference to an entry it didn't copy, is null.
const field = (a: Attribute) =>
  (a.type === "records"
    ? z.array(z.strictObject({ id: z.uuid(), ...Object.fromEntries(a.fields.map((f) => [f.key, scalar(f).nullable().optional()])) })).max(100)
    : scalar(a)
  )
    .nullable()
    .optional();

// Where the SE moved a node, which node is the hub and the Prisma Access a Prisma SD-WAN is grouped with,
// set from the cockpit rather than typed.
const placement = {
  zone: z.enum(ZONES).nullable().optional(),
  order: z.number().nullable().optional(),
  hub: z.boolean().nullable().optional(),
  group: z.uuid().nullable().optional(),
};

// What an entry of the slot may keep in its attributes.
export function attrsSchema(template: BoardTemplate, slotId: string): z.ZodType {
  if (template.layout in layoutAttrs) return layoutAttrs[template.layout as keyof typeof layoutAttrs];
  const slot = template.slots.find((s) => s.id === slotId);
  if (!slot) return z.never();
  return z.strictObject({
    ...Object.fromEntries(slot.attributes.map((a) => [a.key, field(a)])),
    ...(template.layout === "hub-and-spoke" ? placement : {}),
    ...(template.layout === "grid" ? { mark: z.enum(MARKS).optional() } : {}),
    ...(slot.zoomOnRequest ? { zoom: z.literal(true).optional() } : {}),
  });
}

// A diagram's entries under fresh ids, every reference pointing at the copy's own entries; one to an entry not copied
// is cleared. Records keep their ids, which are only unique within their entry.
export function copyEntries(template: BoardTemplate, entries: Entry[], newId = () => crypto.randomUUID()): Entry[] {
  const ids = new Map(entries.map((e) => [e.id, newId()]));
  const to = (value: unknown) => (typeof value === "string" ? (ids.get(value) ?? null) : value);
  return entries.map((e) => {
    const attrs = { ...e.attrs };
    for (const a of template.slots.find((s) => s.id === e.slot)?.attributes ?? []) {
      if (a.type === "ref" && a.key in attrs) attrs[a.key] = to(attrs[a.key]);
      if (a.type === "records" && Array.isArray(attrs[a.key])) {
        const refs = a.fields.filter((f) => f.type === "ref").map((f) => f.key);
        if (refs.length)
          attrs[a.key] = (attrs[a.key] as Record<string, unknown>[]).map((r) =>
            Object.fromEntries(Object.entries(r).map(([k, v]) => [k, refs.includes(k) ? to(v) : v])),
          );
      }
    }
    if (template.layout === "hub-and-spoke" && "group" in attrs) attrs.group = to(attrs.group);
    return { ...e, id: ids.get(e.id)!, attrs };
  });
}
