import type { BoardTemplate } from "@/content/schema";
import { type Connection, connectionTypes } from "./architecture";
import { type BoardData, type Entry, type Op, addOp, ensureOp, entriesIn, opChain, sameValue, setAttrOp, updateOp } from "./model";
import { type CatalogLookup, type FlowPath, type Named, type SummaryView, list, nodeName, nodesAt } from "./summary";

type Template = Extract<BoardTemplate, { layout: "hub-and-spoke" }>;

// Going direct: a site's local breakout, or for people and partners their own internet, which draws no line.
export const DIRECT = "conn-local-internet";

const KEYS = ["who", "how", "through", "where", "app"] as const;
type Key = (typeof KEYS)[number];
export type Flow = { id: string; name: string } & Record<Key, string | null>;

const picks = (attrs: Entry["attrs"]) =>
  Object.fromEntries(KEYS.map((k) => [k, typeof attrs[k] === "string" && attrs[k] ? attrs[k] : null])) as Record<Key, string | null>;
const flowOf = (e: Entry): Flow => ({ id: e.id, name: e.text ?? "", ...picks(e.attrs) });

// The diagram's saved flows.
export const flowsAt = (template: Template, data: BoardData): Flow[] => (template.flows ? entriesIn(data, template.flows).map(flowOf) : []);

// A flow reaching where with no through point goes direct as its through, as the builder shows it.
export const directThrough = (attrs: Entry["attrs"]) => !attrs.through && !!attrs.where && !!attrs.how && attrs.how !== DIRECT;

// A line joins two nodes whichever end it was entered on.
const joins = (l: { from: string; to?: string | null }, a: string, b: string) => (l.from === a && l.to === b) || (l.from === b && l.to === a);

// The line a flow's first leg lights: every breakout of who when it goes direct, else the line joining who and its through
// point, or where the app lives, of the type it picked, else the first such line; none lights nothing.
export function legOf(view: SummaryView, flow: Flow): string[] {
  const { who, how, through, where } = flow;
  const target = through ?? where;
  if (who && how === DIRECT) return view.lines.filter((l) => l.from === who && l.type === DIRECT).map((l) => l.id);
  if (!who || !target) return [];
  const between = view.lines.filter((l) => joins(l, who, target));
  const line = between.find((l) => l.type === how) ?? between[0];
  return line ? [line.id] : [];
}

// The nodes and lines a flow takes, worked out afresh from its picks so a line drawn or retyped later still lights: its
// first leg, then on from its through point to where the app lives by any line between the two.
export function flowPath(view: SummaryView, flow: Flow): FlowPath {
  const { who, through, where } = flow;
  const lines = legOf(view, flow);
  const onward = through && where && view.lines.find((l) => joins(l, through, where));
  if (onward) lines.push(onward.id);
  const shown = new Set(view.nodes.map((n) => n.id));
  return { name: flow.name, nodes: [who, through, where].filter((id): id is string => !!id && shown.has(id)), lines };
}

// "Branches to Salesforce": who, then the app or where it lives once picked.
const defaultName = (flow: Pick<Flow, "who" | "where" | "app">, label: (id: string) => string | undefined) => {
  const who = flow.who && label(flow.who);
  const to = flow.app ?? (flow.where && label(flow.where));
  // Cut by code point, so an emoji at the cut never leaves half a surrogate pair, which Postgres refuses.
  return Array.from(who ? (to ? `${who} to ${to}` : who) : "Flow").slice(0, 200).join("");
};

// A node already on the board, or a catalog item to add one of.
export type Target = { id: string } | { itemId: string };
export type Step = { who: Target } | { how: string } | { through: Target | null } | { where: Target; app?: string };

// One step of a flow as one change: the node it names, added if the diagram lacks it or confirmed if a ghost; the step, clearing
// those after who, how and through, which hang on them, unless it repeats the current pick; the name, while it's still the one
// the steps gave it; an app among its home's apps unless one there has its name in any case, taking the spelling of one there
// or one its home offers, as SaaS offers the common business apps and those people need; and the lines the path lacks, of the
// type picked to the through point, or else where the app lives, and of the first type that joins the through point to where,
// entered on whichever end may hold it. Null when nothing changes.
export function stepOp(
  template: Template,
  data: BoardData,
  catalog: CatalogLookup,
  flowId: string | null,
  step: Step,
): { op: Op | null; id: string } {
  const slot = template.flows!;
  const chain = opChain(data);
  const { apply } = chain;
  const node = (id: string | null) => (id ? nodesAt(template, chain.data, catalog).find((n) => n.id === id) : undefined);
  const label = (id: string) => {
    const n = node(id);
    return n && nodeName(n, catalog);
  };
  const ensure = (target: Target) => {
    if ("id" in target) {
      const ghost = chain.data.entries.find((e) => e.id === target.id && e.status === "ghost");
      if (ghost) apply(updateOp([ghost], { status: "live" }));
      return target.id;
    }
    const category = catalog(target.itemId)?.category ?? "";
    const ensured = ensureOp(chain.data, template.slots.find((s) => s.categories.includes(category))!.id, target.itemId);
    ensured.ops.forEach(apply);
    return ensured.id;
  };
  const named = (n: Entry) => list<Named>(n.attrs.apps).flatMap((a) => (a.name ? [a.name] : []));
  const spelled = (homeId: string, app: string) => {
    const home = node(homeId)!;
    const field = template.slots.find((s) => s.id === home.slot)?.attributes.find((a) => a.key === "apps");
    const known = [
      ...named(home),
      ...(field?.type === "records" ? field.presets.flatMap((id) => catalog(id)?.name ?? []) : []),
      ...(home.kind === "saas" ? nodesAt(template, chain.data, catalog).filter((n) => n.kind === "people").flatMap(named) : []),
    ];
    return known.find((name) => name.toLowerCase() === app.toLowerCase()) ?? app;
  };
  const place = ({ where, app }: { where: Target; app?: string }) => {
    const home = ensure(where);
    return { where: home, app: app ? spelled(home, app) : null };
  };
  const id = flowId ?? crypto.randomUUID();
  const entry = flowId ? entriesIn(data, slot).find((e) => e.id === flowId) : undefined;
  const before = entry && flowOf(entry);
  const pick = (key: "who" | "how" | "through", value: string | null): Partial<Flow> => {
    if (before && before[key] === value) return {};
    const later = KEYS.slice(KEYS.indexOf(key) + 1);
    return { ...Object.fromEntries(later.map((k) => [k, null])), [key]: value };
  };
  const set: Partial<Flow> =
    "who" in step
      ? pick("who", ensure(step.who))
      : "how" in step
        ? pick("how", step.how)
        : "through" in step
          ? pick("through", step.through && ensure(step.through))
          : place(step);
  const flow = { ...(before ?? { name: "", ...picks({}) }), ...set, id };
  if (!entry) {
    const attrs = Object.fromEntries(Object.entries(set).filter(([, v]) => v));
    apply(addOp(chain.data, { id, slot, text: defaultName(flow, label), attrs }));
  } else {
    for (const key of KEYS) if (key in set && !sameValue(entry.attrs[key], set[key])) apply(setAttrOp(chain.data, id, key, set[key]));
    const name = defaultName(flow, label);
    if (entry.text === defaultName(before!, label) && name !== entry.text) apply(updateOp([entry], { text: name }));
  }

  const home = flow.app && "where" in step ? node(flow.where) : undefined;
  if (home) {
    const apps = list<Named>(home.attrs.apps);
    if (!apps.some((a) => a.name?.toLowerCase() === flow.app!.toLowerCase()))
      apply(setAttrOp(chain.data, home.id, "apps", [...apps, { id: crypto.randomUUID(), name: flow.app }]));
  }

  const drawn = () =>
    nodesAt(template, chain.data, catalog).flatMap((n) =>
      list<Connection>(n.attrs.connections).map((c) => ({ from: n.id, to: c.to ?? null, type: c.type ?? null })),
    );
  const connect = (from: string, to: string | null, type: string) => {
    const connections = list<Connection>(node(from)!.attrs.connections);
    apply(setAttrOp(chain.data, from, "connections", [...connections, { id: crypto.randomUUID(), type, ...(to && { to }) }]));
  };
  const who = node(flow.who);
  const target = node(flow.through ?? flow.where);
  if (who && flow.how === DIRECT) {
    if (who.kind === "site" && !drawn().some((l) => l.from === who.id && l.type === DIRECT)) connect(who.id, null, DIRECT);
  } else if (who && target && flow.how && connectionTypes(who, target).includes(flow.how)) {
    if (!drawn().some((l) => l.type === flow.how && joins(l, who.id, target.id))) connect(who.id, target.id, flow.how);
  }
  const [through, where] = [node(flow.through), node(flow.where)];
  if (through && where && through.id !== where.id && !drawn().some((l) => joins(l, through.id, where.id))) {
    const [out] = connectionTypes(through, where);
    const [back] = connectionTypes(where, through);
    if (out) connect(through.id, where.id, out);
    else if (back) connect(where.id, through.id, back);
  }
  return { op: chain.op(), id };
}
