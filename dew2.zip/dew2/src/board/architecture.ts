import type { Zone } from "./attributes";
import { type BoardData, type Op, setAttrOp } from "./model";

export type Kind = "site" | "datacenter" | "security" | "sdwan" | "cloud" | "saas" | "internet" | "partner" | "people";

// Each node category's kind, and for sites the zones it may sit in, in order of preference, and what one of the
// group's count is where it isn't a site.
const CATEGORIES: Record<string, { kind: Kind; zones?: Zone[]; unit?: string }> = {
  "site-hq": { kind: "site", zones: ["left"] },
  "site-office": { kind: "site", zones: ["left", "bottom"] },
  "site-branch": { kind: "site" },
  "site-retail": { kind: "site", unit: "store" },
  "site-clinic": { kind: "site" },
  "site-factory": { kind: "site" },
  "site-warehouse": { kind: "site" },
  "site-home-office": { kind: "site" },
  "data-center": { kind: "datacenter" },
  sase: { kind: "security" },
  swg: { kind: "security" },
  ztna: { kind: "security" },
  "browser-connector": { kind: "security" },
  "sd-wan": { kind: "sdwan" },
  "cloud-provider": { kind: "cloud" },
  saas: { kind: "saas" },
  internet: { kind: "internet" },
  partner: { kind: "partner" },
  people: { kind: "people" },
};

export const kindOf = (category: string) => CATEGORIES[category]?.kind ?? "site";
export const siteUnit = (category: string | undefined) => (category ? CATEGORIES[category]?.unit : undefined);
// A site group's count field is named for what it counts, such as Stores, where that isn't sites.
export const countName = (category: string | undefined) => {
  const unit = siteUnit(category);
  return unit && `${unit[0].toUpperCase()}${unit.slice(1)}s`;
};
const siteZones = (category: string): Zone[] => CATEGORIES[category]?.zones ?? ["bottom"];

type HubNode = { id: string; kind: Kind; category?: string; hub?: boolean | null };
export type Hub = { kind: "datacenters" } | { kind: "security"; id: string } | null;

// The hub defaults to the data centers, else a security service, preferring a SASE; the SE can say otherwise.
export function hubOf(nodes: HubNode[]): Hub {
  const security = nodes.filter((n) => n.kind === "security");
  const chosen = security.find((n) => n.hub === true);
  if (chosen) return { kind: "security", id: chosen.id };
  if (nodes.some((n) => n.kind === "datacenter")) return { kind: "datacenters" };
  // The browser's connector reaches only private apps, so it is the hub only when the SE makes it so. A ZTNA service
  // reaches only private apps too, so a service that also reaches the internet comes before it.
  const usable = security.filter((n) => n.hub !== false && n.category !== "browser-connector");
  const pick = usable.find((n) => n.category === "sase") ?? usable.find((n) => n.category !== "ztna") ?? usable[0];
  return pick ? { kind: "security", id: pick.id } : null;
}

// Making a security service the hub, or not, records only what differs from the default; only one service is the hub.
// Standing one down keeps the others stood down, so the SE can stand them all down.
export function hubOp(data: BoardData, nodes: HubNode[], id: string, hub: boolean): Op {
  const byDefault = hubOf(nodes.map((n) => (hub || n.id === id ? { ...n, hub: null } : n)));
  const value = (byDefault?.kind === "security" && byDefault.id === id) === hub ? null : hub;
  const ops = [
    setAttrOp(data, id, "hub", value),
    ...nodes
      .filter((n) => hub && n.kind === "security" && n.id !== id && (n.hub ?? null) !== null)
      .map((n) => setAttrOp(data, n.id, "hub", null)),
  ];
  return ops.length === 1 ? ops[0] : { type: "batch", ops };
}

// Prisma SASE is Prisma Access and Prisma SD-WAN, drawn as one node while the SE groups them.
export const PRISMA_SASE = { id: "p-prisma-sase", access: "p-prisma-access", sdwan: "p-prisma-sd-wan" } as const;

export type PlaceNode = {
  id: string;
  kind: Kind;
  category: string;
  // Total users for sites, people for people, and lines for the rest; it orders and folds nodes.
  weight: number;
  zone?: Zone | null;
  order?: number | null;
  group?: { lead: string } | null;
};

// The data centers outside the hub show as one node.
export const DATACENTERS = "datacenters";

const CAPACITY = {
  full: { top: 5, left: 3, right: 3, bottom: 4 },
  compact: { top: 5, left: 5, right: 4, bottom: 6 },
} satisfies Record<string, Record<Zone, number>>;

export type Placement = {
  hub: string[];
  zones: Record<Zone, string[]>;
  compact: boolean;
  // The smallest nodes of a zone that didn't fit, shown as one "+N more" node at its end.
  folded: Partial<Record<Zone, string[]>>;
};

// A security service or SD-WAN platform that isn't the hub sits mid-row, over the hub, so its many lines split
// either side of it rather than all crossing the street above the hub from one end.
const TOP_ORDER: Kind[] = ["internet", "saas", "security", "sdwan", "cloud", "partner"];

export function place(nodes: PlaceNode[], hub: Hub): Placement {
  const inHub = (n: PlaceNode) =>
    hub?.kind === "datacenters"
      ? n.kind === "datacenter"
      : hub?.kind === "security" && (n.id === hub.id || n.group?.lead === hub.id);
  // A grouped node goes wherever its lead goes.
  const ids = new Set(nodes.map((n) => n.id));
  const member = (n: PlaceNode) => !!n.group && ids.has(n.group.lead);
  const outside = nodes.filter((n) => !inHub(n) && !member(n));
  const dcs = outside.filter((n) => n.kind === "datacenter");
  const orders = dcs.flatMap((d) => (d.order === null || d.order === undefined ? [] : [d.order]));
  const group: PlaceNode | null = dcs.length
    ? {
        id: DATACENTERS,
        kind: "datacenter",
        category: "data-center",
        weight: Infinity,
        zone: dcs.find((d) => d.zone)?.zone ?? null,
        order: orders.length ? Math.min(...orders) : null,
      }
    : null;
  const spokes = [...outside.filter((n) => n.kind !== "datacenter"), ...(group ? [group] : [])];
  const byWeight = (a: PlaceNode, b: PlaceNode) => b.weight - a.weight;

  const assign = (capacity: Record<Zone, number>) => {
    const zones: Record<Zone, PlaceNode[]> = { top: [], left: [], right: [], bottom: [] };
    for (const n of spokes.filter((n) => n.zone)) zones[n.zone!].push(n);
    for (const n of spokes.filter((n) => !n.zone)) {
      if (n.kind === "people") zones.right.push(n);
      else if (n.kind === "datacenter") zones.bottom.push(n);
      else if (n.kind !== "site") zones.top.push(n);
    }
    // Site groups fill the left column first, largest by total users, then the bottom row.
    for (const n of spokes.filter((n) => !n.zone && n.kind === "site").sort(byWeight)) {
      const zone = siteZones(n.category).find((z) => zones[z].length < capacity[z]) ?? "bottom";
      zones[zone].push(n);
    }
    return zones;
  };
  // The top row folds but never shrinks the board, since it holds as many either way.
  const fits = (zones: Record<Zone, PlaceNode[]>, capacity: Record<Zone, number>) =>
    (["left", "right", "bottom"] as Zone[]).every((z) => zones[z].length <= capacity[z]);

  let zones = assign(CAPACITY.full);
  const compact = !fits(zones, CAPACITY.full);
  if (compact) zones = assign(CAPACITY.compact);

  const placement: Placement = {
    hub: [...nodes.filter((n) => inHub(n) && !member(n)), ...nodes.filter((n) => inHub(n) && member(n))].map((n) => n.id),
    zones: { top: [], left: [], right: [], bottom: [] },
    compact,
    folded: {},
  };
  for (const zone of Object.keys(zones) as Zone[]) {
    const capacity = CAPACITY[compact ? "compact" : "full"][zone];
    let members = zones[zone];
    if (members.length > capacity) {
      // The heaviest stay; among equals, the zone's own order decides.
      const kept = arrange(zone, members).sort(byWeight).slice(0, capacity - 1);
      placement.folded[zone] = members.filter((n) => !kept.includes(n)).map((n) => n.id);
      members = members.filter((n) => kept.includes(n));
    }
    placement.zones[zone] = arrange(zone, members).map((n) => n.id);
  }
  return placement;
}

// Nodes the SE ordered come first in that order; the rest follow in the zone's own order.
function arrange(zone: Zone, members: PlaceNode[]) {
  const arranged = [...members]
    .sort((a, b) => (zone === "top" ? TOP_ORDER.indexOf(a.kind) - TOP_ORDER.indexOf(b.kind) : b.weight - a.weight))
    .sort((a, b) => (a.order ?? Infinity) - (b.order ?? Infinity));
  // The data centers sit in the middle of the bottom row, under the hub, unless the SE ordered them. Ordering
  // the row while they're in the hub orders only the sites.
  if (zone === "bottom") {
    const group = arranged.findIndex((n) => n.id === DATACENTERS && n.order === null);
    if (group >= 0) arranged.splice(Math.floor((arranged.length - 1) / 2), 0, ...arranged.splice(group, 1));
  }
  return arranged;
}

export type Circuit = { id: string; type?: string | null; speed?: string | null; role?: string | null };
export type Connection = {
  id: string;
  type?: string | null;
  to?: string | null;
  product?: string | null;
  count?: number | null;
  speed?: string | null;
};

const CELLULAR = ["circuit-lte", "circuit-5g"];
const RIDES_MPLS = "conn-mpls";
// Connections that run over the site's own circuits.
const OVER_CIRCUITS = ["conn-mpls", "conn-sd-wan", "conn-remote-network", "conn-local-internet", "conn-site-vpn"];
const SPEED_ONLY = ["conn-local-internet", "conn-egress"];

export type ConnectionField = "product" | "count" | "speed";
type End = { id?: string; kind: Kind; category: string; itemId: string | null };
const DC_CLOUD: [string[], string[]][] = [
  [["datacenter"], ["cloud"]],
  [["cloud"], ["datacenter"]],
];
// Where a ZTNA connector can sit beside private apps, and what it ends on: Prisma Access or a Prisma Browser Connector.
const APPS_AT = ["datacenter", "cloud", "site", "partner"];
const ZTNA_ENDS = ["sase", "ztna", "browser-connector"];
// Sites small enough to have no firewall of their own, whose devices run an agent instead.
const AGENT_SITES = ["site-home-office", "site-office", "site-branch", "site-retail", "site-clinic"];
// The line table: the nodes each connection type joins, from the node it's entered on to its target (none for a
// breakout), the fields it takes, the products it offers, and its ramp: whether it carries traffic into a security
// service (on) or out of one to the internet or the apps beside a node (off). An end names a kind or a category. A link
// that counts whichever end it was entered on lists both directions. A private cloud link joins only its provider's
// cloud; a cloud named in the customer's words takes any.
const LINKS: Record<
  string,
  { joins: [string[], string[]][]; fields: ConnectionField[]; products?: string[]; cloud?: string; ramp?: "on" | "off" }
> = {
  "conn-mpls": { joins: [[["site"], ["datacenter", "cloud", "site"]]], fields: ["speed"] },
  "conn-sd-wan": {
    joins: [
      [["site"], ["datacenter", "sase", "swg", "sdwan", "cloud", "site"]],
      [["datacenter", "cloud"], ["sdwan"]],
    ],
    fields: ["speed"],
    ramp: "on",
  },
  "conn-local-internet": { joins: [[["site"], []]], fields: ["speed"] },
  "conn-direct-connect": { joins: DC_CLOUD, fields: ["speed"], cloud: "cloud-aws" },
  "conn-expressroute": { joins: DC_CLOUD, fields: ["speed"], cloud: "cloud-azure" },
  "conn-cloud-interconnect": { joins: DC_CLOUD, fields: ["speed"], cloud: "cloud-gcp" },
  "conn-fastconnect": { joins: DC_CLOUD, fields: ["speed"], cloud: "cloud-oci" },
  "conn-dci": { joins: [[["datacenter"], ["datacenter"]]], fields: ["speed"] },
  "conn-site-vpn": {
    joins: [
      [["site", "datacenter", "cloud", "partner"], ["datacenter", "cloud"]],
      [["site"], ["site"]],
    ],
    fields: ["speed"],
  },
  "conn-egress": { joins: [[["datacenter", "sase", "swg", "cloud"], ["internet", "saas"]]], fields: ["speed"], ramp: "off" },
  "conn-remote-network": { joins: [[["site", "sdwan", "datacenter", "cloud"], ["sase", "swg"]]], fields: ["speed"], ramp: "on" },
  "conn-service-connection": {
    joins: [
      [["datacenter", "site-hq", "cloud"], ["sase"]],
      [["sase"], ["datacenter", "cloud"]],
    ],
    fields: ["count"],
    ramp: "off",
  },
  "conn-ztna-connector": {
    joins: [
      [APPS_AT, ZTNA_ENDS],
      [ZTNA_ENDS, APPS_AT],
    ],
    fields: ["count"],
    ramp: "off",
  },
  "conn-colo-connect": { joins: [[["datacenter"], ["sase"]]], fields: ["speed"], ramp: "off" },
  "conn-agent": {
    joins: [[["people", "partner", ...AGENT_SITES], ["sase", "swg", "ztna", "datacenter", "cloud"]]],
    fields: ["product"],
    products: ["p-globalprotect", "p-prisma-access-agent"],
    ramp: "on",
  },
  "conn-remote-access": {
    joins: [[["people", "partner"], ["datacenter", "cloud", "sase", "swg", "ztna"]]],
    fields: ["product"],
    products: ["p-cisco-secure-client", "p-citrix-vdi", "p-forticlient-vpn", "p-ivanti-connect-secure", "p-zscaler-client-connector"],
    ramp: "on",
  },
  "conn-explicit-proxy": {
    joins: [
      [["people", "partner", "site", "datacenter"], ["sase", "swg"]],
      [["site"], ["datacenter"]],
    ],
    fields: [],
    ramp: "on",
  },
  "conn-prisma-browser": { joins: [[["people", "partner"], ["security", "saas", "internet"]]], fields: [], ramp: "on" },
};
export const CONNECTION_TYPES = Object.keys(LINKS);
const matches = (ends: string[], n: End) => ends.includes(n.kind) || ends.includes(n.category);

// The types that join a connection's node to its target, or that need none, in the order LINKS lists them;
// a connection type the catalog adds is offered only once LINKS says what it joins. Only a site group joins itself,
// linking its own sites.
export const connectionTypes = (from: End, to: End | null) =>
  Object.entries(LINKS)
    .filter(
      ([, l]) =>
        (from.kind === "site" || !from.id || from.id !== to?.id) &&
        l.joins.some(([a, b]) => matches(a, from) && (to ? matches(b, to) : !b.length)) &&
        (!l.cloud || [from, to].every((n) => !n || n.kind !== "cloud" || !n.itemId || n.itemId === l.cloud)),
    )
    .map(([type]) => type);

export const connectionFields = (type: string | null | undefined): ConnectionField[] =>
  type && LINKS[type] ? LINKS[type].fields : ["product", "count", "speed"];

export const connectionProducts = (type: string | null | undefined) => (type && LINKS[type]?.products) || [];

export const rampOf = (type: string | null | undefined) => (type && LINKS[type]?.ramp) || null;

// The circuits a connection rides: MPLS rides the MPLS circuits; the others
// ride the rest, or all of them when the site has no MPLS connection.
export function ridden(connection: Connection, site: { circuits: Circuit[]; connections: Connection[] }) {
  if (!connection.type || !OVER_CIRCUITS.includes(connection.type)) return [];
  const mpls = connection.type === RIDES_MPLS;
  const claimed = site.connections.some((c) => c.type === RIDES_MPLS);
  return site.circuits.filter(
    (c) => (c.type || c.speed) && (mpls ? c.type === "circuit-mpls" : !claimed || c.type !== "circuit-mpls"),
  );
}

// A line's label: the product, or the connection name with its count, plus the
// speeds of the circuits it rides on.
export function connectionLabel(
  connection: Connection,
  site: { circuits: Circuit[]; connections: Connection[] },
  name: (id: string) => string,
): string {
  const times = (connection.count ?? 1) > 1 ? ` ×${connection.count}` : "";
  if (connection.product) return `${name(connection.product)}${times}`;
  const head = SPEED_ONLY.includes(connection.type ?? "") ? "" : `${connection.type ? name(connection.type) : ""}${times}`;
  if (connection.speed) return [head, connection.speed].filter(Boolean).join(" ");
  const parts = ridden(connection, site).map((c) => (c.type && (CELLULAR.includes(c.type) || !c.speed) ? name(c.type) : c.speed!));
  const counted = [...new Set(parts)].map((p) => {
    const n = parts.filter((x) => x === p).length;
    return n > 1 ? `${n}×${p}` : p;
  });
  return [head, counted.join(" + ")].filter(Boolean).join(" ");
}

const UNITS: Record<string, number> = { k: 0.001, m: 1, g: 1000, t: 1_000_000 };

// A speed as people type it, in megabits per second: "300M", "1.5 Gbps", "10 gig", "2x10G", or "500/50"
// for down and up, which counts the first. A bare number is megabits; anything else, such as "LTE", is null.
// A comma only groups thousands, so a decimal comma such as "1,5G" is null rather than ten times too fast.
export function mbps(speed: string | null | undefined) {
  const m = speed?.trim().match(/^(?:(\d+)\s*[x×]\s*)?((?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)\s*([kmgt])?(?:ig|bit|bps|b)?(?:\/s)?(?:\s*\/.*)?$/i);
  return m ? Number(m[1] ?? 1) * Number(m[2].replace(/,/g, "")) * UNITS[(m[3] ?? "m").toLowerCase()] : null;
}

// A link's bandwidth: its own speed, or else the speeds of the primary circuits it rides.
export const linkMbps = (connection: Connection, site: { circuits: Circuit[]; connections: Connection[] }) =>
  mbps(connection.speed) ??
  ridden(connection, site)
    .filter((c) => c.role !== "role-backup")
    .reduce((total, c) => total + (mbps(c.speed) ?? 0), 0);
