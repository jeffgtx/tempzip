import type { BoardTemplate } from "@/content/schema";
import {
  type Circuit,
  type Connection,
  type Hub,
  type Kind,
  PRISMA_SASE,
  connectionLabel,
  hubOf,
  kindOf,
} from "./architecture";
import type { Zone } from "./attributes";
import { type BoardData, entriesIn } from "./model";

export type BadgeIcon = "router" | "firewall" | "lock" | "device";
export type Badge = { id: string; label: string; icon: BadgeIcon };
export type Service = { id: string; itemId: string; label: string };
export type SummaryNode = {
  id: string;
  kind: Kind;
  category: string;
  itemId: string | null;
  name: string;
  count: number | null;
  detail: string[];
  badges: Badge[];
  services: Service[];
  weight: number;
  zone: Zone | null;
  order: number | null;
  hub: boolean | null;
  // The node this one draws with, as Prisma SD-WAN does with the Prisma Access it's grouped with.
  group: { lead: string; name: string } | null;
};
export type SummaryLine = { id: string; from: string; to: string | null; type: string | null; label: string };
// The flow the cockpit has picked: its name and the nodes and lines it takes.
export type FlowPath = { name: string; nodes: string[]; lines: string[] };
export type SummaryView = {
  layout: "hub-and-spoke";
  // The diagram's name.
  name: string;
  hub: Hub;
  nodes: SummaryNode[];
  lines: SummaryLine[];
  flow: FlowPath | null;
};

export type CatalogLookup = (id: string) => { name: string; category: string } | undefined;

const ICONS: Record<string, BadgeIcon> = {
  "sd-wan": "router",
  "network-firewall": "firewall",
  "cloud-network-security": "firewall",
  "remote-access": "lock",
};

export const badgeIcon = (category: string | undefined): BadgeIcon => (category && ICONS[category]) || "device";

export type EdgeDevice = { id: string; product?: string | null; model?: string | null; count?: number | null };
export type Named = { id: string; name?: string | null };
export const list = <T>(value: unknown) => (Array.isArray(value) ? (value as T[]) : []);
export const num = (value: unknown) => (typeof value === "number" ? value : null);
// A cloud's networks, each record standing for its count of alike ones.
export const networkCount = (networks: { count?: unknown }[]) => networks.reduce((t, n) => t + (num(n.count) ?? 1), 0);

// The catalog items a board's entries are and their fields pick, so their names and categories can be looked up.
export function pickedIds(template: BoardTemplate, data: BoardData) {
  const ids = new Set(data.entries.flatMap((e) => (e.itemId ? [e.itemId] : [])));
  const slots = new Map(data.entries.map((e) => [e.id, template.slots.find((s) => s.id === e.slot)]));
  const visit = (entryId: string, attrs: Record<string, unknown>) => {
    for (const a of slots.get(entryId)?.attributes ?? []) {
      const value = attrs[a.key];
      if (a.type === "pick" && typeof value === "string") ids.add(value);
      if (a.type === "records" && Array.isArray(value))
        for (const f of a.fields)
          for (const r of value as Record<string, unknown>[]) if (f.type === "pick" && typeof r[f.key] === "string") ids.add(r[f.key] as string);
    }
  };
  for (const e of data.entries) visit(e.id, e.attrs);
  // A Prisma SASE group takes its name.
  if (template.layout === "hub-and-spoke") ids.add(PRISMA_SASE.id);
  return [...ids];
}

// The board's nodes. Saved flows are no nodes.
export const nodesAt = (template: BoardTemplate, data: BoardData, catalog: CatalogLookup) =>
  template.slots
    .filter((slot) => template.layout !== "hub-and-spoke" || slot.id !== template.flows)
    .flatMap((slot) =>
      entriesIn(data, slot.id).map((e) => ({
          ...e,
          // Free text has no category: it takes the slot's kind, and its single category if it has one.
          category: (e.itemId && catalog(e.itemId)?.category) || (slot.categories.length === 1 ? slot.categories[0] : ""),
          kind: kindOf((e.itemId && catalog(e.itemId)?.category) || slot.categories[0]),
        })),
    );
export type Node = ReturnType<typeof nodesAt>[number];

export const nodeName = (e: Node, catalog: CatalogLookup) =>
  (typeof e.attrs.name === "string" && e.attrs.name) || (e.itemId ? (catalog(e.itemId)?.name ?? e.itemId) : e.text!);

// The summary as one diagram, named name, shows it.
export function summaryView(template: BoardTemplate, data: BoardData, diagram: string, catalog: CatalogLookup): SummaryView {
  const name = (id: string) => catalog(id)?.name ?? id;
  const now = nodesAt(template, data, catalog);

  const all = now.flatMap((e) => {
    const site = { circuits: list<Circuit>(e.attrs.circuits), connections: list<Connection>(e.attrs.connections) };
    return site.connections.map(
      (c): SummaryLine => ({ id: c.id, from: e.id, to: c.to ?? null, type: c.type ?? null, label: connectionLabel(c, site, name) }),
    );
  });
  // A line whose far end is gone isn't drawn.
  const ids = new Set(now.map((e) => e.id));
  const lines = all.filter((l) => !l.to || ids.has(l.to));

  const leadOf = new Map(
    now.flatMap((e) => {
      const lead = now.find((l) => l.id === e.attrs.group && l.kind === "security");
      return lead ? [[e.id, lead] as const] : [];
    }),
  );

  const nodes = now.map((e): SummaryNode => {
    const { kind } = e;
    const lead = leadOf.get(e.id);
    const a = e.attrs;
    const count = num(a.count);
    const users = num(a.users);
    const edge = list<EdgeDevice>(a.edge);
    const services = list<{ id: string; function?: string | null }>(a.services).filter((s) => s.function);
    const names = (key: string) => list<Named>(a[key]).flatMap((r) => (r.name ? [r.name] : []));
    const networks = list<{ id: string; region?: string | null; count?: number | null }>(a.networks);
    const regions = new Set(networks.flatMap((n) => (n.region ? [n.region] : []))).size;
    const detail =
      kind === "site" && users !== null
        ? [`${users.toLocaleString("en-US")} ${users === 1 ? "user" : "users"}${(count ?? 1) > 1 ? " each" : ""}`]
        : kind === "datacenter"
          ? [a.location as string, names("apps").join(" · ")].filter(Boolean)
          : kind === "cloud"
            ? [regions ? `${regions} ${regions === 1 ? "region" : "regions"}` : "", names("apps").join(" · ")].filter(Boolean)
            : kind === "saas"
              ? [names("apps").join(" · ")].filter(Boolean)
              : [];
    return {
      id: e.id,
      kind,
      category: e.category,
      itemId: e.itemId,
      name: nodeName(e, catalog),
      // A single site needs no "×1".
      count:
        kind === "cloud"
          ? networkCount(networks) || null
          : kind === "saas"
            ? names("apps").length || null
            : kind === "site" && count === 1
              ? null
              : count,
      detail,
      badges: edge.map((d) => ({
        id: d.id,
        label: `${d.model || (d.product ? name(d.product) : "")}${(d.count ?? 1) > 1 ? ` ×${d.count}` : ""}`,
        icon: badgeIcon(d.product ? catalog(d.product)?.category : undefined),
      })),
      services: services.map((s) => ({ id: s.id, itemId: s.function!, label: name(s.function!) })),
      weight:
        kind === "site"
          ? (count ?? 1) * (users ?? 0)
          : kind === "people"
            ? (count ?? 0)
            : lines.filter((l) => [l.from, l.to].some((id) => !!id && (id === e.id || leadOf.get(id)?.id === e.id))).length,
      zone: (a.zone as Zone | undefined) ?? null,
      order: num(a.order),
      hub: (a.hub as boolean | undefined) ?? null,
      group: lead ? { lead: lead.id, name: catalog(PRISMA_SASE.id)?.name ?? nodeName(lead, catalog) } : null,
    };
  });

  return { layout: "hub-and-spoke", name: diagram, hub: hubOf(nodes), nodes, lines, flow: null };
}

// A lead and the nodes grouped with it, as the one node they draw as.
export function framed(lead: SummaryNode, members: SummaryNode[]): SummaryNode {
  const all = [lead, ...members];
  return {
    ...lead,
    name: members[0].group!.name,
    detail: [all.map((n) => n.name).join(" · ")],
    badges: all.flatMap((n) => n.badges),
    services: all.flatMap((n) => n.services),
  };
}
