import type { BoardTemplate } from "@/content/schema";
import { type BoardData, type Entry, entriesIn } from "./model";

type SlotDef = BoardTemplate["slots"][number];
// Planned: held in a slot for what the customer plans, which suggests nothing but still implies concerns.
export type Placed = { boardId: string; templateId: string; slot: string; itemId: string; category: string; planned: boolean };

// The catalog items live in each slot of a board.
export function placed(
  boardId: string,
  template: BoardTemplate,
  data: BoardData,
  categoryOf: (itemId: string) => string | undefined,
): Placed[] {
  return template.slots.flatMap((slot) =>
    entriesIn(data, slot.id).flatMap((e) => {
      const category = e.itemId && categoryOf(e.itemId);
      return category && e.status === "live"
        ? [{ boardId, templateId: template.id, slot: slot.id, itemId: e.itemId!, category, planned: slot.planned }]
        : [];
    }),
  );
}

// A catalog item entered on one board is suggested to every slot on the customer's boards of other templates that names
// its category, so neither its own board nor another diagram of the summary is. A slot that accepts everything names
// none. An item the slot already holds in any form, dismissed included, isn't suggested. A slot for plans suggests
// nothing and is suggested nothing.
export function suggestions(
  target: { templateId: string; slot: SlotDef },
  everywhere: Placed[],
  board: Pick<Entry, "itemId" | "slot">[],
): string[] {
  const { templateId, slot } = target;
  if (slot.planned) return [];
  const taken = new Set(board.filter((e) => e.slot === slot.id).map((e) => e.itemId));
  const items = everywhere
    .filter((p) => !p.planned && p.templateId !== templateId && slot.categories.includes(p.category) && !taken.has(p.itemId))
    .map((p) => p.itemId);
  return [...new Set(items)];
}
