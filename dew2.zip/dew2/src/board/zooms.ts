import type { BoardTemplate } from "@/content/schema";
import { type Circuit, type Connection, connectionLabel, linkMbps, place, rampOf, ridden, siteUnit } from "./architecture";
import { flowsAt } from "./flows";
import type { BoardData, Entry } from "./model";
import { type Destination, routesOf } from "./routes";
import {
  type BadgeIcon,
  type CatalogLookup,
  type EdgeDevice,
  type Named,
  type Node,
  badgeIcon,
  framed,
  list,
  nodeName,
  networkCount,
  nodesAt,
  num,
  summaryView,
} from "./summary";

// An AI app's zoom is drawn on its own; see appView.
type Shows = Exclude<Extract<BoardTemplate, { layout: "zoom" }>["shows"], "app">;
// How a data center's app group is held apart from the others: not at all, by layer 4 rules, or by a firewall.
type Guard = "open" | "filtered" | "inspected";
type Glyph =
  | "users"
  | "device"
  | "circuit"
  | "internet"
  | "apps"
  | "network"
  | "transport"
  | "access"
  | "region"
  | "unplaced"
  | "unnetworked"
  | "sites"
  | "bandwidth"
  | Guard
  | "tags"
  | "onramp"
  | "offramp";
export type ZoomIcon = { node: { category: string; itemId: string | null } } | { badge: BadgeIcon } | { glyph: Glyph };
export type ZoomCard = {
  id: string;
  // The entry the card stands for when its id isn't that entry's, as for a node standing on both sides of a zoom.
  entry?: string;
  name: string;
  detail: string[];
  count: string | null;
  icon: ZoomIcon;
  // Numbers beside icons, such as a region's people, sites and bandwidth.
  stats: { glyph: Glyph; value: string }[];
  // Empty, such as a placeholder, or a ghost the cockpit shows.
  quiet: boolean;
};
type ZoomLine = {
  from: string;
  to: string;
  label: string;
  type: string | null;
  backup: boolean;
};
// A zoom reads left to right in columns of cards. A box outlines the cards of its
// columns (span of them, one by default) that sit inside the node, such as a site's
// devices or a cloud's networks, and on a boundary the next column's cards sit on its
// edge. A line to or from the box's id meets the box itself.
export type ZoomView = {
  layout: "zoom";
  shows: Shows;
  title: string;
  subtitle: string[];
  // A cloud's inspected flows, beside the title.
  inspected: ZoomCard[];
  columns: ZoomCard[][];
  // Drawn inside the box, under its cards, such as a security service's services.
  tiles: ZoomCard[];
  box: { id: string; column: number; span?: number; boundary: boolean; icon: { category: string; itemId: string | null } } | null;
  lines: ZoomLine[];
  // A column's caption, such as a security service's on-ramps.
  heads: { column: number; glyph: "onramp" | "offramp"; name: string }[];
  // The entries its cards name in their detail without a card of their own, which the cockpit sets apart beneath it.
  names: string[];
};

type Edge = EdgeDevice & { ha?: string | null; at?: string | null; insertion?: string | null };
type Group = Named & { count?: number | null; control?: string | null };
type Lan = { id: string; kind?: string | null; count?: number | null };
type Network = Named & { region?: string | null; count?: number | null; kind?: string | null };
type Hosted = Named & { count?: number | null; network?: string | null };
type Flow = { id: string; flow?: string | null };
type Site = { circuits: Circuit[]; connections: Connection[] };

// A group's icon comes from the catalog category of its east-west control, as a badge's does from its device's.
const GUARDS: Record<string, Guard> = {
  "east-west-open": "open",
  "east-west-l4": "filtered",
  microsegmentation: "filtered",
  "network-firewall": "inspected",
  "cloud-network-security": "inspected",
};
const fmt = (n: number) => n.toLocaleString("en-US");
const plural = (n: number, one: string, many = `${one}s`) => `${fmt(n)} ${n === 1 ? one : many}`;
const listed = (parts: string[]) => (parts.length > 1 ? `${parts.slice(0, -1).join(", ")} and ${parts.at(-1)}` : parts.join(""));
// People read as a number, as on the summary; everything else as a count, but a single site as none.
const counted = (kind: string, n: number | null) =>
  n === null || (kind === "site" && n === 1) ? null : kind === "people" ? fmt(n) : `×${fmt(n)}`;
const card = (c: Partial<ZoomCard> & Pick<ZoomCard, "id" | "name" | "icon">): ZoomCard => ({
  detail: [],
  count: null,
  stats: [],
  quiet: false,
  ...c,
});
const line = (l: Partial<ZoomLine> & Pick<ZoomLine, "from" | "to">): ZoomLine => ({
  label: "",
  type: null,
  backup: false,
  ...l,
});
// Lines run through these cards in turn.
function through(chain: ZoomCard[]) {
  return {
    inner: chain[0]?.id,
    outer: chain.at(-1)?.id,
    links: chain.slice(1).map((c, i) => line({ from: chain[i].id, to: c.id })),
  };
}
const siteOf = (n: Node): Site => ({ circuits: list<Circuit>(n.attrs.circuits), connections: list<Connection>(n.attrs.connections) });
// Once each, since a card keys its detail lines by their text.
const appNames = (n: Node) => [...new Set(list<Named>(n.attrs.apps).flatMap((r) => (r.name ? [r.name] : [])))];

// Records the SE has added but not filled in yet aren't drawn.
const filled = {
  edge: (r: Edge) => !!(r.product || r.model),
  lan: (r: Lan) => !!r.kind,
  circuits: (r: Circuit) => !!(r.type || r.speed),
  connections: (r: Connection) => !!(r.type || r.product),
  named: (r: Named) => !!r.name,
};

// The same node can reach a column more than once; it shows once.
const unique = (cards: ZoomCard[]) => [...new Map(cards.map((c) => [c.id, c])).values()];

// The order a security service's on-ramps and off-ramps stand in, by kind.
const ON_RAMPS: Node["kind"][] = ["people", "site", "partner", "sdwan", "datacenter", "cloud", "security"];
const OFF_RAMPS: Node["kind"][] = ["internet", "saas", "datacenter", "cloud", "site", "partner", "security", "sdwan"];
// The links a site group reaches a security service by over its own circuits.
const SITE_LINKS = ["conn-remote-network", "conn-sd-wan"];

type Sizing = { users: number; browser: number; sites: number; mbps: number };
const NONE: Sizing = { users: 0, browser: 0, sites: 0, mbps: 0 };
const plus = (a: Sizing, b: Sizing): Sizing => ({
  users: a.users + b.users,
  browser: a.browser + b.browser,
  sites: a.sites + b.sites,
  mbps: a.mbps + b.mbps,
});
const regionOf = (n: Node) => (typeof n.attrs.region === "string" ? n.attrs.region : null);

// What a site group reaches a security service through: the service, and the Prisma SD-WAN grouped with it.
export const sizedThrough = (nodes: Node[], serviceId: string) => [
  serviceId,
  ...nodes.filter((n) => n.attrs.group === serviceId).map((n) => n.id),
];

// What a population or site group adds to a security service's sizing, or null when it doesn't
// reach the service, through any of `through`, in a way the sizing counts. A population counts once
// however many ways it connects; a site group with a speed it can read is its count times its fastest
// link's bandwidth.
export function reach(n: Node, through: string[]): Sizing | null {
  const links = list<Connection>(n.attrs.connections).filter((c) => !!c.to && through.includes(c.to));
  const count = num(n.attrs.count);
  if (n.kind === "people" && links.length)
    return { ...NONE, users: count ?? 0, browser: links.some((c) => c.type === "conn-prisma-browser") ? (count ?? 0) : 0 };
  if (n.kind !== "site") return null;
  const fastest = Math.max(0, ...links.filter((c) => SITE_LINKS.includes(c.type ?? "")).map((c) => linkMbps(c, siteOf(n))));
  return fastest ? { ...NONE, sites: count ?? 1, mbps: (count ?? 1) * fastest } : null;
}

function sizing(nodes: Node[], serviceId: string) {
  const regions = new Map<string | null, Sizing>();
  const through = sizedThrough(nodes, serviceId);
  for (const n of nodes) {
    const add = reach(n, through);
    if (add) regions.set(regionOf(n), plus(regions.get(regionOf(n)) ?? NONE, add));
  }
  return regions;
}

// Megabits per second as the lines read speeds, such as "850M" or "25.5G".
const speedOf = (mbps: number) => (mbps >= 1000 ? `${fmt(Math.round(mbps / 100) / 10)}G` : `${fmt(Math.round(mbps))}M`);

// A ghost's zoom shows in the cockpit only, quiet throughout.
export function quietAll(view: ZoomView): ZoomView {
  const settle = <T extends { quiet: boolean }>(x: T) => ({ ...x, quiet: true });
  return {
    ...view,
    inspected: view.inspected.map(settle),
    columns: view.columns.map((c) => c.map(settle)),
    tiles: view.tiles.map(settle),
  };
}

export function zoomView(
  template: BoardTemplate,
  data: BoardData,
  shows: Shows,
  entryId: string | null,
  // The diagram's name, which leads every zoom's subtitle.
  diagram: string,
  catalog: CatalogLookup,
  // The device classes a site can hold, in the order the zoom lists them.
  classes: { id: string; name: string }[],
): ZoomView | null {
  const name = (id: string) => catalog(id)?.name ?? id;
  const summary = summaryView(template, data, diagram, catalog);
  const base = { layout: "zoom" as const, shows, inspected: [], tiles: [], box: null, heads: [], names: [] };

  if (shows === "folded") {
    const folded = Object.values(place(summary.nodes, summary.hub).folded).flat();
    const cards = summary.nodes
      .filter((n) => folded.includes(n.id))
      .map((lead) => {
        const members = summary.nodes.filter((m) => m.group?.lead === lead.id);
        const n = members.length ? framed(lead, members) : lead;
        return card({
          id: n.id,
          name: n.name,
          icon: { node: { category: n.category, itemId: n.itemId } },
          count: counted(n.kind, n.count),
          detail: [...n.detail, n.badges.map((b) => b.label).join(" · ")].filter(Boolean),
        });
      });
    const rows = Math.ceil(cards.length / 3) || 1;
    return {
      ...base,
      title: `${folded.length} more`,
      subtitle: [diagram],
      columns: [0, 1, 2].map((i) => cards.slice(i * rows, (i + 1) * rows)).filter((c) => c.length),
      lines: [],
    };
  }

  const now = nodesAt(template, data, catalog);
  const flows = template.layout === "hub-and-spoke" ? flowsAt(template, data) : [];
  const byId = new Map(now.map((n) => [n.id, n]));
  const find = (id: unknown) => (typeof id === "string" ? byId.get(id) : undefined);
  const nodeCard = (n: Node, extra: Partial<ZoomCard> = {}) =>
    card({ id: n.id, name: nodeName(n, catalog), icon: { node: { category: n.category, itemId: n.itemId } }, ...extra });
  const countOf = (n: Node) => counted(n.kind, num(n.attrs.count));

  const found = entryId ? find(entryId) : undefined;
  if (!found) return null;
  const self: Node = found;
  const a = self.attrs;
  const recordsOf = <R extends { id: string }>(key: string, keep: (r: R) => boolean) => list<R>(a[key]).filter(keep);

  const deviceName = (r: Edge) => `${r.model || (r.product ? name(r.product) : "")}${(r.count ?? 1) > 1 ? ` ×${r.count}` : ""}`;
  const edges = recordsOf<Edge>("edge", filled.edge);
  const edgeCards = edges.map((r) =>
    card({
      id: r.id,
      name: deviceName(r),
      // HA and where it sits share a line, so a card with room for two keeps the product too.
      detail: [
        [r.ha, r.at, r.insertion].flatMap((v) => (v ? [name(v)] : [])).join(" · "),
        r.model && r.product ? name(r.product) : "",
      ].filter(Boolean),
      icon: { badge: badgeIcon(r.product ? catalog(r.product)?.category : undefined) },
    }),
  );
  const { inner, outer, links } = through(edgeCards);
  const circuits = recordsOf<Circuit>("circuits", filled.circuits);
  const circuitCards = circuits.map((r) =>
    card({
      id: r.id,
      name: r.type ? name(r.type) : "",
      count: r.speed ?? null,
      detail: r.role ? [name(r.role)] : [],
      icon: { glyph: "circuit" },
    }),
  );
  const site = siteOf(self);
  // A transport to a ghost goes with it, as in the overview; one with no far end, such as local internet, stays.
  const transports = recordsOf<Connection>("connections", (r) => filled.connections(r) && !(r.to && !find(r.to)));
  const outbound = transports.flatMap((r) => {
    const target = find(r.to);
    return target
      ? [{ r, target, line: line({ from: self.id, to: target.id, label: connectionLabel(r, site, name), type: r.type ?? null }) }]
      : [];
  });

  const view = (): ZoomView => {
    if (shows === "site") return siteView();
    if (shows === "datacenter") return datacenterView();
    if (shows === "people") return peopleView();
    if (shows === "security") return securityView();
    if (shows === "sdwan") return sdwanView();
    return cloudView();
  };
  const serviceTiles = () =>
    recordsOf<{ id: string; function?: string | null }>("services", (r) => !!r.function).map((r) =>
      card({ id: r.id, name: name(r.function!), icon: { node: { category: "security-function", itemId: r.function! } } }),
    );

  function siteView(): ZoomView {
    const count = num(a.count) ?? 1;
    const unit = siteUnit(self.category) ?? "site";
    const users = num(a.users);
    const lan = recordsOf<Lan>("lan", filled.lan);
    // Only the classes the site has, in the catalog's order; a class the content no longer lists comes last.
    // A class entered twice shows once, its counts summed.
    const order = new Map(classes.map((k, i) => [k.id, i]));
    const devices = [
      card({ id: "users", name: "Users", icon: { glyph: "users" }, count: users === null ? null : fmt(users), quiet: users === null }),
      ...[...new Set(lan.map((r) => r.kind!))]
        .sort((x, y) => (order.get(x) ?? classes.length) - (order.get(y) ?? classes.length))
        .map((kind) => {
          const counts = lan.filter((r) => r.kind === kind).flatMap((r) => num(r.count) ?? []);
          return card({
            id: kind,
            name: classes.find((k) => k.id === kind)?.name ?? name(kind),
            icon: { glyph: "device" },
            count: counts.length ? fmt(counts.reduce((t, n) => t + n, 0)) : null,
          });
        }),
    ];
    // A link another node entered to this one, such as another group's MPLS or Prisma Access's ZTNA connector, rides
    // this one's circuits too, and leads to that node.
    const linked = now
      .filter((n) => n.id !== self.id)
      .flatMap((n) => list<Connection>(n.attrs.connections).flatMap((c) => (c.to === self.id && filled.connections(c) ? [{ ...c, to: n.id }] : [])));
    const carried = [...transports, ...linked];
    const transportCards = carried.map((r) => {
      const target = find(r.to);
      return card({
        id: r.id,
        name: r.product ? name(r.product) : r.type ? name(r.type) : "",
        detail: target ? [nodeName(target, catalog)] : [],
        icon: { glyph: "transport" },
      });
    });
    // Each transport rides its circuits, and a tunnel such as a service connection those SD-WAN would.
    const shownCircuits = new Set(circuits.map((c) => c.id));
    const rides = (r: Connection, s: Site) => {
      const own = ridden(r, s);
      return own.length || r.type === "conn-mpls" ? own : ridden({ ...r, type: "conn-sd-wan" }, s);
    };
    const circuitLines = carried.flatMap((r) =>
      rides(r, site)
        .filter((circuit) => shownCircuits.has(circuit.id))
        .map((circuit) => line({ from: circuit.id, to: r.id, type: r.type ?? null, backup: circuit.role === "role-backup" })),
    );

    // A transport that rides no circuit leaves from the edge.
    const stranded = carried
      .filter((r) => !circuitLines.some((l) => l.to === r.id))
      .map((r) => line({ from: outer ?? "users", to: r.id, type: r.type ?? null }));

    const routes = routesOf(summary, now, flows, self);
    const placesTo = (to: Destination) => [...new Set(routes.flatMap((r) => (r.to === to ? r.places : [])))];
    const destination = (to: Destination, title: string, detail: (n: Node) => string[]) =>
      routes.some((r) => r.to === to)
        ? [card({ id: to, name: title, icon: { glyph: to }, detail: [...new Set(placesTo(to).flatMap(detail))] })]
        : [];
    // A route leaves the transport it takes, carrying the apps its flows name on it.
    const leaving = new Map<string, { from: string; to: Destination; apps: Set<string> }>();
    for (const r of routes) {
      if (!r.line || !transportCards.some((c) => c.id === r.line)) continue;
      const key = `${r.line}:${r.to}`;
      const at = leaving.get(key) ?? { from: r.line, to: r.to, apps: new Set<string>() };
      if (r.app) at.apps.add(r.app);
      leaving.set(key, at);
    }
    // The destinations stand in the order whose lines cross least, the internet first on a tie; the transports keep
    // theirs, since reordering them would move the crossing onto the circuits' lines.
    const rank = (id: string) => transportCards.findIndex((c) => c.id === id);
    const out = [...leaving.values()];
    const crossings = (first: Destination) =>
      out.filter((x) => x.to === first).reduce((t, x) => t + out.filter((y) => y.to !== first && rank(y.from) < rank(x.from)).length, 0);
    const destinations = [
      ...destination("internet", "Internet & SaaS", (n) => [nodeName(n, catalog)]),
      ...destination("apps", "Private apps", (n) => [nodeName(n, catalog), ...appNames(n)]),
    ];
    if (crossings("apps") < crossings("internet")) destinations.reverse();
    return {
      ...base,
      title: count > 1 ? `${nodeName(self, catalog)} ×${fmt(count)}` : nodeName(self, catalog),
      subtitle: [
        diagram,
        ...(count > 1 ? [`one typical ${unit}`, ...(users !== null ? [`${plural(users * count, "user")} across all ${fmt(count)}`] : [])] : []),
      ],
      columns: [
        devices,
        edgeCards,
        circuitCards,
        transportCards,
        destinations,
      ].filter((c) => c.length),
      box: { id: self.id, column: 0, boundary: edgeCards.length > 0, icon: { category: self.category, itemId: self.itemId } },
      lines: [
        ...(inner ? devices.filter((d) => !d.quiet).map((d) => line({ from: d.id, to: inner })) : []),
        ...links,
        ...circuitCards.map((c) => line({ from: outer ?? "users", to: c.id })),
        ...circuitLines,
        ...stranded,
        ...out.map((l) => line({ from: l.from, to: l.to, label: [...l.apps].join(" · ") })),
      ],
      names: [
        ...transports.flatMap((r) => (r.to ? [r.to] : [])),
        ...linked.map((r) => r.to),
        ...routes.flatMap((r) => r.places.map((p) => p.id)),
      ],
    };
  }

  // Everyone else's connections to this node.
  const dependents = now.flatMap((n) => list<Connection>(n.attrs.connections).filter((c) => c.to === self.id).map((c) => ({ n, c })));
  const inboundLine = (d: (typeof dependents)[number], from: string, to: string) =>
    line({ from, to, label: connectionLabel(d.c, siteOf(d.n), name), type: d.c.type ?? null });

  function datacenterView(): ZoomView {
    const sites = dependents.filter((d) => d.n.kind === "site");
    const others = dependents.filter((d) => d.n.kind !== "site");
    // A single site has no count, while a population without one adds nothing, as on a security service's sizing.
    const sum = (nodes: Node[], uncounted: number) => nodes.reduce((t, n) => t + (num(n.attrs.count) ?? uncounted), 0);
    const all = now.filter((n) => n.kind === "site" || n.kind === "people").map((n) => ({ n, routes: routesOf(summary, now, flows, n) }));
    const ending = (to: Destination, kind: Node["kind"]) =>
      all.filter((x) => x.n.kind === kind && x.routes.some((r) => r.to === to && r.places.some((p) => p.id === self.id))).map((x) => x.n);
    const [egressSites, people, appSites] = [ending("internet", "site"), ending("internet", "people"), ending("apps", "site")];
    const users = sum(people, 0);
    // With none of them counted, the populations are named rather than numbered.
    const egress = [
      ...(egressSites.length ? [plural(sum(egressSites, 1), "site")] : []),
      ...(users ? [plural(users, "remote user")] : new Set(people.map((n) => nodeName(n, catalog)))),
    ];
    const facts = [
      egress.length ? `internet egress for ${listed(egress)}` : "",
      appSites.length ? `private apps for ${plural(sum(appSites, 1), "site")}` : "",
    ];
    const groups = recordsOf<Group>("apps", filled.named);
    // A group a firewall holds apart meets that firewall among the edge devices.
    const held = groups.flatMap((r) => {
      const firewall = r.control ? edges.find((e) => e.product === r.control) : undefined;
      return firewall ? [line({ from: r.id, to: firewall.id })] : [];
    });
    const inside = [
      groups.map((r) =>
        card({
          id: r.id,
          name: r.name!,
          count: (r.count ?? 1) > 1 ? `×${fmt(r.count!)}` : null,
          icon: { glyph: (r.control && GUARDS[catalog(r.control)?.category ?? ""]) || "apps" },
        }),
      ),
      [
        ...edgeCards,
        ...(typeof a.tags === "string" ? [card({ id: "tags", name: name(a.tags), icon: { glyph: "tags" } })] : []),
        ...circuitCards,
      ],
    ].filter((c) => c.length);
    const left = unique(sites.map((d) => nodeCard(d.n, { count: countOf(d.n) })));
    return {
      ...base,
      title: nodeName(self, catalog),
      subtitle: [
        diagram,
        typeof a.location === "string" ? a.location : "",
        typeof a.fabric === "string" ? name(a.fabric) : "",
        ...facts,
      ].filter(Boolean),
      columns: [
        left,
        ...(inside.length ? inside : [[nodeCard(self)]]),
        unique([
          ...outbound.map((o) => nodeCard(o.target)),
          ...others.map((d) => nodeCard(d.n, { count: countOf(d.n) })),
        ]),
      ].filter((c) => c.length),
      box: {
        id: self.id,
        column: left.length ? 1 : 0,
        span: Math.max(1, inside.length),
        boundary: false,
        icon: { category: self.category, itemId: self.itemId },
      },
      // Sites, people and links meet the data center itself, its box.
      lines: [
        ...sites.map((d) => inboundLine(d, d.n.id, self.id)),
        ...held,
        ...outbound.map((o) => o.line),
        ...others.map((d) => inboundLine(d, self.id, d.n.id)),
      ],
    };
  }

  function peopleView(): ZoomView {
    const count = num(a.count);
    const access = outbound.map((o) =>
      card({
        id: `via-${o.r.id}`,
        name: o.line.label || (o.line.type ? name(o.line.type) : ""),
        icon: { glyph: "access" },
      }),
    );
    // The apps they need live in SaaS unless a data center or cloud hosts one by that name.
    const hosted = new Set(
      now.filter((n) => n.kind === "datacenter" || n.kind === "cloud").flatMap((n) => appNames(n).map((app) => app.toLowerCase())),
    );
    const needed = appNames(self);
    const held = {
      internet: needed.filter((app) => !hosted.has(app.toLowerCase())),
      apps: needed.filter((app) => hosted.has(app.toLowerCase())),
    };
    const targets = unique(outbound.map((o) => nodeCard(o.target)));
    const routes = routesOf(summary, now, flows, self);
    const onward = new Map<string, ZoomLine>();
    for (const r of routes) {
      const o = outbound.find((o) => o.r.id === r.line);
      if (o) onward.set(`${o.target.id}:${r.to}`, line({ from: o.target.id, to: r.to }));
    }
    const destination = (id: Destination, title: string) =>
      routes.some((r) => r.to === id) || held[id].length ? [card({ id, name: title, icon: { glyph: id }, detail: held[id] })] : [];
    return {
      ...base,
      title: nodeName(self, catalog),
      subtitle: [diagram, count === null ? "" : plural(count, "person", "people")].filter(Boolean),
      columns: [
        [
          nodeCard(self, {
            count: countOf(self),
            detail: [a.region, a.ownership].flatMap((v) => (typeof v === "string" ? [name(v)] : [])),
          }),
        ],
        access,
        targets,
        [...destination("internet", "Internet & SaaS"), ...destination("apps", "Private apps")],
      ].filter((c) => c.length),
      box: null,
      lines: [
        ...outbound.flatMap((o) => [
          { ...o.line, from: self.id, to: `via-${o.r.id}`, label: "" },
          { ...o.line, from: `via-${o.r.id}`, to: o.target.id, label: "" },
        ]),
        ...onward.values(),
      ],
    };
  }

  // A cloud: its apps and networks inside, and on its boundary its hub and then its firewalls or connectors,
  // which the networks' lines pass through in turn, and what it connects to.
  function cloudView(): ZoomView {
    const networks = recordsOf<Network>("networks", filled.named);
    // Apps stand in the order of their networks, those in none last, so their lines run side by side.
    const rank = (r: Hosted) => {
      const i = networks.findIndex((n) => n.id === r.network);
      return i < 0 ? networks.length : i;
    };
    const apps = recordsOf<Hosted>("apps", filled.named).sort((x, y) => rank(x) - rank(y));
    // Apps in none of its networks share a quiet card after them, marked with a question, as a security service's
    // sizing marks where no region was said.
    const unnetworked = networks.length > 0 && apps.some((r) => rank(r) === networks.length);
    const regions = [...new Set(networks.flatMap((r) => (r.region ? [r.region] : [])))];
    // Isolated networks have no hub.
    const hub = typeof a.transit === "string" && a.transit !== "hub-isolated" ? a.transit : null;
    const boundary = [...(hub ? [card({ id: "hub", name: name(hub), icon: { node: { category: "cloud-hub", itemId: hub } } })] : []), ...edgeCards];
    const chain = through(boundary);
    // Links leave from the hub, else the last firewall or connector, else the cloud's box.
    const from = hub ? "hub" : (chain.outer ?? self.id);
    const leave = (l: ZoomLine): ZoomLine => ({ ...l, from });
    // Flows read in the order the template offers them.
    const offered = template.slots.find((s) => s.id === self.slot)?.attributes.find((x) => x.key === "inspects");
    const order = offered?.type === "records" ? offered.fields.flatMap((f) => (f.type === "pick" ? (f.items ?? []) : [])) : [];
    // Each flow's chip is its first record, so it brings that record into view in the tray.
    const flowing = new Map<string, string>();
    for (const r of list<Flow>(a.inspects)) if (r.flow && !flowing.has(r.flow)) flowing.set(r.flow, r.id);
    const times = (count: unknown) => ((num(count) ?? 1) > 1 ? `×${fmt(num(count)!)}` : null);
    const networkCards = [
      ...networks.map((r) =>
        card({
          id: r.id,
          name: r.name!,
          count: times(r.count),
          detail: r.region ? [r.region] : [],
          icon: r.kind ? { node: { category: "cloud-network-kind", itemId: r.kind } } : { glyph: "network" },
        }),
      ),
      ...(unnetworked ? [card({ id: "network:none", name: "", icon: { glyph: "unnetworked" }, quiet: true })] : []),
    ];
    const inside = [
      apps.map((r) => card({ id: r.id, name: r.name!, count: times(r.count), icon: { glyph: "apps" } })),
      networkCards,
    ].filter((c) => c.length);
    // An app joins the network it sits in; with no networks, it stands in their place on the way out.
    const sits = apps.flatMap((r) => {
      const to = networks.length ? (networks[rank(r)]?.id ?? "network:none") : chain.inner;
      return to ? [line({ from: r.id, to })] : [];
    });
    return {
      ...base,
      title: nodeName(self, catalog),
      subtitle: [diagram, networks.length ? plural(networkCount(networks), "network") : "", regions.join(" · ")].filter(Boolean),
      inspected: [...new Set([...order, ...flowing.keys()])]
        .filter((f) => flowing.has(f))
        .map((f) => card({ id: flowing.get(f)!, name: name(f), icon: { node: { category: "cloud-flow", itemId: f } } })),
      columns: [
        ...(inside.length ? inside : [[nodeCard(self)]]),
        boundary,
        unique([...outbound.map((o) => nodeCard(o.target)), ...dependents.map((d) => nodeCard(d.n, { count: countOf(d.n) }))]),
      ].filter((c) => c.length),
      box: {
        id: self.id,
        column: 0,
        span: Math.max(1, inside.length),
        boundary: boundary.length > 0,
        icon: { category: self.category, itemId: self.itemId },
      },
      lines: [
        ...sits,
        ...(chain.inner ? networkCards.map((c) => line({ from: c.id, to: chain.inner! })) : []),
        ...chain.links,
        ...outbound.map((o) => leave(o.line)),
        ...dependents.map((d) => leave(inboundLine(d, from, d.n.id))),
      ],
    };
  }

  // The security service: its on-ramps on the left, inside it the regions they come from with what each adds up to, and
  // its off-ramps on the right.
  function securityView(): ZoomView {
    const sized = sizing(now, self.id);
    const byRegion = (x: string | null, y: string | null) =>
      x === y ? 0 : x === null ? 1 : y === null ? -1 : name(x).localeCompare(name(y));
    const stats = (s: Sizing): ZoomCard["stats"] => [
      ...(s.users ? [{ glyph: "users" as const, value: fmt(s.users) }] : []),
      ...(s.sites ? [{ glyph: "sites" as const, value: fmt(s.sites) }] : []),
      ...(s.mbps ? [{ glyph: "bandwidth" as const, value: speedOf(s.mbps) }] : []),
    ];
    // An uncounted population still reaches the service, but a question pin with no numbers says nothing.
    const keys = [...sized.keys()].filter((k) => k !== null || stats(sized.get(k)!).length).sort(byRegion);
    // Without a region to tell apart, the service's own card holds the numbers, as a data center's does.
    const inside = keys.some((k) => k !== null)
      ? keys.map((key) =>
          card({ id: `region:${key ?? "none"}`, name: key ? name(key) : "", icon: { glyph: key ? "region" : "unplaced" }, stats: stats(sized.get(key)!) }),
        )
      : [nodeCard(self, { stats: stats(sized.get(null) ?? NONE) })];
    const into = (n: Node) => {
      const id = `region:${regionOf(n) ?? "none"}`;
      return inside.some((c) => c.id === id) ? id : self.id;
    };
    // Each line between another node and the service, a node grouped with it being part of it. A line of a type the line
    // table doesn't place leaves the service when entered on it, and comes in otherwise.
    const service = sizedThrough(now, self.id);
    const ramps = [
      ...now
        .filter((n) => !service.includes(n.id))
        .flatMap((n) =>
          list<Connection>(n.attrs.connections)
            .filter((c) => filled.connections(c) && !!c.to && service.includes(c.to))
            .map((c) => ({ n, c, label: connectionLabel(c, siteOf(n), name), ramp: rampOf(c.type) ?? "on" })),
        ),
      ...outbound
        .filter((o) => !service.includes(o.target.id))
        .map((o) => ({ n: o.target, c: o.r, label: o.line.label, ramp: rampOf(o.r.type) ?? "off" })),
    ];
    // On-ramps sort by region as the region cards do, even from a region with nothing sized, so their lines run side by
    // side rather than across.
    const on = ramps
      .filter((r) => r.ramp === "on")
      .sort((x, y) => byRegion(regionOf(x.n), regionOf(y.n)) || ON_RAMPS.indexOf(x.n.kind) - ON_RAMPS.indexOf(y.n.kind));
    const off = ramps.filter((r) => r.ramp === "off").sort((x, y) => OFF_RAMPS.indexOf(x.n.kind) - OFF_RAMPS.indexOf(y.n.kind));
    // Apps take a line each, as on a site's zoom, so none is cut short. On the summary they are the node's last line of detail.
    const detailOf = (n: Node) => {
      const s = summary.nodes.find((x) => x.id === n.id);
      const apps = appNames(n);
      if (!s || !apps.length) return s?.detail ?? [];
      return [...new Set([...s.detail.slice(0, -1), ...apps])];
    };
    const left = unique(on.map((r) => nodeCard(r.n, { count: countOf(r.n) })));
    // A node on both sides stands on each, its off-ramp card under an id of its own.
    const right = unique(off.map((r) => nodeCard(r.n, { id: `off:${r.n.id}`, entry: r.n.id, detail: detailOf(r.n) })));
    const rampLine = (r: (typeof ramps)[number], from: string, to: string) => line({ from, to, label: r.label, type: r.c.type ?? null });
    const total = [...sized.values()].reduce(plus, NONE);
    // A link counts whichever end the SE entered it on.
    const linked = (type: string) => ramps.filter((r) => r.c.type === type).reduce((t, r) => t + (num(r.c.count) ?? 1), 0);
    const [connections, connectors] = [linked("conn-service-connection"), linked("conn-ztna-connector")];
    const facts = [
      typeof a.edition === "string" ? name(a.edition) : "",
      total.users ? `${plural(total.users, "remote user")}${total.browser ? `, ${fmt(total.browser)} on ${name("conn-prisma-browser")}` : ""}` : "",
      total.sites ? `${plural(total.sites, "site")}${total.mbps ? ` at ${speedOf(total.mbps)}` : ""}` : "",
      connections ? plural(connections, "service connection") : "",
      connectors ? plural(connectors, "ZTNA connector") : "",
    ];
    return {
      ...base,
      title: nodeName(self, catalog),
      subtitle: [diagram, ...facts].filter(Boolean),
      columns: [left, inside, right].filter((c) => c.length),
      heads: [
        ...(left.length ? [{ column: 0, glyph: "onramp" as const, name: "On-ramps" }] : []),
        ...(right.length ? [{ column: left.length ? 2 : 1, glyph: "offramp" as const, name: "Off-ramps" }] : []),
      ],
      tiles: serviceTiles(),
      box: { id: self.id, column: left.length ? 1 : 0, boundary: false, icon: { category: self.category, itemId: self.itemId } },
      lines: [...on.map((r) => rampLine(r, r.n.id, into(r.n))), ...off.map((r) => rampLine(r, self.id, `off:${r.n.id}`))],
    };
  }

  // An SD-WAN platform: the site groups, data centers and clouds on its fabric on the left, inside it their sites, its
  // appliances and their bandwidth, and on the right where those sites' SD-WAN goes and what it connects to.
  function sdwanView(): ZoomView {
    const appliances = (n: Node) => list<Edge>(n.attrs.edge).filter((r) => !!self.itemId && r.product === self.itemId);
    const fabric = (n: Node) => n.kind === "site" || n.kind === "datacenter" || n.kind === "cloud";
    const carries = (n: Node) => fabric(n) && appliances(n).length > 0;
    const joined = dependents.filter((d) => fabric(d.n));
    const carrying = now.filter((n) => carries(n) && !joined.some((d) => d.n.id === n.id)).map((n) => ({ n }));
    const sdwan = (n: Node) => list<Connection>(n.attrs.connections).filter((c) => c.type === "conn-sd-wan");
    const groupsIn = (nodes: Node[]) =>
      nodes.filter((n) => n.kind === "site" && (appliances(n).length || list<Connection>(n.attrs.connections).some((c) => c.to === self.id)));
    const totals = (nodes: Node[]) =>
      groupsIn(nodes).reduce(
        (t, n) => {
          const count = num(n.attrs.count) ?? 1;
          return {
            sites: t.sites + count,
            appliances: t.appliances + count * appliances(n).reduce((sum, r) => sum + (num(r.count) ?? 1), 0),
            mbps: t.mbps + count * Math.max(0, ...sdwan(n).map((c) => linkMbps(c, siteOf(n)))),
          };
        },
        { sites: 0, appliances: 0, mbps: 0 },
      );
    const total = totals(now);
    const left = unique([...joined, ...carrying].map((d) => nodeCard(d.n, { count: countOf(d.n), detail: appliances(d.n).map(deviceName) })));
    const onward = [
      ...new Set(groupsIn(now).flatMap((n) => sdwan(n).flatMap((c) => (c.to !== self.id && find(c.to) ? [find(c.to)!] : [])))),
    ];
    const others = dependents.filter((d) => !fabric(d.n));
    return {
      ...base,
      title: nodeName(self, catalog),
      subtitle: [
        diagram,
        total.sites ? `${plural(total.sites, "site")}${total.mbps ? ` at ${speedOf(total.mbps)}` : ""}` : "",
        total.appliances ? plural(total.appliances, "appliance") : "",
      ].filter(Boolean),
      columns: [
        left,
        [
          nodeCard(self, {
            stats: [
              ...(total.sites ? [{ glyph: "sites" as const, value: fmt(total.sites) }] : []),
              ...(total.appliances ? [{ glyph: "device" as const, value: fmt(total.appliances) }] : []),
              ...(total.mbps ? [{ glyph: "bandwidth" as const, value: speedOf(total.mbps) }] : []),
            ],
          }),
        ],
        unique([
          ...onward.map((n) => nodeCard(n)),
          ...outbound.map((o) => nodeCard(o.target)),
          ...others.map((d) => nodeCard(d.n, { count: countOf(d.n) })),
        ]),
      ].filter((c) => c.length),
      tiles: serviceTiles(),
      box: { id: self.id, column: left.length ? 1 : 0, boundary: false, icon: { category: self.category, itemId: self.itemId } },
      lines: [
        ...joined.map((d) => inboundLine(d, d.n.id, self.id)),
        ...carrying.map((d) => line({ from: d.n.id, to: self.id, type: "conn-sd-wan" })),
        ...onward.map((n) => line({ from: self.id, to: n.id, type: "conn-sd-wan" })),
        ...outbound.map((o) => o.line),
        ...others.map((d) => inboundLine(d, self.id, d.n.id)),
      ],
    };
  }

  return view();
}

export type AppKind = "bought" | "built";
// A product people use is bought: the customer controls only how their people reach it and what it sees in their tenant.
// Everything else the slot accepts, and free text, is built: the customer controls what the app calls.
const BOUGHT = new Set(["employee-productivity", "coding-assistance", "enterprise-search", "research-and-analysis", "ai-security-assistant"]);
export const appKind = (entry: Pick<Entry, "itemId">, catalog: CatalogLookup): AppKind =>
  entry.itemId && BOUGHT.has(catalog(entry.itemId)?.category ?? "") ? "bought" : "built";

// Where Palo Alto Networks AI security can insert into an AI app, each a field of its entry holding capabilities.
const INSERTIONS = ["endpoints", "access", "prompts", "tenant", "build", "model-calls", "tool-calls", "data-calls"] as const;
type Insertion = (typeof INSERTIONS)[number];
const PARTS: Record<AppKind, readonly string[]> = {
  bought: ["app-users", "endpoints", "access", "tenant"],
  built: ["app-users", "prompts", "build", "model-calls", "app-models", "tool-calls", "app-tools", "data-calls", "app-data"],
};
// A row out of a built app stands once something is named in it or placed on its line; models always, since every AI app calls a model.
const ROWS = [
  { key: "models", field: "app-models", line: "model-calls" },
  { key: "tools", field: "app-tools", line: "tool-calls" },
  { key: "data", field: "app-data", line: "data-calls" },
] as const;
// What a field holds, as the picture counts it: a record with a name, or a capability.
const namesIn = (attrs: Entry["attrs"], key: string) => [
  ...new Set(list<{ name?: unknown }>(attrs[key]).flatMap((r) => (typeof r.name === "string" && r.name ? [r.name] : []))),
];
const placedIn = (attrs: Entry["attrs"], key: string) =>
  list<{ capability?: unknown }>(attrs[key]).some((r) => typeof r.capability === "string");
export type Placed = { id: string; name: string; products: string[]; inPlace: boolean };
export type AppRow = (typeof ROWS)[number] & { names: string[]; placed: Placed[] };
export type AppView = {
  layout: "ai-app";
  kind: AppKind;
  title: string;
  subtitle: string[];
  icon: { category: string; itemId: string | null };
  users: string[];
  // Every insertion, whatever the kind: the renderers draw each where the kind has a place for it.
  at: Record<Insertion, Placed[]>;
  rows: AppRow[];
};

const IN_PLACE = "capability-in-place";

const columnOf = (template: BoardTemplate, slotId: string) => {
  if (template.layout !== "grid") return [];
  const rows = template.groups ? template.groups.flatMap((g) => g.rows) : (template.rows ?? []);
  const column = template.columns?.[rows.find((r) => r.includes(slotId))?.indexOf(slotId) ?? -1];
  return column ? [column] : [];
};

// An AI app: who uses it, the app, what a built app calls, and the capabilities placed where they insert.
export function appView(
  template: BoardTemplate,
  data: BoardData,
  entryId: string,
  catalog: CatalogLookup,
  // The names of the products that deliver each capability.
  products: Record<string, string[]>,
): AppView | null {
  const self = data.entries.find((e) => e.id === entryId);
  const slot = self && template.slots.find((s) => s.id === self.slot);
  if (!self || !slot) return null;
  const name = (id: string) => catalog(id)?.name ?? id;
  // A capability placed twice at one point shows once, in place if either record says so.
  const placed = (key: Insertion): Placed[] => {
    const inPlace = new Map<string, boolean>();
    for (const r of list<{ capability?: unknown; status?: unknown }>(self.attrs[key]))
      if (typeof r.capability === "string") inPlace.set(r.capability, !!inPlace.get(r.capability) || r.status === IN_PLACE);
    return [...inPlace].map(([id, settled]) => ({ id, name: name(id), products: products[id] ?? [], inPlace: settled }));
  };
  const kind = appKind(self, catalog);
  const at = Object.fromEntries(INSERTIONS.map((key) => [key, placed(key)])) as AppView["at"];
  return {
    layout: "ai-app",
    kind,
    title: self.itemId ? name(self.itemId) : self.text!,
    subtitle: slot.planned ? columnOf(template, slot.id) : [],
    icon: { category: (self.itemId && catalog(self.itemId)?.category) || slot.categories[0], itemId: self.itemId },
    users: namesIn(self.attrs, "app-users"),
    at,
    rows:
      kind === "built"
        ? ROWS.map((r) => ({ ...r, names: namesIn(self.attrs, r.field), placed: at[r.line] })).filter(
            (r) => r.key === "models" || r.names.length || r.placed.length,
          )
        : [],
  };
}

// What the tray offers one app: its kind's parts, a row's line once the row stands, and whatever the entry already holds, so the SE
// can clear it (the rule FieldsEditor applies to `for`). Attributes not tied to a part of the zoom pass through.
export function appAttributes(slot: BoardTemplate["slots"][number], entry: Pick<Entry, "attrs">, kind: AppKind) {
  const held = (key: string) => namesIn(entry.attrs, key).length > 0 || placedIn(entry.attrs, key);
  return slot.attributes.filter((a) => {
    if (!a.at || held(a.key)) return true;
    if (!PARTS[kind].includes(a.key)) return false;
    const row = ROWS.find((r) => r.line === a.key && r.key !== "models");
    return !row || held(row.field);
  });
}
