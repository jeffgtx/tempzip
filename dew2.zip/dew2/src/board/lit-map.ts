import type { CatalogItem } from "@/content/schema";
import { attachedTo, concernLevel } from "./concerns";
import type { Entry } from "./model";

export type LitCapability = {
  id: string;
  name: string;
  summary: string | null;
  products: string[];
  level: number;
  computed: number;
  forced: number | null;
  // The concerns at 1 or more, or attached, routed to it, in the catalog's order and then the customer's words as added, so
  // nothing moves as levels change. A catalog concern's key is its item, any other's its entry; attached means the SE
  // routed it here. Attached ones stay listed below 1 so the cockpit can still detach them.
  concerns: { key: string; label: string; attached: boolean; level: number }[];
};
// The concerns the room and the notes name.
export const named = (k: LitCapability["concerns"][number]) => k.level > 0;
export type LitGroup = { id: string; name: string; summary: string | null; hidden: boolean; capabilities: LitCapability[] };

// The names of the products that deliver each capability. Every one is Palo Alto Networks', so it reads without the brand.
export function capabilityProducts(items: CatalogItem[]): Record<string, string[]> {
  const names = new Map(items.map((i) => [i.id, i.name.replace(/^Palo Alto Networks /, "")]));
  return Object.fromEntries(items.filter((i) => i.deliveredBy.length).map((i) => [i.id, i.deliveredBy.map((p) => names.get(p) ?? p)]));
}

// A capability's level is the highest level among the concerns routed to it, by the catalog or by the SE,
// unless an override entry forces it, 0 turning it off; an override entry for a group hides it.
export function litMap(input: {
  groups: CatalogItem[];
  items: CatalogItem[];
  concerns: Pick<Entry, "id" | "itemId" | "text" | "attrs">[];
  // The concerns answers imply, which need no entry.
  implied: Set<string>;
  overrides: Pick<Entry, "itemId" | "attrs">[];
}): LitGroup[] {
  const items = new Map(input.items.map((i) => [i.id, i]));
  const order = new Map(input.items.map((i, n) => [i.id, n]));
  const entered = new Set(input.concerns.map((e) => e.itemId));
  const concerns = [
    ...input.concerns,
    ...[...input.implied].filter((id) => !entered.has(id)).map((id) => ({ id, itemId: id, text: null, attrs: {} as Entry["attrs"] })),
  ]
    .flatMap((e) => {
      const item = e.itemId ? items.get(e.itemId) : undefined;
      const label = item ? (item.short ?? item.name) : !e.itemId && e.text;
      const level = concernLevel(e.attrs, input.implied.has(e.itemId ?? "")) ?? 0;
      const own = attachedTo(e.attrs);
      if (!label || (!level && !own.length)) return [];
      const rank = item ? order.get(item.id)! : order.size;
      return [{ key: item?.id ?? e.id, label, level, catalog: item?.routes ?? [], own, rank }];
    })
    .sort((a, b) => a.rank - b.rank);
  const forced = new Map(input.overrides.map((e) => [e.itemId, e.attrs.level]));
  const products = capabilityProducts(input.items);

  return input.groups.map((group) => ({
    id: group.id,
    name: group.name,
    summary: group.summary ?? null,
    hidden: input.overrides.some((e) => e.itemId === group.id),
    capabilities: input.items
      .filter((i) => i.group === group.id)
      .map((capability) => {
        const by = concerns.filter((c) => c.catalog.includes(capability.id) || c.own.includes(capability.id));
        const computed = Math.max(0, ...by.map((c) => c.level));
        const pick = forced.get(capability.id);
        const level = typeof pick === "number" && pick >= 0 && pick <= 3 ? pick : null;
        return {
          id: capability.id,
          name: capability.name,
          summary: capability.summary ?? null,
          products: products[capability.id] ?? [],
          level: level ?? computed,
          computed,
          forced: level,
          concerns: by
            .filter((c) => c.level || c.own.includes(capability.id))
            .map((c) => ({ key: c.key, label: c.label, attached: !c.catalog.includes(capability.id), level: c.level })),
        };
      }),
  }));
}

export type LitGroupView = {
  layout: "lit-group";
  name: string;
  summary: string | null;
  capabilities: (Pick<LitCapability, "id" | "name" | "summary" | "products" | "level" | "concerns"> & { focused: boolean })[];
};

// One capability group's zoom, as the room shows it.
export const litGroupView = (g: LitGroup, focused: (id: string) => boolean = () => false): LitGroupView => ({
  layout: "lit-group",
  name: g.name,
  summary: g.summary,
  capabilities: g.capabilities.map(({ id, name, summary, products, level, concerns }) => ({
    id,
    name,
    summary,
    products,
    level,
    concerns: concerns.filter(named),
    focused: focused(id),
  })),
});
