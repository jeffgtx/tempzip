import type { Architecture } from "@/content/schema";
import type { Connection } from "./architecture";
import { type BoardData, type Op, ensureOp, entriesIn, opChain, setAttrOp } from "./model";
import { list } from "./summary";

// What an architecture adds to a diagram, as one change: the nodes it lacks, matched by item in the order the
// architecture lists them, and the lines of each type not yet drawn between the same two nodes, from either end. A node already
// there keeps its fields; one it adds is grouped as the architecture groups it. Null when nothing is missing.
export function presetOps(data: BoardData, architecture: Architecture): Op | null {
  const chain = opChain(data);
  const ids = new Map<string, string>();
  const created = new Set<string>();
  for (const n of architecture.nodes) {
    const ensured = ensureOp(chain.data, n.slot, n.item, n.name ? { name: n.name } : {}, new Set(ids.values()));
    if (!chain.data.entries.some((e) => e.id === ensured.id)) created.add(n.key);
    ensured.ops.forEach(chain.apply);
    ids.set(n.key, ensured.id);
  }
  const attrsOf = (key: string, slot: string) => entriesIn(chain.data, slot).find((e) => e.id === ids.get(key))!.attrs;
  for (const n of architecture.nodes)
    if (n.group && created.has(n.key)) chain.apply(setAttrOp(chain.data, ids.get(n.key)!, "group", ids.get(n.group)));
  for (const { from, to, type } of architecture.connections) {
    const slot = architecture.nodes.find((n) => n.key === from)!.slot;
    const target = to ? ids.get(to)! : null;
    const current = list<Connection>(attrsOf(from, slot).connections);
    if (current.some((c) => c.type === type && (c.to ?? null) === target)) continue;
    const toSlot = architecture.nodes.find((n) => n.key === to)?.slot;
    if (toSlot && list<Connection>(attrsOf(to!, toSlot).connections).some((c) => c.type === type && c.to === ids.get(from)))
      continue;
    chain.apply(setAttrOp(chain.data, ids.get(from)!, "connections", [...current, { id: crypto.randomUUID(), type, to: target }]));
  }
  return chain.op();
}
