import { type Connection, rampOf } from "./architecture";
import { DIRECT, type Flow, legOf } from "./flows";
import { type Node, type SummaryView, list } from "./summary";

export type Destination = "internet" | "apps";
export type Route = {
  to: Destination;
  // The connection record the route leaves on: the node's own, or a link another node entered to it; null for a population
  // going direct.
  line: string | null;
  // What the destination names: the hub passed through for the internet, where the apps live for private apps.
  places: Node[];
  // A saved flow's app, which labels the line.
  app: string | null;
};
type Places = Partial<Record<Destination, Node[]>>;

const filled = (c: Connection) => !!(c.type || c.product);
const connections = (n: Node) => list<Connection>(n.attrs.connections).filter(filled);
const between = (a: Node, b: Node) => [...connections(a).filter((c) => c.to === b.id), ...connections(b).filter((c) => c.to === a.id)];
const web = (n: Node) => n.kind === "internet" || n.kind === "saas";
const leadOf = (nodes: Node[], n: Node) => nodes.find((l) => l.id === n.attrs.group && l.kind === "security");
const HANDOFF = ["datacenter", "cloud", "site", "partner"];
const JOINED = ["security", "datacenter", "cloud"];

// Where a line into n leads on to, and the places each destination names.
function ahead(nodes: Node[], n: Node): Places {
  if (n.kind === "security") {
    const handed = nodes.filter((h) => HANDOFF.includes(h.kind) && between(h, n).some((c) => rampOf(c.type) === "off"));
    const leads: Destination[] = n.category === "ztna" || n.category === "browser-connector" ? ["apps"] : ["internet", "apps"];
    return Object.fromEntries(leads.map((to) => [to, to === "internet" || !handed.length ? [n] : handed]));
  }
  if (n.kind === "datacenter" || n.kind === "cloud") {
    // Its own internet goes out by egress, or as a remote network or proxy to a SASE or web gateway, since a service
    // connection doesn't carry that traffic.
    const webOut = connections(n).some((c) => {
      const to = nodes.find((t) => t.id === c.to);
      return !!to && (web(to) || (rampOf(c.type) === "on" && (to.category === "sase" || to.category === "swg")));
    });
    return { ...(webOut && { internet: [n] }), apps: [n] };
  }
  if (n.kind !== "sdwan") return {};
  const lead = leadOf(nodes, n);
  if (lead) return ahead(nodes, lead);
  const union: Places = {};
  for (const j of nodes.filter((j) => JOINED.includes(j.kind) && between(j, n).length))
    for (const [to, places] of Object.entries(ahead(nodes, j)) as [Destination, Node[]][])
      union[to] = [...new Set([...(union[to] ?? []), ...places])];
  return union;
}

// Where one of a node's own lines leads, and the places each destination names.
function ends(nodes: Node[], c: Connection): Places {
  if (!c.to) return c.type === DIRECT ? { internet: [] } : {};
  const target = nodes.find((n) => n.id === c.to);
  if (!target) return {};
  if (web(target)) return { internet: [] };
  // A service connection, ZTNA Connector or Colo-Connect carries traffic in to the apps beside the node.
  if (rampOf(c.type) === "off") return {};
  return ahead(nodes, target);
}

// A site group's or population's routes among the live nodes. A saved flow from it pins the destination it reaches, leaving
// on the line its first leg lights. Elsewhere its own lines decide: the internet by every breakout, line to the internet or
// SaaS and line to a security service that leads there, else by every line that does; private apps by every line that does.
export function routesOf(view: SummaryView, nodes: Node[], flows: Flow[], who: Node): Route[] {
  const find = (id: string | null | undefined) => nodes.find((n) => n.id === id);
  const flown = flows.flatMap((flow): Route[] => {
    const where = flow.who === who.id ? find(flow.where) : undefined;
    if (!where) return [];
    const to: Destination = web(where) ? "internet" : "apps";
    const through = find(flow.through);
    const places = to === "apps" ? [where] : through ? [through] : [];
    const lines = flow.how === DIRECT && who.kind !== "site" ? [null] : legOf(view, flow);
    return lines.map((line) => ({ to, line, places, app: flow.app }));
  });
  const pinned = new Set(flown.map((r) => r.to));
  const own = connections(who).flatMap((c) => {
    const target = find(c.to);
    return !c.to || target ? [{ c, target, ends: ends(nodes, c) }] : [];
  });
  const before = (target: Node | undefined) =>
    !target || web(target) || target.kind === "security" || (target.kind === "sdwan" && !!leadOf(nodes, target));
  const leaving = (to: Destination) => {
    const reaching = own.filter((o) => o.ends[to]);
    const first = to === "internet" ? reaching.filter((o) => before(o.target)) : [];
    return (first.length ? first : reaching).map((o): Route => ({ to, line: o.c.id, places: o.ends[to]!, app: null }));
  };
  return [...flown, ...(["internet", "apps"] as const).filter((to) => !pinned.has(to)).flatMap(leaving)];
}
