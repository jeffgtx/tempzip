import { z } from "zod";
import type { BoardTemplate } from "@/content/schema";
import { concernGroup } from "./concerns";

const status = z.enum(["live", "ghost", "dismissed"]);
const attrs = z.record(z.string(), z.unknown());

// The room shows live entries only, never ghosts or dismissals.
export const live = (data: BoardData): BoardData => ({ entries: data.entries.filter((e) => e.status === "live") });

// A grid in groups lays out the group its pane picks.
export const gridRows = (template: Extract<BoardTemplate, { layout: "grid" }>, pane: number) =>
  template.groups ? (template.groups[pane] ?? template.groups[0]).rows : template.rows!;

// The pane of a board in groups that holds an entry: its slot's group on a grid, its concern's on a ranked list. Null on
// a board not in groups, and for a slot every group shows.
export function paneOf(
  template: BoardTemplate,
  entry: Pick<Entry, "slot" | "itemId" | "attrs">,
  categoryOf: (itemId: string) => string | undefined,
) {
  if (template.layout === "ranked-list") {
    const groups = template.slots[0].categories;
    return groups.indexOf(concernGroup(groups, entry.itemId, entry.attrs, categoryOf));
  }
  const at = template.layout === "grid" && template.groups ? template.groups.findIndex((g) => g.rows.flat().includes(entry.slot)) : -1;
  return at < 0 ? null : at;
}

// The zoom an entry opens: its slot's, else its category's, and on a slot that zooms on request only once added.
// Free text takes its slot's first category.
export const zoomOf = (
  template: Pick<BoardTemplate, "slots" | "zooms">,
  slotId: string,
  category?: string | null,
  attrs?: Record<string, unknown>,
) => {
  const slot = template.slots.find((s) => s.id === slotId);
  if (!slot || (slot.zoomOnRequest && attrs?.zoom !== true)) return undefined;
  return slot.zoom ?? template.zooms[category || slot.categories[0]];
};

// What a grid entry shows beside its name and count, in the cockpit and the room alike: the levels of its coverage mode
// and of a planned one that differs, and its detail. An entry that opens a zoom shows its fields there instead.
export function gridEntryFacts(
  template: Pick<BoardTemplate, "slots" | "zooms">,
  slotId: string,
  attrs: Entry["attrs"],
  catalog: (id: string) => { name: string; category: string } | undefined,
) {
  const slot = template.slots.find((s) => s.id === slotId)!;
  const name = (id: string) => catalog(id)?.name ?? id;
  const level = (mode: unknown) => (typeof mode === "string" ? (catalog(mode)?.category ?? null) : null);
  const { coverage: mode, goal: plan } = attrs;
  const coverage = level(mode);
  const goal = typeof plan === "string" && plan !== mode ? level(plan) : null;
  // A planned mode at the current level, such as out-of-band for agentless, names itself so its accent has a reason.
  const renamed = goal && goal === coverage ? [name(plan as string)] : [];
  const zooms = !!slot.zoom || slot.categories.some((c) => template.zooms[c]);
  const picks = zooms ? [] : slot.attributes.filter((a) => a.type === "pick" && a.key !== "coverage" && a.key !== "goal");
  return {
    coverage,
    goal,
    detail: [...renamed, ...picks.flatMap((a) => (typeof attrs[a.key] === "string" ? [name(attrs[a.key] as string)] : []))],
  };
}

// What a grid cell shows of an entry that opens a zoom, besides its item: its name, levels, mark and count, and whether
// it has its zoom at all.
const CELL_ATTRS = ["name", "coverage", "goal", "mark", "count", "zoom"];

// The one entry an op changes in fields a grid shows only in the entry's zoom rather than its cell. Editing a ghost's
// fields confirms it in the same op, so the change still counts.
export function zoomOnlyChange(op: Op): string | null {
  const updates = (op.type === "batch" ? op.ops : [op]).flatMap((o) => (o.type === "update" ? o.updates : [null]));
  const [first] = updates;
  const changed = (u: NonNullable<(typeof updates)[number]>) =>
    Object.keys({ ...u.set.attrs, ...u.prev.attrs }).filter((k) => !sameValue(u.set.attrs?.[k], u.prev.attrs?.[k]));
  const inCell = updates.some(
    (u) =>
      !u ||
      u.entryId !== first!.entryId ||
      Object.keys(u.set).some((k) => k !== "attrs" && k !== "status") ||
      changed(u).some((k) => CELL_ATTRS.includes(k)),
  );
  return first && !inCell && updates.some((u) => changed(u!).length) ? first.entryId : null;
}

// A board's own categories and its slots'. A slot that accepts every category offers and suggests into these.
export const boardCategories = (template: Pick<BoardTemplate, "categories" | "slots">) => [
  ...new Set([...template.categories, ...template.slots.flatMap((s) => s.categories)]),
];

// What the SE can mark a grid entry with, in the order one control cycles through them. They carry no meaning of their own.
export const MARKS = ["flag", "star", "bolt", "diamond"] as const;
export type Mark = (typeof MARKS)[number];
export const markOf = (attrs: Entry["attrs"]) => (MARKS.includes(attrs.mark as Mark) ? (attrs.mark as Mark) : null);

// What each layout keeps in an entry's attributes. Other layouts keep their slots' declared attributes.
export const layoutAttrs = {
  // Level is the SE's pick, 0 for not a concern to 3, which wins over what answers imply; group places a concern in the
  // customer's words; routes are the capabilities the SE attached it to beyond the catalog's.
  "ranked-list": z.strictObject({
    level: z.number().int().min(0).max(3).optional(),
    group: z.string().min(1).max(100).optional(),
    routes: z.array(z.string().min(1).max(100)).max(50).optional(),
  }),
  // A capability forced to a level, 0 for unlit whatever its concerns say, where no entry means the computed level; a
  // group's entry hides the group.
  "lit-map": z.strictObject({ level: z.number().int().min(0).max(3).optional() }),
  // Owner is "us", "them" or a name.
  list: z.strictObject({
    owner: z.string().trim().min(1).max(100).optional(),
    due: z.iso.date().optional(),
    minutes: z.number().int().min(1).max(999).optional(),
  }),
};

const entry = z.strictObject({
  id: z.uuid(),
  slot: z.string().min(1),
  position: z.number(),
  itemId: z.string().min(1).nullable(),
  text: z.string().trim().min(1).max(200).nullable(),
  attrs,
  note: z.string().max(2000).nullable(),
  status,
});

// Changing an entry's item or text, as approving a suggestion does, must leave it
// one or the other; the server checks that.
const entryFields = z.strictObject({
  itemId: entry.shape.itemId.optional(),
  text: entry.shape.text.optional(),
  position: entry.shape.position.optional(),
  note: z.string().max(2000).nullable().optional(),
  status: status.optional(),
  attrs: attrs.optional(),
});

// An op's inverse is built from the op alone: a delete carries the rows it removes, and an update the values it
// replaces. A put only ever adds rows; a batch applies several ops as one undoable change. A diagram's copy is a put
// too, and a return visit's choice a delete or an update, but each is how the board starts rather than a change undo
// takes back.
const singleOp = z.discriminatedUnion("type", [
  z.strictObject({ type: z.literal("put"), entries: z.array(entry), copy: z.literal(true).optional() }),
  z.strictObject({ type: z.literal("delete"), entries: z.array(entry), visit: z.literal(true).optional() }),
  z.strictObject({
    type: z.literal("update"),
    updates: z.array(z.strictObject({ entryId: z.uuid(), set: entryFields, prev: entryFields })),
    visit: z.literal(true).optional(),
  }),
]);

// The room's one-line title and the export file names rely on the cap.
export const DIAGRAM_NAME_MAX = 60;
export const diagramName = z.string().trim().min(1).max(DIAGRAM_NAME_MAX);
const diagramFields = z.strictObject({ name: diagramName.optional(), position: z.number().int().optional() });

export const opSchema = z.union([
  singleOp,
  z.strictObject({ type: z.literal("batch"), ops: z.array(singleOp).min(1) }),
  // A diagram's name and its place among its template's diagrams, which no board's entries hold.
  z.strictObject({
    type: z.literal("diagrams"),
    updates: z.array(z.strictObject({ boardId: z.uuid(), set: diagramFields, prev: diagramFields })).min(1),
  }),
]);

export const commitSchema = z.strictObject({
  id: z.uuid(),
  boardId: z.uuid(),
  op: opSchema,
  reverts: z.uuid().nullable(),
  // The meeting running when the change was made, which a queued commit may outlive.
  meetingId: z.uuid().nullable(),
});

export type Entry = z.infer<typeof entry>;
export type SingleOp = z.infer<typeof singleOp>;
export type Op = z.infer<typeof opSchema>;
export type Commit = z.infer<typeof commitSchema>;
export type BoardData = { entries: Entry[] };
export type Diagram = { id: string; name: string; position: number };

// Ops are idempotent, so a commit replayed after a reconnect changes nothing twice.
export function applyOp(data: BoardData, op: Op): BoardData {
  switch (op.type) {
    case "batch":
      return op.ops.reduce(applyOp, data);
    case "diagrams":
      return data;
    case "put": {
      const ids = new Set(op.entries.map((e) => e.id));
      return { entries: [...data.entries.filter((e) => !ids.has(e.id)), ...op.entries] };
    }
    case "delete": {
      const ids = new Set(op.entries.map((e) => e.id));
      return { entries: data.entries.filter((e) => !ids.has(e.id)) };
    }
    case "update":
      return {
        entries: data.entries.map((e) => {
          const update = op.updates.find((u) => u.entryId === e.id);
          return update ? { ...e, ...update.set } : e;
        }),
      };
  }
}

export function invert(op: Op): Op {
  if (op.type === "batch") return { type: "batch", ops: op.ops.map(invertSingle).reverse() };
  if (op.type === "diagrams")
    return { type: "diagrams", updates: op.updates.map((u) => ({ boardId: u.boardId, set: u.prev, prev: u.set })) };
  return invertSingle(op);
}

function invertSingle(op: SingleOp): SingleOp {
  switch (op.type) {
    case "put":
      return { type: "delete", entries: op.entries };
    case "delete":
      return { type: "put", entries: op.entries };
    case "update":
      return { type: "update", updates: op.updates.map((u) => ({ entryId: u.entryId, set: u.prev, prev: u.set })) };
  }
}

// The ids of the entries an op changes.
export const entryIds = (op: Op): string[] =>
  op.type === "batch"
    ? op.ops.flatMap(entryIds)
    : op.type === "update"
      ? op.updates.map((u) => u.entryId)
      : op.type === "diagrams"
        ? []
        : op.entries.map((e) => e.id);

// The entries a put or delete carries whole.
export const carriedEntries = (op: Op): Entry[] =>
  op.type === "batch" ? op.ops.flatMap(carriedEntries) : op.type === "put" || op.type === "delete" ? op.entries : [];

// A template's diagrams in their order, as an op leaves them.
export const applyDiagrams = (list: Diagram[], op: Op) =>
  op.type === "diagrams"
    ? list.map((d) => ({ ...d, ...op.updates.find((u) => u.boardId === d.id)?.set })).sort((a, b) => a.position - b.position)
    : list;

export const renameOp = (diagram: Diagram, name: string): Op => ({
  type: "diagrams",
  updates: [{ boardId: diagram.id, set: { name }, prev: { name: diagram.name } }],
});

// Moving a diagram swaps its place with its neighbour's.
export function moveOp(list: Diagram[], id: string, by: -1 | 1): Op | null {
  const at = list.findIndex((d) => d.id === id);
  const [self, other] = [list[at], list[at + by]];
  if (!self || !other) return null;
  return {
    type: "diagrams",
    updates: [
      { boardId: self.id, set: { position: other.position }, prev: { position: self.position } },
      { boardId: other.id, set: { position: self.position }, prev: { position: other.position } },
    ],
  };
}

// A slot's entries in their order.
export const entriesIn = (data: BoardData, slot: string) =>
  data.entries.filter((e) => e.slot === slot).sort((a, b) => a.position - b.position);

export function addOp(
  data: BoardData,
  add: { id: string; slot: string; itemId?: string; text?: string; attrs?: Entry["attrs"]; status?: Entry["status"] },
): SingleOp {
  const positions = data.entries.filter((e) => e.slot === add.slot).map((e) => e.position);
  return {
    type: "put",
    entries: [
      {
        id: add.id,
        slot: add.slot,
        position: Math.max(0, ...positions) + 1,
        itemId: add.itemId ?? null,
        text: add.text ?? null,
        attrs: add.attrs ?? {},
        note: null,
        status: add.status ?? "live",
      },
    ],
  };
}

export const removeOp = (data: BoardData, entryId: string): SingleOp => ({
  type: "delete",
  entries: data.entries.filter((e) => e.id === entryId),
});

// Removing an entry takes every reference to it from the board's other entries, as one change: a reference field is
// cleared and a record pointing at it, such as a connection, goes.
export function removeEntryOp(template: BoardTemplate, data: BoardData, entryId: string): Op {
  const updates = data.entries.flatMap((e) => {
    if (e.id === entryId) return [];
    const attrs = { ...e.attrs };
    for (const a of template.slots.find((s) => s.id === e.slot)?.attributes ?? []) {
      if (a.type === "ref" && attrs[a.key] === entryId) delete attrs[a.key];
      if (a.type === "records" && Array.isArray(attrs[a.key])) {
        const refs = a.fields.filter((f) => f.type === "ref").map((f) => f.key);
        const records = attrs[a.key] as Record<string, unknown>[];
        const kept = records.filter((r) => !refs.some((k) => r[k] === entryId));
        if (kept.length) attrs[a.key] = kept;
        else if (records.length) delete attrs[a.key];
      }
    }
    if (template.layout === "hub-and-spoke" && attrs.group === entryId) delete attrs.group;
    return sameValue(attrs, e.attrs) ? [] : [updateOp([e], { attrs })];
  });
  return { type: "batch", ops: [removeOp(data, entryId), ...updates] };
}

export function updateOp(entries: Entry[], set: Partial<Pick<Entry, "note" | "status" | "attrs" | "text" | "position">>): SingleOp {
  return {
    type: "update",
    updates: entries.map((e) => ({
      entryId: e.id,
      set,
      prev: Object.fromEntries(Object.keys(set).map((k) => [k, e[k as keyof typeof set]])),
    })),
  };
}

const isEmpty = (value: unknown) =>
  value === undefined || value === null || value === "" || (Array.isArray(value) && value.length === 0);

// Field values compare by content: key order doesn't matter and empty fields count as absent.
const canonical = (value: unknown): unknown =>
  isEmpty(value)
    ? null
    : Array.isArray(value)
      ? value.map(canonical)
      : typeof value === "object"
        ? Object.fromEntries(
            Object.entries(value!)
              .filter(([, v]) => !isEmpty(v))
              .sort(([a], [b]) => a.localeCompare(b))
              .map(([k, v]) => [k, canonical(v)]),
          )
        : value;
export const sameValue = (a: unknown, b: unknown) => JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));

// Sets one attribute; an empty value takes it away.
export function setAttrOp(data: BoardData, entryId: string, key: string, value: unknown): SingleOp {
  const target = data.entries.find((e) => e.id === entryId)!;
  const attrs = { ...target.attrs };
  if (isEmpty(value)) delete attrs[key];
  else attrs[key] = value;
  return updateOp([target], { attrs });
}

// Builds one batched change from steps that each see the data the earlier ones left.
export function opChain(data: BoardData) {
  const ops: SingleOp[] = [];
  return {
    get data() {
      return data;
    },
    apply(op: SingleOp) {
      ops.push(op);
      data = applyOp(data, op);
    },
    op: (): Op | null => (ops.length ? { type: "batch", ops } : null),
  };
}

// Brings an item into a slot: back from the ghosts, or newly added. Entries in except don't count, so a repeating slot
// can get a second entry of the same item.
export function ensureOp(
  data: BoardData,
  slot: string,
  itemId: string,
  attrs?: Entry["attrs"],
  except: ReadonlySet<string> = new Set(),
): { ops: SingleOp[]; id: string } {
  const existing = entriesIn(data, slot).find((e) => e.itemId === itemId && e.status !== "dismissed" && !except.has(e.id));
  if (existing) return { ops: existing.status === "live" ? [] : [updateOp([existing], { status: "live" })], id: existing.id };
  const id = crypto.randomUUID();
  return { ops: [addOp(data, { id, slot, itemId, attrs })], id };
}

// Approving a suggestion turns its free-text entry into a reference to the item. With merge, a slot that already holds
// this item keeps that entry instead, so the item never shows twice, and takes the free text's note.
// What other entries' fields point at, wherever they hold it, moves from one entry to another.
function retarget(data: BoardData, from: string, to: string): SingleOp[] {
  const swap = (v: unknown): unknown =>
    v === from ? to : Array.isArray(v) ? v.map(swap) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, swap(x)])) : v;
  return data.entries.flatMap((e) => {
    if (e.id === from) return [];
    const attrs = swap(e.attrs) as Entry["attrs"];
    return sameValue(attrs, e.attrs) ? [] : [updateOp([e], { attrs })];
  });
}

export function approveOp(data: BoardData, entryId: string, itemId: string, merge: boolean): Op {
  const from = data.entries.find((e) => e.id === entryId)!;
  const into = merge ? data.entries.find((e) => e.slot === from.slot && e.itemId === itemId && e.status !== "dismissed") : undefined;
  if (!into) return { type: "update", updates: [{ entryId, set: { itemId, text: null }, prev: { itemId: null, text: from.text } }] };
  const ops: SingleOp[] = [removeOp(data, entryId), ...retarget(data, entryId, into.id)];
  const set = {
    ...(from.note && !into.note ? { note: from.note } : {}),
    ...(from.status === "live" && into.status === "ghost" ? { status: from.status } : {}),
  };
  if (Object.keys(set).length) ops.push(updateOp([into], set));
  return { type: "batch", ops };
}

// A dismissal is the SE's answer to a suggestion, not something the customer said, so a clean start keeps it.
export const clearOp = (data: BoardData, within: (e: Entry) => boolean = () => true) =>
  ({ type: "delete", entries: data.entries.filter((e) => e.status !== "dismissed" && within(e)) }) satisfies Op;

// A return visit's choice: start clean, or keep the earlier meetings' entries as ghosts.
export const visitOp = (data: BoardData, choice: "clean" | "ghost"): Op =>
  choice === "clean"
    ? { ...clearOp(data), visit: true }
    : {
        type: "update",
        updates: data.entries
          .filter((e) => e.status === "live")
          .map((e) => ({ entryId: e.id, set: { status: "ghost" }, prev: { status: e.status } })),
        visit: true,
      };

// Rebuilds the undo and redo stacks from a meeting's commits in order. An undo
// reverts the top of the undo stack; a redo reverts the top of the redo stack.
export function undoStacks<C extends { id: string; reverts: string | null; op: Op }>(commits: C[]) {
  const undo: C[] = [];
  let redo: C[] = [];
  for (const c of commits) {
    if ((c.op.type === "put" && c.op.copy) || ((c.op.type === "delete" || c.op.type === "update") && c.op.visit)) continue;
    if (c.reverts && undo.at(-1)?.id === c.reverts) {
      undo.pop();
      redo.push(c);
    } else if (c.reverts && redo.at(-1)?.id === c.reverts) {
      redo.pop();
      undo.push(c);
    } else {
      undo.push(c);
      redo = [];
    }
  }
  return { undo, redo };
}
