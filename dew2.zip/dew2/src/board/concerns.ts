import type { BoardTemplate, CatalogItem, Category } from "@/content/schema";
import type { Entry, Op } from "./model";
import type { Placed } from "./propagation";

type RankedTemplate = Extract<BoardTemplate, { layout: "ranked-list" }>;
type Slot = BoardTemplate["slots"][number];

// What the customer's answers on a ranked list's impliedBy boards imply: each item's own concerns and its category's.
export function impliedConcerns(
  template: RankedTemplate,
  placed: Placed[],
  content: { items: CatalogItem[]; categories: Category[] },
): Set<string> {
  const items = new Map(content.items.map((i) => [i.id, i.implies]));
  const categories = new Map(content.categories.map((c) => [c.id, c.implies]));
  return new Set(
    placed
      .filter((p) => template.impliedBy.includes(p.templateId))
      .flatMap((p) => [...(items.get(p.itemId) ?? []), ...(categories.get(p.category) ?? [])]),
  );
}

// A concern's level, 0 for not a concern to 3: the SE's own pick, or else 1 while an answer implies it, or else nothing.
export const pickedLevel = (attrs: Entry["attrs"]) => (typeof attrs.level === "number" ? attrs.level : null);
export const concernLevel = (attrs: Entry["attrs"], implied: boolean) => pickedLevel(attrs) ?? (implied ? 1 : null);

// Tapping a level picks it; tapping the pick again clears it, back to what answers imply.
export function levelAttrs(attrs: Entry["attrs"], level: number): Entry["attrs"] {
  const { level: current, ...rest } = attrs;
  return current === level ? rest : { ...rest, level };
}

// The capabilities the SE attached a concern to, beyond those its catalog item routes it to.
export const attachedTo = (attrs: Entry["attrs"]) => (Array.isArray(attrs.routes) ? (attrs.routes as string[]) : []);

// Attaching a concern to a capability says the customer raised it, so one not yet at 1 or more is picked at 1.
export const attachAttrs = (attrs: Entry["attrs"], capability: string): Entry["attrs"] => ({
  ...attrs,
  level: Math.max(1, pickedLevel(attrs) ?? 0),
  routes: [...new Set([...attachedTo(attrs), capability])],
});

// The capabilities an op attaches a concern to or detaches one from. A detach that leaves a template concern with nothing
// recorded removes it, so a delete counts a concern that held nothing but its attachments; removing one that held more,
// such as a level, isn't a detach.
export const reattached = (op: Op): string[] =>
  op.type === "batch"
    ? op.ops.flatMap(reattached)
    : op.type === "put"
      ? op.entries.flatMap((e) => attachedTo(e.attrs))
      : op.type === "delete"
        ? op.entries.flatMap((e) => (!e.note && Object.keys(e.attrs).every((k) => k === "routes") ? attachedTo(e.attrs) : []))
        : op.type === "update"
          ? op.updates.flatMap((u) => {
              const [now, was] = [attachedTo(u.set.attrs ?? {}), attachedTo(u.prev.attrs ?? {})];
              return [...now, ...was].filter((id) => now.includes(id) !== was.includes(id));
            })
          : [];

export function detachAttrs(attrs: Entry["attrs"], capability: string): Entry["attrs"] {
  const { routes, ...rest } = attrs;
  const left = attachedTo({ routes }).filter((r) => r !== capability);
  return left.length ? { ...rest, routes: left } : rest;
}

// A concern in the customer's words attached to a capability joins the group most of the capability's catalog concerns
// are in, the earlier on a tie, else the first.
export function groupFor(capability: string, items: Pick<CatalogItem, "category" | "routes">[], groups: string[]) {
  const count = (group: string) => items.filter((i) => i.category === group && i.routes.includes(capability)).length;
  return groups.reduce((best, group) => (count(group) > count(best) ? group : best), groups[0]);
}

// The group a concern sits in: its item's category, or for one in the customer's words the group it was added under, and
// anything else the first.
export function concernGroup(
  groups: string[],
  itemId: string | null,
  attrs: Entry["attrs"],
  categoryOf: (itemId: string) => string | undefined,
) {
  const id = itemId ? categoryOf(itemId) : attrs.group;
  return groups.find((g) => g === id) ?? groups[0];
}

export type ConcernRow<E> = {
  key: string;
  itemId: string | null;
  entry: E | null;
  implied: boolean;
  // The SE's pick, and the level it shows: the pick, or else 1 while implied, or else nothing.
  picked: number | null;
  level: number | null;
};

// The template's concerns in its order, then those the SE added, each in its group.
export function concernGroups<E extends Pick<Entry, "id" | "itemId" | "text" | "attrs" | "note">>(
  slot: Slot,
  groups: Pick<Category, "id" | "name">[],
  entries: E[],
  categoryOf: (itemId: string) => string | undefined,
  implied: Set<string>,
) {
  const row = (itemId: string | null, entry: E | null): ConcernRow<E> => {
    const attrs = entry?.attrs ?? {};
    const isImplied = !!itemId && implied.has(itemId);
    return { key: entry?.id ?? itemId!, itemId, entry, implied: isImplied, picked: pickedLevel(attrs), level: concernLevel(attrs, isImplied) };
  };
  const rows = [
    ...slot.presets.map((id) => row(id, entries.find((e) => e.itemId === id) ?? null)),
    ...entries.filter((e) => !e.itemId || !slot.presets.includes(e.itemId)).map((e) => row(e.itemId, e)),
  ];
  const ids = groups.map((g) => g.id);
  const groupOf = (r: ConcernRow<E>) => concernGroup(ids, r.itemId, r.entry?.attrs ?? {}, categoryOf);
  return groups.map((g) => ({ id: g.id, name: g.name, rows: rows.filter((r) => groupOf(r) === g.id) }));
}
