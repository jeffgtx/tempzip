import { and, eq, inArray, isNull, notInArray, or, sql } from "drizzle-orm";
import { getContent } from "@/content/load";
import type { BoardTemplate, Verdict } from "@/content/schema";
import { db } from "@/db";
import { boards, catalogItems, entries } from "@/db/schema";
import { pendingReturnVisits, runningMeeting } from "@/meetings/data";
import { concernGroups, impliedConcerns } from "./concerns";
import { boardData, placedOn, templateById, zoomSource } from "./data";
import { flowPath, flowsAt } from "./flows";
import { type LitCapability, type LitGroupView, capabilityProducts, litGroupView, litMap } from "./lit-map";
import { type BoardData, type Entry, type Mark, entriesIn, gridEntryFacts, gridRows, live, markOf } from "./model";
import { type SummaryView, pickedIds, summaryView } from "./summary";
import { type AppView, type ZoomView, appView, zoomView } from "./zooms";

export type ViewEntry = {
  id: string;
  label: string;
  mark: Mark | null;
  count: number | null;
  // The levels of its coverage mode and of a planned one that differs.
  coverage: string | null;
  goal: string | null;
  // A planned mode that keeps the current level, then the names its other picks hold, such as a data store's sensitivity.
  detail: string[];
  focused: boolean;
};
export type ViewSlot = { id: string; name: string; verdict: Verdict | null; focused: boolean; entries: ViewEntry[] };
// A concern's level, 0 for not a concern to 3, or null for nothing said.
export type Concern = { id: string; label: string; level: number | null; focused: boolean };
export type Step = { id: string; label: string; owner: string | null; due: string | null; minutes: number | null; focused: boolean };
// Whether the SE forced a level stays in the cockpit.
export type LitView = {
  id: string;
  name: string;
  summary: string | null;
  focused: boolean;
  capabilities: (Pick<LitCapability, "id" | "name" | "summary" | "level"> & { focused: boolean })[];
};

// What the room shows of a board: live entries only, never notes, ghosts or dismissals.
export type BoardView =
  | { layout: "grid"; name: string; columns: string[] | null; strip: ViewSlot | null; rows: ViewSlot[][] }
  | { layout: "ranked-list"; name: string; concerns: Concern[] }
  | { layout: "lit-map"; name: string; groups: LitView[] }
  | LitGroupView
  | { layout: "list"; name: string; steps: Step[] }
  | SummaryView
  | ZoomView
  | AppView;

// The pane of a layout that has them, and what the SE has selected in the cockpit, as `slot:<id>`, `entry:<id>` or
// `item:<id>`; on the summary, the flow picked. A summary's pane 1 is its "+N more".
export type ViewOptions = { pane: number; focus?: string | null };
export const FOCUS = /^(slot|entry|item):[A-Za-z0-9-]{1,100}$/;

// The names and categories of the catalog items a board's entries are and pick, and of any others it names.
async function catalogOf(template: BoardTemplate, data: BoardData, others: string[] = []) {
  const ids = [...new Set([...pickedIds(template, data), ...others])];
  const rows = ids.length
    ? await db
        .select({ id: catalogItems.id, name: catalogItems.name, category: catalogItems.category })
        .from(catalogItems)
        .where(inArray(catalogItems.id, ids))
    : [];
  const catalog = new Map(rows.map((r) => [r.id, r]));
  return (id: string) => catalog.get(id);
}

export const deviceClasses = () =>
  getContent()
    .items.filter((i) => i.category === "device-class")
    .map(({ id, name }) => ({ id, name }));

// The capability groups a lit map shows, and the catalog it lights them from.
export function litContent(template: BoardTemplate) {
  const { items } = getContent();
  const groupIds = template.slots[0].presets;
  const capabilities = items.filter((i) => i.group && groupIds.includes(i.group));
  const products = new Set(capabilities.flatMap((c) => c.deliveredBy));
  return {
    groups: groupIds.map((id) => items.find((i) => i.id === id)!),
    items: items.filter((i) => capabilities.includes(i) || products.has(i.id) || i.routes.length),
  };
}

// The boards still waiting for the running meeting's return-visit choice.
async function unsettled(ownerId: string, customerId: string): Promise<string[]> {
  const meeting = await runningMeeting(ownerId, customerId);
  return meeting ? pendingReturnVisits(ownerId, customerId, meeting) : [];
}

// The concerns that route to capabilities, through their catalog item or the SE's attachment, wherever the customer's
// boards hold them, except on boards still unsettled and the board excepted.
export async function concernEntries(ownerId: string, customerId: string, options: { except?: string } = {}) {
  const routed = getContent()
    .items.filter((i) => i.routes.length)
    .map((i) => i.id);
  const pending = await unsettled(ownerId, customerId);
  const rows = await db
    .select({ id: entries.id, itemId: entries.itemId, text: entries.text, attrs: entries.attrs })
    .from(entries)
    .where(
      and(
        eq(entries.ownerId, ownerId),
        eq(entries.customerId, customerId),
        eq(entries.status, "live"),
        or(inArray(entries.itemId, routed), sql`${entries.attrs} ? 'routes'`),
        notInArray(entries.boardId, options.except ? [...pending, options.except] : pending),
      ),
    )
    .orderBy(entries.position);
  return rows as Pick<Entry, "id" | "itemId" | "text" | "attrs">[];
}

// The ranked list whose concerns light a lit map: its cluster's.
export const concernsTemplate = (template: BoardTemplate) =>
  getContent().templates.find(
    (t): t is Extract<BoardTemplate, { layout: "ranked-list" }> => t.layout === "ranked-list" && t.cluster === template.cluster,
  );

// The concerns implied by the answers on a ranked list's impliedBy boards, except on boards still unsettled. While the
// ranked list itself awaits its return-visit choice, its concerns imply nothing, as its own levels count for nothing.
export async function impliedFor(ownerId: string, customerId: string, template: Extract<BoardTemplate, { layout: "ranked-list" }>) {
  if (!template.impliedBy.length) return new Set<string>();
  const [placed, pending, [own]] = await Promise.all([
    placedOn(ownerId, customerId, { templates: template.impliedBy }),
    unsettled(ownerId, customerId),
    db
      .select({ id: boards.id })
      .from(boards)
      .where(and(eq(boards.ownerId, ownerId), eq(boards.customerId, customerId), eq(boards.templateId, template.id), isNull(boards.entryId))),
  ]);
  if (own && pending.includes(own.id)) return new Set<string>();
  return impliedConcerns(template, placed.filter((p) => !pending.includes(p.boardId)), getContent());
}

// Where a view reads the customer's boards: the database as it stands, or a meeting's boards rebuilt as they stood at its
// End.
export type ViewSource = {
  data(boardId: string): Promise<BoardData>;
  zoomSource(zoom: BoardTemplate, entryId: string): Promise<{ boardId: string; template: BoardTemplate; name: string | null } | null>;
  implied(template: Extract<BoardTemplate, { layout: "ranked-list" }>): Promise<Set<string>>;
  concerns(): Promise<Pick<Entry, "id" | "itemId" | "text" | "attrs">[]>;
  diagramName(boardId: string): Promise<string | null>;
};

const database = (ownerId: string, customerId: string): ViewSource => ({
  data: (boardId) => boardData(ownerId, boardId),
  zoomSource: (zoom, entryId) => zoomSource(ownerId, customerId, zoom, entryId),
  implied: (template) => impliedFor(ownerId, customerId, template),
  concerns: () => concernEntries(ownerId, customerId),
  diagramName: async (boardId) => (await db.select({ name: boards.name }).from(boards).where(eq(boards.id, boardId)))[0]?.name ?? null,
});

export const boardView = (
  ownerId: string,
  customerId: string,
  template: BoardTemplate,
  boardId: string | null,
  options: ViewOptions,
  entryId: string | null = null,
) => sourcedView(database(ownerId, customerId), template, boardId, options, entryId);

export async function sourcedView(
  source: ViewSource,
  template: BoardTemplate,
  boardId: string | null,
  options: ViewOptions,
  entryId: string | null = null,
): Promise<BoardView | null> {
  if (template.layout === "zoom") {
    const found = entryId && (await source.zoomSource(template, entryId));
    if (!found) return null;
    const data = live(await source.data(found.boardId));
    const catalog = await catalogOf(found.template, data);
    return template.shows === "app"
      ? appView(found.template, data, entryId, catalog, capabilityProducts(getContent().items))
      : zoomView(found.template, data, template.shows, entryId, found.name ?? "", catalog, deviceClasses());
  }
  const data = live(boardId ? await source.data(boardId) : { entries: [] });
  const slot = template.slots[0];
  const catalog = await catalogOf(template, data, slot.presets);
  const name = (id: string) => catalog(id)?.name ?? id;
  // An entry's own name attribute, such as "Prod OU", names it before its catalog item does.
  const label = (e: Entry) => (typeof e.attrs.name === "string" && e.attrs.name) || (e.itemId ? name(e.itemId) : e.text!);
  const focused = (kind: "slot" | "entry" | "item", id: string) => options.focus === `${kind}:${id}`;

  switch (template.layout) {
    case "grid": {
      const view = (id: string): ViewSlot => {
        const def = template.slots.find((s) => s.id === id)!;
        return {
          id,
          name: def.name,
          verdict: def.verdict ?? null,
          focused: focused("slot", id),
          entries: entriesIn(data, id).map((e) => ({
            id: e.id,
            label: label(e),
            mark: markOf(e.attrs),
            count: typeof e.attrs.count === "number" ? e.attrs.count : null,
            ...gridEntryFacts(template, id, e.attrs, catalog),
            focused: focused("entry", e.id),
          })),
        };
      };
      return {
        layout: "grid",
        name: (template.groups?.[options.pane] ?? template.groups?.[0])?.name ?? template.name,
        columns: template.columns ?? null,
        strip: template.strip ? view(template.strip) : null,
        rows: gridRows(template, options.pane).map((row) => row.map(view)),
      };
    }
    case "ranked-list": {
      const { categories } = getContent();
      const groups = concernGroups(
        slot,
        slot.categories.map((id) => categories.find((c) => c.id === id)!),
        entriesIn(data, slot.id),
        (id) => catalog(id)?.category,
        await source.implied(template),
      );
      const group = groups[options.pane] ?? groups[0];
      return {
        layout: "ranked-list",
        name: group.name,
        concerns: group.rows.map((r) => ({
          id: r.key,
          label: r.itemId ? name(r.itemId) : r.entry!.text!,
          level: r.level,
          focused: (!!r.entry && focused("entry", r.entry.id)) || (!!r.itemId && focused("item", r.itemId)),
        })),
      };
    }
    case "lit-map": {
      const ranked = concernsTemplate(template);
      const [concerns, implied] = await Promise.all([source.concerns(), ranked ? source.implied(ranked) : new Set<string>()]);
      const groups = litMap({ ...litContent(template), concerns, implied, overrides: entriesIn(data, slot.id) });
      const zoomed = groups[options.pane - 1];
      if (zoomed && !zoomed.hidden) return litGroupView(zoomed, (id) => focused("item", id));
      return {
        layout: "lit-map",
        name: template.name,
        groups: groups
          .filter((g) => !g.hidden)
          .map(({ id, name, summary, capabilities }) => ({
            id,
            name,
            summary,
            focused: focused("item", id),
            capabilities: capabilities.map(({ id, name, summary, level }) => ({
              id,
              name,
              summary,
              level,
              focused: focused("item", id),
            })),
          })),
      };
    }
    case "list":
      return {
        layout: "list",
        name: template.name,
        steps: entriesIn(data, slot.id).map((e) => ({
          id: e.id,
          label: label(e),
          owner: (e.attrs.owner as string | undefined) ?? null,
          due: (e.attrs.due as string | undefined) ?? null,
          minutes: (e.attrs.minutes as number | undefined) ?? null,
          focused: focused("entry", e.id),
        })),
      };
    case "hub-and-spoke": {
      const diagram = (boardId && (await source.diagramName(boardId))) || "";
      if (options.pane === 1 && template.more) return zoomView(template, data, "folded", null, diagram, catalog, deviceClasses());
      const view = summaryView(template, data, diagram, catalog);
      const flow = flowsAt(template, data).find((f) => focused("entry", f.id));
      return flow ? { ...view, flow: flowPath(view, flow) } : view;
    }
    default:
      return null;
  }
}

// A board the customer has never opened has no row yet, and shows as empty. A zoom shows the board it zooms from, so
// needs no row of its own.
export async function customerBoardView(
  ownerId: string,
  customerId: string,
  templateId: string,
  options: ViewOptions,
  pick: { entryId?: string; diagramId?: string } = {},
) {
  const template = templateById(templateId);
  if (!template) return null;
  if (template.layout === "zoom") return boardView(ownerId, customerId, template, null, options, pick.entryId ?? null);
  const [board] = await db
    .select({ id: boards.id })
    .from(boards)
    .where(
      and(
        eq(boards.ownerId, ownerId),
        eq(boards.customerId, customerId),
        eq(boards.templateId, templateId),
        isNull(boards.entryId),
        pick.diagramId ? eq(boards.id, pick.diagramId) : template.layout === "hub-and-spoke" ? undefined : isNull(boards.name),
      ),
    )
    // Without one picked, a summary shows its first diagram.
    .orderBy(boards.position)
    .limit(1);
  if (pick.diagramId && !board) return null;
  return boardView(ownerId, customerId, template, board?.id ?? null, options);
}
