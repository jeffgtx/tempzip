import { and, eq, inArray, or } from "drizzle-orm";
import { getContent } from "@/content/load";
import type { BoardTemplate } from "@/content/schema";
import { db } from "@/db";
import { catalogItems, vendors } from "@/db/schema";
import type { CatalogOption } from "./match";

// Live items for the template's slots and fields, by category, and the items its records offer, for chips, type-ahead and picks.
export async function catalogFor(template: BoardTemplate) {
  // The summary's flows are free text and pick only connection types, so they don't open the whole catalog.
  const everything = template.slots.some((s) => !s.categories.length && (template.layout !== "hub-and-spoke" || s.id !== template.flows));
  const picked = template.slots.flatMap((s) =>
    s.attributes.flatMap((a) => (a.type === "records" ? a.fields : [a])).flatMap((a) => (a.type === "pick" ? a.categories : [])),
  );
  const categories = [...new Set([...template.slots.flatMap((s) => s.categories), ...picked])];
  const offered = template.slots.flatMap((s) => s.attributes.flatMap((a) => (a.type === "records" ? a.presets : [])));
  const rows = await db
    .select({
      id: catalogItems.id,
      name: catalogItems.name,
      aliases: catalogItems.aliases,
      category: catalogItems.category,
      vendorName: vendors.name,
      vendorAliases: vendors.aliases,
    })
    .from(catalogItems)
    .leftJoin(vendors, eq(vendors.id, catalogItems.vendorId))
    .where(
      and(
        eq(catalogItems.retired, false),
        everything ? undefined : or(inArray(catalogItems.category, categories), inArray(catalogItems.id, offered)),
      ),
    );
  // A ranked list's items are its concerns, grouped by category.
  const groups = template.layout === "ranked-list" ? new Map(getContent().categories.map((c) => [c.id, c.name])) : undefined;
  return rows.map(
    (r): CatalogOption & { category: string } => ({
      id: r.id,
      name: r.name,
      aliases: r.aliases,
      category: r.category,
      vendor: r.vendorName ? { name: r.vendorName, aliases: r.vendorAliases ?? [] } : null,
      ...(groups && { group: groups.get(r.category) }),
    }),
  );
}

// Names for items entries refer to, retired ones included.
export async function itemNames(ids: string[]) {
  if (!ids.length) return {};
  const rows = await db
    .select({ id: catalogItems.id, name: catalogItems.name })
    .from(catalogItems)
    .where(inArray(catalogItems.id, ids));
  return Object.fromEntries(rows.map((r) => [r.id, r.name]));
}
