import { and, asc, eq, isNotNull, or, sql } from "drizzle-orm";
import { z } from "zod";
import { boardData, commitIn, templateById } from "@/board/data";
import { approveOp, boardCategories } from "@/board/model";
import { getContent } from "@/content/load";
import { db } from "@/db";
import { boards, catalogItems, entries, suggestions } from "@/db/schema";
import { type Tx, transaction } from "@/db/transaction";
import { runningMeeting } from "@/meetings/data";

export const proposal = z.object({
  name: z.string().trim().min(1).max(200),
  aliases: z
    .array(z.string())
    .transform((aliases) => [...new Set(aliases.map((a) => a.trim()).filter(Boolean))])
    .pipe(z.array(z.string().max(100)).max(20)),
});
export type Proposal = z.infer<typeof proposal>;

// A suggestion can't name the capabilities a concern routes to.
const isConcern = (category: string) =>
  getContent().templates.some((t) => t.layout === "ranked-list" && t.slots.some((slot) => slot.categories.includes(category)));

// True once the entry has a suggestion waiting, whether this one or an earlier one.
export async function raiseSuggestion(
  ownerId: string,
  customerId: string,
  s: Proposal & { entryId: string; category: string },
) {
  const [entry] = await db
    .select({ text: entries.text, slot: entries.slot, templateId: boards.templateId })
    .from(entries)
    .innerJoin(boards, eq(boards.id, entries.boardId))
    .where(and(eq(entries.id, s.entryId), eq(entries.ownerId, ownerId), eq(entries.customerId, customerId)));
  const template = entry && templateById(entry.templateId);
  const slot = template?.slots.find((x) => x.id === entry?.slot);
  const accepted = slot?.categories.length ? slot.categories : template ? boardCategories(template) : [];
  const flow = template?.layout === "hub-and-spoke" && slot?.id === template.flows;
  if (!entry?.text || !slot || flow || !accepted.includes(s.category) || isConcern(s.category)) return false;
  await db
    .insert(suggestions)
    .values({ ...s, ownerId, customerId })
    .onConflictDoNothing({ target: suggestions.entryId, where: sql`${suggestions.status} = 'pending'` });
  return true;
}

export async function suggestedEntries(ownerId: string, customerId: string) {
  const rows = await db
    .select({ entryId: suggestions.entryId })
    .from(suggestions)
    .where(
      and(
        eq(suggestions.ownerId, ownerId),
        eq(suggestions.customerId, customerId),
        eq(suggestions.status, "pending"),
        isNotNull(suggestions.entryId),
      ),
    );
  return rows.map((r) => r.entryId!);
}

// The admin sees the proposed item only, never the customer.
export const pendingSuggestions = () =>
  db
    .select({ id: suggestions.id, name: suggestions.name, category: suggestions.category, aliases: suggestions.aliases })
    .from(suggestions)
    .where(eq(suggestions.status, "pending"))
    .orderBy(asc(suggestions.createdAt));

class Refused extends Error {}

// Approving reuses a live item of the same category already going by that name.
// The entry's change is a commit for the SE, with the suggestion's id, so the room
// and later notes follow it, and it joins the customer's running meeting so undo and
// redo take it in turn. Returns why nothing was approved, if it wasn't.
export async function approveSuggestion(id: string, edit: Proposal): Promise<string | null> {
  try {
    await transaction(async (tx) => {
      const [s] = await tx
        .select()
        .from(suggestions)
        .where(and(eq(suggestions.id, id), eq(suggestions.status, "pending")))
        .for("update");
      if (!s) return;
      if (isConcern(s.category)) throw new Refused("A concern needs the capabilities it routes to, which a suggestion can't name.");
      const itemId = (await sameItem(tx, s.category, edit.name)) ?? (await addItem(tx, s.category, edit));
      const [entry] = s.entryId
        ? await tx
            .select({ boardId: entries.boardId, text: entries.text, slot: entries.slot, templateId: boards.templateId })
            .from(entries)
            .innerJoin(boards, eq(boards.id, entries.boardId))
            .where(and(eq(entries.id, s.entryId), eq(entries.ownerId, s.ownerId)))
        : [];
      if (entry?.text) {
        const meeting = await runningMeeting(s.ownerId, s.customerId);
        const template = templateById(entry.templateId);
        // A summary node's fields and the lines other nodes draw to it would be lost in a merge.
        const merge = template?.layout !== "hub-and-spoke" && !template?.slots.find((x) => x.id === entry.slot)?.repeats;
        const result = await commitIn(
          tx,
          s.ownerId,
          s.customerId,
          {
            id: s.id,
            boardId: entry.boardId,
            op: approveOp(await boardData(s.ownerId, entry.boardId), s.entryId!, itemId, merge),
            reverts: null,
            meetingId: meeting?.id ?? null,
          },
          { bySe: false },
        );
        if ("rejected" in result) throw new Refused(`The entry no longer fits its board (${result.rejected}).`);
      }
      await tx
        .update(suggestions)
        .set({ ...edit, status: "approved", itemId, decidedAt: sql`now()` })
        .where(eq(suggestions.id, id));
    });
    return null;
  } catch (error) {
    if (error instanceof Refused) return error.message;
    throw error;
  }
}

export async function rejectSuggestion(id: string) {
  await db
    .update(suggestions)
    .set({ status: "rejected", decidedAt: sql`now()` })
    .where(and(eq(suggestions.id, id), eq(suggestions.status, "pending")));
}

async function sameItem(tx: Tx, category: string, name: string) {
  const lower = name.toLowerCase();
  const [item] = await tx
    .select({ id: catalogItems.id })
    .from(catalogItems)
    .where(
      and(
        eq(catalogItems.category, category),
        eq(catalogItems.retired, false),
        or(
          sql`lower(${catalogItems.name}) = ${lower}`,
          sql`${lower} = any(select lower(a) from unnest(${catalogItems.aliases}) a)`,
        ),
      ),
    );
  return item?.id;
}

// Approved ids read like git ones, so the admin can later move an item into the content files.
async function addItem(tx: Tx, category: string, { name, aliases }: Proposal) {
  const slug =
    name
      .normalize("NFKD")
      .replace(/\p{M}/gu, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .slice(0, 48)
      .replace(/^-|-$/g, "") || "item";
  for (let n = 1; ; n++) {
    const [added] = await tx
      .insert(catalogItems)
      .values({ id: n === 1 ? `a-${slug}` : `a-${slug}-${n}`, name, aliases, category, source: "approved" })
      .onConflictDoNothing()
      .returning({ id: catalogItems.id });
    if (added) return added.id;
  }
}
