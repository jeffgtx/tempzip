export type CatalogOption = {
  id: string;
  name: string;
  aliases: string[];
  vendor: { name: string; aliases: string[] } | null;
  group?: string;
};

// Names and aliases of items and of their vendors, case-insensitive; closer matches first.
export function matchCatalog(options: CatalogOption[], query: string, limit = 8) {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const rank = (o: CatalogOption) => {
    const own = [o.name, ...o.aliases].map((s) => s.toLowerCase());
    const vendor = o.vendor ? [o.vendor.name, ...o.vendor.aliases].map((s) => s.toLowerCase()) : [];
    if (own.includes(q)) return 0;
    if (own.some((s) => s.startsWith(q))) return 1;
    if (own.some((s) => s.includes(q))) return 2;
    if (vendor.some((s) => s.startsWith(q))) return 3;
    if (vendor.some((s) => s.includes(q))) return 4;
    return null;
  };
  return options
    .map((o) => ({ o, r: rank(o) }))
    .filter((x): x is { o: CatalogOption; r: number } => x.r !== null)
    .sort((a, b) => a.r - b.r || a.o.name.localeCompare(b.o.name))
    .slice(0, limit)
    .map((x) => x.o);
}
