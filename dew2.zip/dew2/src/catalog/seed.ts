import { and, eq, notInArray, sql } from "drizzle-orm";
import type { Content } from "@/content/load";
import { catalogItems, vendors } from "@/db/schema";
import type { Tx } from "@/db/transaction";

// Upserts git content by id. Git items missing from content are retired rather
// than deleted, since entries may still reference them; approved items are left alone.
export async function seedCatalog(tx: Tx, content: Pick<Content, "vendors" | "items">) {
  const vendorIds = content.vendors.map((v) => v.id);
  const itemIds = content.items.map((i) => i.id);
  if (content.vendors.length)
    await tx
      .insert(vendors)
      .values(content.vendors.map((v) => ({ id: v.id, name: v.name, aliases: v.aliases })))
      .onConflictDoUpdate({
        target: vendors.id,
        set: { name: sql`excluded.name`, aliases: sql`excluded.aliases`, retired: false },
      });
  await tx.update(vendors).set({ retired: true }).where(notInArray(vendors.id, vendorIds));
  if (content.items.length)
    await tx
      .insert(catalogItems)
      .values(
        content.items.map((i) => ({
          id: i.id,
          name: i.name,
          aliases: i.aliases,
          category: i.category,
          vendorId: i.vendor ?? null,
          useCases: i.useCases,
          source: "git" as const,
        })),
      )
      .onConflictDoUpdate({
        target: catalogItems.id,
        set: {
          name: sql`excluded.name`,
          aliases: sql`excluded.aliases`,
          category: sql`excluded.category`,
          vendorId: sql`excluded.vendor_id`,
          useCases: sql`excluded.use_cases`,
          source: "git",
          retired: false,
        },
      });
  await tx
    .update(catalogItems)
    .set({ retired: true })
    .where(and(eq(catalogItems.source, "git"), notInArray(catalogItems.id, itemIds)));
}
