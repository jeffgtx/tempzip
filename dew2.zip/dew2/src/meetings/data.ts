import { randomInt } from "node:crypto";
import { type SQL, and, eq, isNotNull, isNull, ne, notInArray, sql } from "drizzle-orm";
import type { PgColumn } from "drizzle-orm/pg-core";
import { templateById, zoomSource } from "@/board/data";
import { markActive } from "@/customers/data";
import { db } from "@/db";
import { boards, customers, entries, meetings } from "@/db/schema";

const meetingColumns = {
  id: meetings.id,
  code: meetings.code,
  startedAt: meetings.startedAt,
  boardId: meetings.boardId,
  pane: meetings.pane,
  held: meetings.held,
  visited: meetings.visited,
};

const running = (ownerId: string, customerId: string) =>
  and(eq(meetings.ownerId, ownerId), eq(meetings.customerId, customerId), isNull(meetings.endedAt));

export async function runningMeeting(ownerId: string, customerId: string) {
  const [row] = await db.select(meetingColumns).from(meetings).where(running(ownerId, customerId));
  return row ?? null;
}

export type Meeting = NonNullable<Awaited<ReturnType<typeof runningMeeting>>>;

// Codes are unique among running meetings; a clash just draws another.
export async function startMeeting(ownerId: string, customerId: string): Promise<Meeting> {
  for (let attempt = 0; ; attempt++) {
    const code = String(randomInt(1_000_000)).padStart(6, "0");
    const [row] = await db
      .insert(meetings)
      .values({ ownerId, customerId, code })
      .onConflictDoNothing()
      .returning(meetingColumns);
    if (row) {
      await markActive(ownerId, customerId);
      return row;
    }
    const existing = await runningMeeting(ownerId, customerId);
    if (existing) return existing;
    if (attempt === 5) throw new Error("No free meeting code");
  }
}

export async function endMeeting(ownerId: string, customerId: string) {
  const [ended] = await db
    .update(meetings)
    .set({
      endedAt: sql`now()`,
      code: null,
      endSeq: sql`(select ${customers.seq} from ${customers} where ${customers.id} = ${meetings.customerId})`,
    })
    .where(running(ownerId, customerId))
    .returning({ id: meetings.id });
  if (!ended) return null;
  await markActive(ownerId, customerId);
  return ended.id;
}

// The array with each value appended that it doesn't hold yet.
const including = (array: PgColumn, values: string[], type: "uuid" | "text") =>
  values.reduce<SQL | PgColumn>(
    (list, value) => sql`case when ${value}::${sql.raw(type)} = any(${list}) then ${list}
        else array_append(${list}, ${value}::${sql.raw(type)}) end`,
    array,
  );

// How the room's showing a diagram's "+N more" is recorded among the lit map's groups.
export const moreZoom = (boardId: string) => `more:${boardId}`;

// Opening a board settles its return-visit question for the rest of the meeting, and
// opening a zoom that of the board it zooms from, during Hold too. The notes and pack
// cover only what the room showed: during Hold it shows nothing, and releasing Hold
// resends the view. A board that isn't the customer's, or a zoom board deleted with
// its entry, shows nothing.
export async function setView(
  ownerId: string,
  customerId: string,
  view: { boardId: string | null; pane: number; focus: string | null; held: boolean },
) {
  const opened: string[] = [];
  const groups: string[] = [];
  if (view.boardId) {
    const [board] = await db
      .select({ id: boards.id, templateId: boards.templateId, entryId: boards.entryId })
      .from(boards)
      .where(and(eq(boards.id, view.boardId), eq(boards.customerId, customerId), eq(boards.ownerId, ownerId)));
    const template = board && templateById(board.templateId);
    const source = template?.layout === "zoom" && board.entryId ? await zoomSource(ownerId, customerId, template, board.entryId) : null;
    if (board) opened.push(board.id, ...(source ? [source.boardId] : []));
    // A lit map's panes after the map are its groups' zooms, and a summary's pane 1 is its "+N more".
    const group =
      template?.layout === "lit-map"
        ? template.slots[0].presets[view.pane - 1]
        : template?.layout === "hub-and-spoke" && template.more && view.pane === 1
          ? moreZoom(board.id)
          : undefined;
    if (group) groups.push(group);
  }
  const updated = await db
    .update(meetings)
    .set({
      ...view,
      boardId: opened[0] ?? null,
      visited: including(meetings.visited, opened, "uuid"),
      ...(view.held
        ? {}
        : { shown: including(meetings.shown, opened, "uuid"), shownGroups: including(meetings.shownGroups, groups, "text") }),
    })
    .where(running(ownerId, customerId))
    .returning({ id: meetings.id });
  return updated.length > 0;
}

// Boards holding live entries from an earlier meeting that this meeting hasn't
// shown yet. Entries prepared outside any meeting don't count.
export async function pendingReturnVisits(ownerId: string, customerId: string, meeting: Pick<Meeting, "id" | "visited">) {
  const rows = await db
    .selectDistinct({ boardId: entries.boardId })
    .from(entries)
    .where(
      and(
        eq(entries.ownerId, ownerId),
        eq(entries.customerId, customerId),
        eq(entries.status, "live"),
        isNotNull(entries.meetingId),
        ne(entries.meetingId, meeting.id),
        notInArray(entries.boardId, meeting.visited),
      ),
    );
  return rows.map((r) => r.boardId);
}

export async function meetingForCode(code: string) {
  const [row] = /^\d{6}$/.test(code)
    ? await db
        .select({ id: meetings.id, customerId: meetings.customerId })
        .from(meetings)
        .where(and(eq(meetings.code, code), isNull(meetings.endedAt)))
    : [];
  return row ?? null;
}
