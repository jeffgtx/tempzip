import { createHash } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { templateById } from "@/board/data";
import { type BoardView, boardView } from "@/board/view";
import { db } from "@/db";
import { boards, customers, meetings } from "@/db/schema";

export type RoomSnapshot = {
  version: string;
  customer: { accent: string | null; logoUrl: string | null };
  board: BoardView | null;
};

async function meetingView(meetingId: string) {
  const [row] = await db
    .select({
      seq: customers.seq,
      ownerId: meetings.ownerId,
      customerId: meetings.customerId,
      boardId: meetings.boardId,
      name: boards.name,
      pane: meetings.pane,
      focus: meetings.focus,
      held: meetings.held,
      endedAt: meetings.endedAt,
      accent: customers.accent,
      // A logo is a data URL of up to 700 KB, so the version takes its digest and only the snapshot reads it.
      logo: sql<string | null>`md5(${customers.logoUrl})`,
    })
    .from(meetings)
    .innerJoin(customers, eq(customers.id, meetings.customerId))
    .leftJoin(boards, eq(boards.id, meetings.boardId))
    .where(eq(meetings.id, meetingId));
  return row && !row.endedAt ? row : null;
}

// Hashed, since it travels as an SSE event id and must stay on one line.
const versionOf = (v: NonNullable<Awaited<ReturnType<typeof meetingView>>>) =>
  createHash("sha256")
    .update(JSON.stringify([v.seq, v.boardId, v.name, v.pane, v.focus, v.held, v.accent, v.logo]))
    .digest("base64url");

// Null once the meeting has ended.
export async function roomVersion(meetingId: string) {
  const view = await meetingView(meetingId);
  return view && versionOf(view);
}

export async function roomSnapshot(meetingId: string): Promise<RoomSnapshot | null> {
  const view = await meetingView(meetingId);
  if (!view) return null;
  const [{ logoUrl }] = await db.select({ logoUrl: customers.logoUrl }).from(customers).where(eq(customers.id, view.customerId));
  const snapshot = { version: versionOf(view), customer: { accent: view.accent, logoUrl }, board: null };
  if (view.held || !view.boardId) return snapshot;
  const [board] = await db
    .select({ templateId: boards.templateId, entryId: boards.entryId })
    .from(boards)
    .where(and(eq(boards.id, view.boardId), eq(boards.ownerId, view.ownerId)));
  const template = board && templateById(board.templateId);
  if (!template) return snapshot;
  const options = { pane: view.pane, focus: view.focus };
  return { ...snapshot, board: await boardView(view.ownerId, view.customerId, template, view.boardId, options, board.entryId) };
}
