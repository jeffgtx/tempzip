import { AsyncLocalStorage } from "node:async_hooks";
import fs from "node:fs";
import os from "node:os";
import { PGlite, type Transaction } from "@electric-sql/pglite";
import { drizzle } from "drizzle-orm/pglite";
import { migrate } from "drizzle-orm/pglite/migrator";
import { seedCatalog } from "@/catalog/seed";
import { loadContent } from "@/content/load";
import * as schema from "./schema";

// Two processes on one data directory corrupt it, so the second one to try refuses, naming the first.
const LOCK = ".pglite.lock";

const running = (pid: number) => {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return (error as NodeJS.ErrnoException).code === "EPERM";
  }
};

function lock() {
  try {
    fs.writeFileSync(LOCK, String(process.pid), { flag: "wx" });
  } catch {
    const holder = Number(fs.readFileSync(LOCK, "utf8"));
    // A lock naming no process, or written before the Mac last started, was left by a crash; its pid may since be another's.
    const leftover = !(holder > 0) || fs.statSync(LOCK).mtimeMs < Date.now() - os.uptime() * 1000;
    if (!leftover && holder !== process.pid && running(holder))
      throw new Error(
        `Another copy of dew2 (process ${holder}) has the database open. Run one copy at a time, or if none is running, delete .pglite.lock.`,
      );
    fs.writeFileSync(LOCK, String(process.pid));
  }
  process.on("exit", () => fs.rmSync(LOCK, { force: true }));
  // Closing the Terminal window sends SIGHUP, which Next leaves to the default of dying without running exit handlers.
  process.once("SIGHUP", () => process.exit(129));
}

async function open() {
  lock();
  const pglite = new PGlite(".pglite");
  const db = drizzle({ client: pglite, schema, casing: "snake_case" });
  await migrate(db, { migrationsFolder: "drizzle" });
  await db.transaction((tx) => seedCatalog(tx, loadContent()));
  return pglite;
}

// Opened on the first query, not on import: Next dev also imports route modules in worker processes. One per process,
// though Next can load this module more than once in it.
const shared = globalThis as { pglite?: Promise<PGlite>; within?: AsyncLocalStorage<Transaction> };
const ready = () => (shared.pglite ??= open());

// PGlite runs one transaction at a time, so a query made through `db` while a transaction is open would wait on that
// transaction forever. It joins the transaction instead.
const within = (shared.within ??= new AsyncLocalStorage<Transaction>());
const current = () => {
  const tx = within.getStore();
  return tx && !tx.closed ? tx : null;
};
const client = {
  query: async (...args: Parameters<PGlite["query"]>) => (current() ?? (await ready())).query(...args),
  transaction: async <T>(work: (tx: Transaction) => Promise<T>) => {
    const tx = current();
    return tx ? work(tx) : (await ready()).transaction((tx) => within.run(tx, () => work(tx)));
  },
} as PGlite;

export const db = drizzle({ client, schema, casing: "snake_case" });

export type Db = typeof db;
