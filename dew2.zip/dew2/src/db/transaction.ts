import { type Db, db } from "@/db";

export type Tx = Parameters<Parameters<Db["transaction"]>[0]>[0];

export const transaction = <T>(work: (tx: Tx) => Promise<T>) => db.transaction(work);
