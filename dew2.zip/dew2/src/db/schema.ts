import {
  type AnyPgColumn,
  bigint,
  boolean,
  check,
  doublePrecision,
  foreignKey,
  index,
  type PgTableExtraConfigValue,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  unique,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { and, isNotNull, isNull, sql } from "drizzle-orm";

const createdAt = () => timestamp({ withTimezone: true }).notNull().defaultNow();

export const users = pgTable("users", {
  id: uuid().primaryKey().defaultRandom(),
  phone: text().notNull().unique(),
  invitedAt: createdAt(),
  removedAt: timestamp({ withTimezone: true }),
});

export const sessions = pgTable("sessions", {
  tokenHash: text().primaryKey(),
  userId: uuid()
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp({ withTimezone: true }).notNull(),
});

// Rows holding customer data carry ownerId, and every foreign key between them
// includes it, so no row can point at another owner's data. drizzle-kit can't
// express ON DELETE SET NULL for one column of such a key, so the migration
// spells it out by hand; keep that when regenerating these keys.

export const customers = pgTable(
  "customers",
  {
    id: uuid().primaryKey().defaultRandom(),
    ownerId: uuid()
      .notNull()
      .references(() => users.id),
    name: text().notNull(),
    accent: text(),
    logoUrl: text(),
    clusters: text().array().notNull(),
    seq: bigint({ mode: "number" }).notNull().default(0),
    createdAt: createdAt(),
    lastActiveAt: createdAt(),
  },
  (t) => [unique().on(t.id, t.ownerId), index().on(t.ownerId, t.lastActiveAt)],
);

const ownedByCustomer = (t: { customerId: AnyPgColumn; ownerId: AnyPgColumn }) =>
  foreignKey({
    columns: [t.customerId, t.ownerId],
    foreignColumns: [customers.id, customers.ownerId],
  }).onDelete("cascade");

export const boards = pgTable(
  "boards",
  {
    id: uuid().primaryKey().defaultRandom(),
    customerId: uuid().notNull(),
    ownerId: uuid().notNull(),
    templateId: text().notNull(),
    // Set for zoom boards, which live as long as their entry.
    entryId: uuid(),
    // Set only on a diagram of the summary: what the SE calls it, and its place among the customer's diagrams.
    name: text(),
    position: integer(),
    createdAt: createdAt(),
  },
  (t): PgTableExtraConfigValue[] => [
    ownedByCustomer(t),
    unique().on(t.id, t.ownerId),
    foreignKey({
      columns: [t.entryId, t.ownerId],
      foreignColumns: [entries.id, entries.ownerId],
    }).onDelete("cascade"),
    uniqueIndex()
      .on(t.customerId, t.templateId)
      .where(and(isNull(t.entryId), isNull(t.name))!),
    uniqueIndex()
      .on(t.entryId)
      .where(isNotNull(t.entryId)),
  ],
);

export const vendors = pgTable("vendors", {
  id: text().primaryKey(),
  name: text().notNull(),
  aliases: text().array().notNull().default([]),
  retired: boolean().notNull().default(false),
});

export const itemSource = pgEnum("item_source", ["git", "approved"]);

export const catalogItems = pgTable("catalog_items", {
  id: text().primaryKey(),
  name: text().notNull(),
  aliases: text().array().notNull().default([]),
  category: text().notNull(),
  vendorId: text().references(() => vendors.id),
  useCases: text().array().notNull().default([]),
  source: itemSource().notNull(),
  retired: boolean().notNull().default(false),
});

// Live entries show in the room. Ghost (return visit) entries show only in the
// cockpit until confirmed; a dismissed entry records a declined propagation.
export const entryStatus = pgEnum("entry_status", ["live", "ghost", "dismissed"]);

export const entries = pgTable(
  "entries",
  {
    id: uuid().primaryKey().defaultRandom(),
    customerId: uuid().notNull(),
    ownerId: uuid().notNull(),
    boardId: uuid().notNull(),
    slot: text().notNull(),
    position: doublePrecision().notNull(),
    itemId: text().references(() => catalogItems.id),
    text: text(),
    attrs: jsonb().notNull().default({}),
    note: text(),
    status: entryStatus().notNull().default("live"),
    // The meeting the entry was added in, for return visits; null outside meetings.
    meetingId: uuid(),
    createdAt: createdAt(),
  },
  (t): PgTableExtraConfigValue[] => [
    ownedByCustomer(t),
    unique().on(t.id, t.ownerId),
    foreignKey({
      columns: [t.boardId, t.ownerId],
      foreignColumns: [boards.id, boards.ownerId],
    }).onDelete("cascade"),
    index().on(t.boardId, t.slot),
    check("entries_item_or_text", sql`(${t.itemId} is null) <> (${t.text} is null)`),
  ],
);

export const meetings = pgTable(
  "meetings",
  {
    id: uuid().primaryKey().defaultRandom(),
    customerId: uuid().notNull(),
    ownerId: uuid().notNull(),
    code: text(),
    startedAt: createdAt(),
    endedAt: timestamp({ withTimezone: true }),
    boardId: uuid(),
    held: boolean().notNull().default(false),
    // Which of a layout's panes the room shows: the ranked list's group, or a lit map's group zoom (0 is the map).
    pane: integer().notNull().default(0),
    // What the SE has selected in the cockpit, which the room lights: "slot:<id>", "entry:<uuid>" or "item:<id>".
    focus: text(),
    // Boards this meeting has opened, during Hold too, so the return-visit question is asked once.
    visited: uuid().array().notNull().default([]),
    // Boards and zoom boards the room has shown, which the notes and pack cover.
    shown: uuid().array().notNull().default([]),
    // The lit map's capability groups whose zoom the room has shown, and as "more:<board id>" the diagrams whose "+N more"
    // it has shown, which the pack pictures.
    shownGroups: text("visited_groups").array().notNull().default([]),
    // The customer's sequence number at End, which notes are rebuilt up to.
    endSeq: bigint({ mode: "number" }),
    // What the SE jots about the meeting, which leads its notes and never reaches the room.
    memo: text(),
  },
  (t) => [
    ownedByCustomer(t),
    unique().on(t.id, t.ownerId),
    foreignKey({
      columns: [t.boardId, t.ownerId],
      foreignColumns: [boards.id, boards.ownerId],
    }).onDelete("set null"),
    uniqueIndex().on(t.code).where(isNull(t.endedAt)),
    uniqueIndex().on(t.customerId).where(isNull(t.endedAt)),
  ],
);

// The owner is the author: customers are never shared.
export const commits = pgTable(
  "commits",
  {
    id: uuid().primaryKey(),
    customerId: uuid().notNull(),
    ownerId: uuid().notNull(),
    seq: bigint({ mode: "number" }).notNull(),
    meetingId: uuid(),
    boardId: uuid().notNull(),
    op: jsonb().notNull(),
    // Set on undo and redo: the commit whose effect this one reverses.
    reverts: uuid(),
    createdAt: createdAt(),
  },
  (t) => [
    ownedByCustomer(t),
    foreignKey({
      columns: [t.meetingId, t.ownerId],
      foreignColumns: [meetings.id, meetings.ownerId],
    }),
    unique().on(t.customerId, t.seq),
  ],
);

export const notes = pgTable(
  "notes",
  {
    meetingId: uuid().primaryKey(),
    ownerId: uuid().notNull(),
    markdown: text().notNull(),
    data: jsonb().notNull(),
    generatedAt: createdAt(),
  },
  (t) => [
    foreignKey({
      columns: [t.meetingId, t.ownerId],
      foreignColumns: [meetings.id, meetings.ownerId],
    }).onDelete("cascade"),
  ],
);

export const suggestionStatus = pgEnum("suggestion_status", ["pending", "approved", "rejected"]);

export const suggestions = pgTable(
  "suggestions",
  {
    id: uuid().primaryKey().defaultRandom(),
    customerId: uuid().notNull(),
    ownerId: uuid().notNull(),
    // Not a foreign key: an entry removed and brought back by undo keeps its suggestion.
    entryId: uuid(),
    name: text().notNull(),
    category: text().notNull(),
    aliases: text().array().notNull().default([]),
    status: suggestionStatus().notNull().default("pending"),
    itemId: text().references(() => catalogItems.id),
    createdAt: createdAt(),
    decidedAt: timestamp({ withTimezone: true }),
  },
  (t) => [
    ownedByCustomer(t),
    uniqueIndex()
      .on(t.entryId)
      .where(sql`${t.status} = 'pending'`),
  ],
);

// Join-code attempts, counted per address to rate-limit guessing.
export const joinAttempts = pgTable(
  "join_attempts",
  {
    id: uuid().primaryKey().defaultRandom(),
    ip: text().notNull(),
    at: createdAt(),
  },
  (t) => [index().on(t.ip, t.at)],
);
