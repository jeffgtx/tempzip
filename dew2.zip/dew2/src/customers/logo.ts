// A logo lives in its customer's row, so it needs no file store and goes when the customer does.
export const logoDataUrl = async (file: File) =>
  `data:${file.type};base64,${Buffer.from(await file.arrayBuffer()).toString("base64")}`;
