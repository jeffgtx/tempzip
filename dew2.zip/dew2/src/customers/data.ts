import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { customers } from "@/db/schema";

// Every customer query goes through here and is scoped to its owner.
const columns = {
  id: customers.id,
  name: customers.name,
  accent: customers.accent,
  clusters: customers.clusters,
};
const mine = (ownerId: string, id: string) =>
  and(eq(customers.ownerId, ownerId), eq(customers.id, id));

export const listCustomers = (ownerId: string) =>
  db
    .select(columns)
    .from(customers)
    .where(eq(customers.ownerId, ownerId))
    .orderBy(desc(customers.lastActiveAt));

// The sequence of the customer's latest commit, which tells a cockpit whether it missed any.
export async function getCustomer(ownerId: string, id: string) {
  const [row] = await db
    .select({ ...columns, logoUrl: customers.logoUrl, seq: customers.seq })
    .from(customers)
    .where(mine(ownerId, id));
  return row ?? null;
}

export async function createCustomer(
  ownerId: string,
  input: { id?: string; name: string; accent: string | null; clusters: string[]; logoUrl?: string | null },
) {
  const [row] = await db
    .insert(customers)
    .values({ ...input, ownerId })
    .returning({ id: customers.id });
  return row.id;
}

// Clusters can be added later but never taken away. A logo left out stays as it is.
export async function updateCustomer(
  ownerId: string,
  id: string,
  input: { name: string; accent: string | null; clusters: string[]; logoUrl?: string | null },
) {
  const updated = await db
    .update(customers)
    .set({
      name: input.name,
      accent: input.accent,
      logoUrl: input.logoUrl,
      lastActiveAt: sql`now()`,
      clusters: sql`array(select distinct unnest(${customers.clusters} || array[${sql.join(
        input.clusters.map((c) => sql`${c}`),
        sql`, `,
      )}]::text[]))`,
    })
    .where(mine(ownerId, id))
    .returning({ id: customers.id });
  return updated.length > 0;
}

export async function deleteCustomer(ownerId: string, id: string) {
  const deleted = await db.delete(customers).where(mine(ownerId, id)).returning({ id: customers.id });
  return deleted.length > 0;
}

// Home lists customers most recently active first.
export async function markActive(ownerId: string, id: string) {
  await db.update(customers).set({ lastActiveAt: sql`now()` }).where(mine(ownerId, id));
}
