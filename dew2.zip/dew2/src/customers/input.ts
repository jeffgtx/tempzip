import { z } from "zod";

export const customerInput = z.object({
  name: z.string().trim().min(1).max(120),
  accent: z
    .string()
    .regex(/^#[0-9a-f]{6}$/i)
    .nullable(),
  clusters: z.array(z.string()).min(1),
});

export type CustomerInput = z.infer<typeof customerInput>;

export const LOGO_TYPES = ["image/png", "image/jpeg", "image/webp"];
const LOGO_BYTES = 512 * 1024;

export const logoProblem = (file: File) =>
  !LOGO_TYPES.includes(file.type)
    ? "Use a PNG, JPEG or WebP image."
    : file.size > LOGO_BYTES
      ? "Use an image under 512 KB."
      : null;
