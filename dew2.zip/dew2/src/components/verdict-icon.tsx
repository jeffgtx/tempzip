import { IconAlertTriangle, IconBan, IconCircleCheck } from "@tabler/icons-react";
import type { Verdict } from "@/content/schema";

// Mid shades read on the cockpit's white and the room's near-black alike.
export const VERDICT: Record<Verdict, { Icon: typeof IconCircleCheck; label: string; text: string; tint: string }> = {
  allowed: { Icon: IconCircleCheck, label: "Allowed", text: "text-emerald-500", tint: "bg-emerald-500/[0.06]" },
  restricted: { Icon: IconAlertTriangle, label: "Restricted", text: "text-amber-500", tint: "bg-amber-500/[0.06]" },
  blocked: { Icon: IconBan, label: "Blocked", text: "text-red-500", tint: "bg-red-500/[0.06]" },
};

export function VerdictIcon({ verdict, className }: { verdict: Verdict; className?: string }) {
  const { Icon, label } = VERDICT[verdict];
  return <Icon className={className} aria-label={label} />;
}
