import { IconBolt, IconDiamond, IconFlag, IconStar } from "@tabler/icons-react";
import type { Mark } from "@/board/model";

type Shade = { border: string; text: string };

// Hues far enough apart that an outline alone tells the marks apart on a compressed screen share, and none that a verdict,
// the default accent or a quiet item uses. The cockpit's white wants a deeper shade than the room's near-black, and the
// light lime deeper still.
export const MARK: Record<Mark, { Icon: typeof IconFlag; label: string; cockpit: Shade; room: Shade }> = {
  flag: {
    Icon: IconFlag,
    label: "Flag",
    cockpit: { border: "border-sky-500", text: "text-sky-600" },
    room: { border: "border-sky-400", text: "text-sky-400" },
  },
  star: {
    Icon: IconStar,
    label: "Star",
    cockpit: { border: "border-violet-500", text: "text-violet-600" },
    room: { border: "border-violet-400", text: "text-violet-400" },
  },
  bolt: {
    Icon: IconBolt,
    label: "Bolt",
    cockpit: { border: "border-lime-600", text: "text-lime-700" },
    room: { border: "border-lime-400", text: "text-lime-400" },
  },
  diamond: {
    Icon: IconDiamond,
    label: "Diamond",
    cockpit: { border: "border-pink-500", text: "text-pink-600" },
    room: { border: "border-pink-400", text: "text-pink-400" },
  },
};

export function MarkIcon({ mark, className }: { mark: Mark; className?: string }) {
  const { Icon, label } = MARK[mark];
  return <Icon className={className} aria-label={label} />;
}
