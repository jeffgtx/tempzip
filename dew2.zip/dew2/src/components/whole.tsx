// Browsers may break a line after a hyphen, so each token holding one, such as SD-WAN or us-east-1, stays whole and no
// chip, card or node narrows below it. A " · " separator keeps to the word before it, so it never starts a line.
export function whole(text: string) {
  return text.replaceAll(" · ", "\u00a0· ").split(/(\S+-\S+)/).map((part, i) => (i % 2 ? <span key={i} className="whitespace-nowrap">{part}</span> : part));
}
