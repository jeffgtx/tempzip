"use client";

import { cn } from "cn";
import { Button } from "@/components/ui/button";
import { useBriefly } from "./use-briefly";

// The first click only arms it, so a submit button submits on the second. Left alone, it disarms.
export function ConfirmButton({ className, onClick, ...props }: React.ComponentProps<typeof Button>) {
  const [armed, setArmed] = useBriefly(3000);
  return (
    <Button
      {...props}
      aria-pressed={armed}
      className={cn(className, armed && "bg-destructive text-white hover:bg-destructive/90 hover:text-white")}
      onClick={(e) => {
        setArmed(!armed);
        if (armed) onClick?.(e);
        else e.preventDefault();
      }}
    />
  );
}
