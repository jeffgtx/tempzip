import { IconEye, IconEyeOff, IconShieldCheckFilled } from "@tabler/icons-react";
import type { COVERAGE_LEVELS } from "@/content/schema";

const LEVELS: Record<(typeof COVERAGE_LEVELS)[number], [typeof IconEye, string]> = {
  "coverage-none": [IconEyeOff, "Not covered"],
  "coverage-visibility": [IconEye, "Visibility"],
  "coverage-protection": [IconShieldCheckFilled, "Protection"],
};

export function CoverageIcon({ level, className }: { level: string; className?: string }) {
  const [Icon, label] = LEVELS[level as keyof typeof LEVELS];
  return <Icon className={className} aria-label={label} />;
}
