import "server-only";
import { cache } from "react";
import { localUser } from "./users";

// Whoever uses this machine is the one user.
export const currentUser = cache(localUser);
export const requireUser = currentUser;
