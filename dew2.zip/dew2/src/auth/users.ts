import { db } from "@/db";
import { users } from "@/db/schema";

// Every user row needs a unique phone number, so the one user has a placeholder.
const PHONE = "+10000000000";

export type User = { id: string };

export async function localUser(): Promise<User> {
  const [row] = await db
    .insert(users)
    .values({ phone: PHONE })
    .onConflictDoUpdate({ target: users.phone, set: { phone: PHONE } })
    .returning({ id: users.id });
  return row;
}
