import { z } from "zod";

const id = z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Use lowercase kebab-case");
const label = z.string().trim().min(1);
const aliases = z.array(label).default([]);

export const clustersFile = z.array(
  z.strictObject({
    id,
    name: label,
    boards: z.array(id),
  }),
);

export const catalogFile = z.strictObject({
  categories: z.array(z.strictObject({ id, name: label, implies: z.array(id).default([]) })).default([]),
  vendors: z.array(z.strictObject({ id, name: label, aliases })).default([]),
  items: z
    .array(
      z.strictObject({
        id,
        name: label,
        aliases,
        category: id,
        vendor: id.optional(),
        useCases: z.array(label).default([]),
        // A concern's label in a lit map's group zoom and the notes, and the capabilities it lights.
        short: label.optional(),
        routes: z.array(id).default([]),
        // The concerns it implies on a ranked list implied by its board.
        implies: z.array(id).default([]),
        // A one-line summary, such as a capability group's or a capability's.
        summary: label.optional(),
        // The item that groups this one on a board, such as a capability's group on the lit map.
        group: id.optional(),
        deliveredBy: z.array(id).default([]),
      }),
    )
    .default([]),
});

const attributeFields = {
  key: id,
  name: label,
  // Behind the tray's advanced toggle.
  advanced: z.literal(true).optional(),
  // Which part of its entry's zoom it describes: left of the box, the box, or right of it. The tray groups by it.
  at: z.enum(["left", "box", "right"]).optional(),
  // Only entries that are these items have it, such as Prisma Access's edition in a slot that also holds SD-WAN.
  for: z.array(id).min(1).optional(),
};

export const VERDICTS = ["allowed", "restricted", "blocked"] as const;

// A pick keyed "coverage" or "goal" draws the category of its item, which must be one of these levels.
export const COVERAGE_LEVELS = ["coverage-none", "coverage-visibility", "coverage-protection"] as const;

const scalarAttribute = z.discriminatedUnion("type", [
  z.strictObject({ ...attributeFields, type: z.literal("number") }),
  z.strictObject({ ...attributeFields, type: z.literal("text") }),
  z.strictObject({
    ...attributeFields,
    type: z.literal("pick"),
    categories: z.array(id).min(1),
    // Only these items of its categories, in this order.
    items: z.array(id).optional(),
  }),
  // Another entry of the board, from the named slots.
  z.strictObject({ ...attributeFields, type: z.literal("ref"), slots: z.array(id).min(1) }),
  // One of its entry's own records of the named attribute, such as the network a cloud's app sits in.
  z.strictObject({ ...attributeFields, type: z.literal("record"), of: id }),
]);

const attribute = z.discriminatedUnion("type", [
  ...scalarAttribute.options,
  z.strictObject({
    ...attributeFields,
    type: z.literal("records"),
    fields: z.array(scalarAttribute).min(1),
    // Items offered as chips above the records; each adds a record holding it in the first field: its name in a text
    // field, or the item itself in a pick.
    presets: z.array(id).default([]),
  }),
]);

const slots = z.array(
  z.strictObject({
    id,
    name: label,
    // Empty accepts every category.
    categories: z.array(id).default([]),
    presets: z.array(id).default([]),
    // Presets a customer also gets for each of these clusters it has, after "presets".
    clusterPresets: z.record(id, z.array(id)).default({}),
    attributes: z.array(attribute).default([]),
    // The treatment its entries get, drawn on its heading and never on its chips.
    verdict: z.enum(VERDICTS).optional(),
    // The same item can be entered more than once, such as tiers of branches or several data centers.
    repeats: z.boolean().default(false),
    // What the SE asks to fill it, shown under it in the cockpit only.
    questions: z.array(label).default([]),
    // Holds what the customer plans, such as the AI board's Where you're going: it neither suggests nor is suggested anything.
    planned: z.boolean().default(false),
    // The zoom every entry of the slot opens, whatever its item's category.
    zoom: id.optional(),
    // Its entries zoom only once the SE adds the zoom, which marks the entry `zoom: true`.
    zoomOnRequest: z.boolean().optional(),
    // On the summary this slot has no button of its own: its chips and type-ahead join the named slot's tray, and what they add still lands here.
    tray: id.optional(),
  }),
);

const templateFields = {
  name: label,
  // Absent on a board every customer has, whatever their clusters.
  cluster: id.optional(),
  slots: slots.min(1),
  // The categories the board is about, for its slots that accept every category: their chips lead with what the
  // customer named in them on other boards, and their free text can be suggested into them. They draw no suggestions.
  categories: z.array(id).default([]),
  // Entry category to the template of the zoom board each such entry gets.
  zooms: z.record(id, id).default({}),
};

export const boardTemplate = z.discriminatedUnion("layout", [
  z.strictObject({
    ...templateFields,
    layout: z.literal("grid"),
    // A slot shown as a chip strip above the rows.
    strip: id.optional(),
    // Slots by row and column, either for the whole board or for each of its groups.
    rows: z.array(z.array(id).min(1)).min(1).optional(),
    // The board in groups the top bar picks between; the cockpit and the room show one at a time.
    groups: z.array(z.strictObject({ name: label, rows: z.array(z.array(id).min(1)).min(1) })).min(2).optional(),
    // Headings over the columns; each row then reads as its first slot's name.
    columns: z.array(label).min(2).optional(),
  }),
  // One slot each. A lit map's slot holds overrides, and its presets are the capability groups, in order.
  z.strictObject({
    ...templateFields,
    layout: z.literal("ranked-list"),
    // Boards whose entries put concerns at 1 through what their items and categories imply. The slot's categories are the concern groups.
    impliedBy: z.array(id).default([]),
  }),
  z.strictObject({ ...templateFields, layout: z.literal("lit-map") }),
  z.strictObject({
    ...templateFields,
    layout: z.literal("list"),
    // What each entry carries beside its owner: the date it's due, or the minutes it takes.
    timing: z.enum(["due", "minutes"]),
  }),
  z.strictObject({
    ...templateFields,
    layout: z.literal("hub-and-spoke"),
    // The zoom the "+N more" node opens: the groups folded away, as a list.
    more: id.optional(),
    // The slot that keeps the saved flows, which draws no node.
    flows: id.optional(),
  }),
  // A zoom shows its entry's fields, laid out for the kind of node it is, and holds no entries of its own.
  z.strictObject({
    ...templateFields,
    slots: slots.default([]),
    layout: z.literal("zoom"),
    shows: z.enum(["site", "datacenter", "people", "cloud", "security", "sdwan", "folded", "app"]),
  }),
]);

// Common architectures the summary can start from or fill in.
export const architecturesFile = z.array(
  z.strictObject({
    id,
    name: label,
    summary: label,
    // The hub-and-spoke board it fills.
    board: id,
    nodes: z
      .array(
        z.strictObject({
          // How the architecture's group and connections name the node.
          key: id,
          slot: id,
          item: id,
          // Only what tells two nodes of one item apart, such as DC-East and DC-West. Everything else is the customer's to say.
          name: label.optional(),
          // The Prisma Access a Prisma SD-WAN groups with.
          group: id.optional(),
        }),
      )
      .min(1),
    connections: z
      .array(
        z.strictObject({
          from: id,
          // None for a breakout.
          to: id.optional(),
          type: id,
        }),
      )
      .default([]),
  }),
);

export type Cluster = z.output<typeof clustersFile>[number];
export type Architecture = z.output<typeof architecturesFile>[number];
export type CatalogFile = z.output<typeof catalogFile>;
export type Category = CatalogFile["categories"][number];
export type Vendor = CatalogFile["vendors"][number];
export type CatalogItem = CatalogFile["items"][number];
export type Verdict = (typeof VERDICTS)[number];
export type BoardTemplate = z.output<typeof boardTemplate> & { id: string };
