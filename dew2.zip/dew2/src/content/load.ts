import fs from "node:fs";
import path from "node:path";
import { z } from "zod";
import {
  type Architecture,
  type BoardTemplate,
  type CatalogItem,
  type Category,
  type Cluster,
  type Vendor,
  COVERAGE_LEVELS,
  architecturesFile,
  boardTemplate,
  catalogFile,
  clustersFile,
} from "./schema";

export type Content = {
  clusters: Cluster[];
  categories: Category[];
  vendors: Vendor[];
  items: CatalogItem[];
  templates: BoardTemplate[];
  architectures: Architecture[];
};

function readJson<T>(file: string, schema: z.ZodType<T>, problems: string[]): T | undefined {
  let json: unknown;
  try {
    json = JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (error) {
    problems.push(`${file}: ${(error as Error).message}`);
    return undefined;
  }
  const parsed = schema.safeParse(json);
  if (parsed.success) return parsed.data;
  problems.push(`${file}:\n${z.prettifyError(parsed.error)}`);
  return undefined;
}

const jsonFiles = (dir: string) =>
  fs.existsSync(dir)
    ? fs
        .readdirSync(dir)
        .filter((f) => f.endsWith(".json"))
        .sort()
    : [];

export function loadContent(root = path.join(process.cwd(), "content")): Content {
  const problems: string[] = [];
  const clusters = readJson(path.join(root, "clusters.json"), clustersFile, problems) ?? [];
  const catalogs = jsonFiles(path.join(root, "catalog")).flatMap(
    (f) => readJson(path.join(root, "catalog", f), catalogFile, problems) ?? [],
  );
  const readBoards = (dir: string, cluster?: string) =>
    jsonFiles(dir).flatMap((f) => {
      const file = path.join(dir, f);
      const template = readJson(file, boardTemplate, problems);
      if (!template) return [];
      if (cluster && template.cluster !== cluster) problems.push(`${file}: cluster must be "${cluster}"`);
      if (!cluster && template.cluster) problems.push(`${file}: a board outside a cluster's folder names no cluster`);
      return [{ ...template, id: f.slice(0, -".json".length) }];
    });
  const boardsDir = path.join(root, "boards");
  const clusterDirs = fs.existsSync(boardsDir)
    ? fs
        .readdirSync(boardsDir, { withFileTypes: true })
        .filter((d) => d.isDirectory())
        .map((d) => d.name)
        .sort()
    : [];
  const templates = [...clusterDirs.flatMap((dir) => readBoards(path.join(boardsDir, dir), dir)), ...readBoards(boardsDir)];
  const content: Content = {
    clusters,
    categories: catalogs.flatMap((c) => c.categories),
    vendors: catalogs.flatMap((c) => c.vendors),
    items: catalogs.flatMap((c) => c.items),
    templates,
    architectures: readJson(path.join(root, "architectures.json"), architecturesFile, problems) ?? [],
  };
  problems.push(...validateContent(content));
  if (problems.length) throw new Error(`Invalid content in ${root}:\n${problems.join("\n")}`);
  return content;
}

// The zoom boards a board opens: its entries' zooms, and a summary's "+N more".
export const zoomsOf = (t: BoardTemplate) => [
  ...Object.values(t.zooms),
  ...t.slots.flatMap((s) => (s.zoom ? [s.zoom] : [])),
  ...(t.layout === "hub-and-spoke" && t.more ? [t.more] : []),
];

// The rail's sections for a customer: each of its clusters, then, unnamed, the boards every customer has, in file name
// order, which puts Agenda above Next steps.
export function railSections(clusterIds: string[], { clusters, templates } = getContent()) {
  return [
    ...clusters.filter((c) => clusterIds.includes(c.id)).map(({ id, name, boards }) => ({ id, name: name as string | null, boards })),
    { id: "every", name: null, boards: templates.filter((t) => !t.cluster && t.layout !== "zoom").map((t) => t.id) },
  ];
}

// A template as a customer with these clusters sees it: each slot's presets, then those its clusters add.
export const withClusterPresets = <T extends BoardTemplate>(t: T, clusterIds: string[]): T => ({
  ...t,
  slots: t.slots.map((s) => ({
    ...s,
    presets: [...s.presets, ...getContent().clusters.filter((c) => clusterIds.includes(c.id)).flatMap((c) => s.clusterPresets[c.id] ?? [])],
  })),
});

let cached: Content | undefined;
export const getContent = () => (cached ??= loadContent());

// What a flow keeps: who, how they connect, through what, and where the app lives.
const FLOW_FIELDS = [
  ["who", "ref"],
  ["how", "pick"],
  ["through", "ref"],
  ["where", "ref"],
  ["app", "text"],
] as const;

export function validateContent({ clusters, categories, vendors, items, templates, architectures }: Content): string[] {
  const problems: string[] = [];
  const ids = (kind: string, list: { id: string }[]) => {
    const seen = new Set<string>();
    for (const { id } of list) {
      if (seen.has(id)) problems.push(`Duplicate ${kind} "${id}"`);
      seen.add(id);
    }
    return seen;
  };
  const clusterIds = ids("cluster", clusters);
  const categoryIds = ids("category", categories);
  const vendorIds = ids("vendor", vendors);
  const itemsById = new Map(items.map((i) => [i.id, i]));
  ids("catalog item", items);
  const templatesById = new Map(templates.map((t) => [t.id, t]));
  ids("board", templates);

  const categoryNames = new Map(categories.map((c) => [c.id, c.name]));
  for (const item of items) {
    if (!categoryIds.has(item.category))
      problems.push(`Catalog item "${item.id}" has unknown category "${item.category}"`);
    else if (item.useCases.length && item.useCases[0] !== categoryNames.get(item.category))
      problems.push(`Catalog item "${item.id}" must list its category first among its use cases`);
    if (item.vendor && !vendorIds.has(item.vendor))
      problems.push(`Catalog item "${item.id}" has unknown vendor "${item.vendor}"`);
    for (const route of item.routes)
      if (!itemsById.has(route)) problems.push(`Catalog item "${item.id}" routes to unknown item "${route}"`);
    if (item.group && !itemsById.has(item.group))
      problems.push(`Catalog item "${item.id}" has unknown group "${item.group}"`);
    for (const product of item.deliveredBy)
      if (!itemsById.get(product)?.vendor)
        problems.push(`Catalog item "${item.id}" is delivered by "${product}", which is not a product`);
  }

  const concernCategories = new Set(templates.flatMap((t) => (t.layout === "ranked-list" ? t.slots[0].categories : [])));
  const isConcern = (id: string) => concernCategories.has(itemsById.get(id)?.category ?? "");
  for (const [kind, list] of [["Catalog item", items], ["Category", categories]] as const)
    for (const { id, implies } of list)
      for (const concern of implies)
        if (!isConcern(concern)) problems.push(`${kind} "${id}" implies "${concern}", which is not a concern`);

  // Zooms are reached from the board that zooms into them, not listed in a cluster.
  for (const cluster of clusters)
    for (const board of cluster.boards)
      if (templatesById.get(board)?.cluster !== cluster.id || templatesById.get(board)?.layout === "zoom")
        problems.push(`Cluster "${cluster.id}" lists "${board}", which is not one of its boards`);
  const zoomed = new Set(templates.flatMap(zoomsOf));

  for (const t of templates) {
    const at = `Board "${t.id}"`;
    if (t.cluster && !clusterIds.has(t.cluster)) problems.push(`${at} has unknown cluster "${t.cluster}"`);
    else if (t.layout === "zoom" ? !zoomed.has(t.id) : !!t.cluster && !clusters.find((c) => c.id === t.cluster)!.boards.includes(t.id))
      problems.push(`${at} is missing from cluster "${t.cluster}"'s boards, or no board zooms into it`);

    for (const c of t.categories) if (!categoryIds.has(c)) problems.push(`${at} is about unknown category "${c}"`);
    const slotIds = ids(`slot in board "${t.id}"`, t.slots);
    for (const slot of t.slots) {
      const where = `${at} slot "${slot.id}"`;
      for (const c of slot.categories)
        if (!categoryIds.has(c)) problems.push(`${where} accepts unknown category "${c}"`);
      for (const c of Object.keys(slot.clusterPresets))
        if (!clusterIds.has(c)) problems.push(`${where} adds presets for unknown cluster "${c}"`);
      for (const p of [...slot.presets, ...Object.values(slot.clusterPresets).flat()]) {
        const item = itemsById.get(p);
        if (!item) problems.push(`${where} has unknown preset "${p}"`);
        else if (slot.categories.length && !slot.categories.includes(item.category))
          problems.push(`${where} preset "${p}" is not in a category it accepts`);
      }
      if (slot.zoom && templatesById.get(slot.zoom)?.layout !== "zoom")
        problems.push(`${where} zooms into "${slot.zoom}", which is not a zoom board`);
      const host = t.slots.find((s) => s.id === slot.tray);
      if (slot.tray && (!host || host === slot || host.tray))
        problems.push(`${where} joins the tray of "${slot.tray}", which is not another slot without a tray of its own`);
      ids(`attribute in ${where}`, slot.attributes.map((a) => ({ id: a.key })));
      for (const a of slot.attributes)
        for (const i of a.for ?? [])
          if (!itemsById.has(i)) problems.push(`${where} "${a.key}" is for unknown item "${i}"`);
      const scalars = slot.attributes.flatMap((a) => {
        if (a.type !== "records") return [a];
        ids(`field in ${where} "${a.key}"`, a.fields.map((f) => ({ id: f.key })));
        if (a.fields.some((f) => f.for)) problems.push(`${where} "${a.key}" limits a field to items, which only an attribute can`);
        const [first] = a.fields;
        const holds = (item: CatalogItem) =>
          first.type === "text" ||
          (first.type === "pick" && first.categories.includes(item.category) && (first.items?.includes(item.id) ?? true));
        for (const p of a.presets) {
          const item = itemsById.get(p);
          if (!item) problems.push(`${where} "${a.key}" offers unknown item "${p}"`);
          else if (!holds(item)) problems.push(`${where} "${a.key}" offers "${p}", which its first field can't hold`);
        }
        return a.fields;
      });
      for (const a of scalars) {
        if (a.type === "pick") {
          for (const c of a.categories)
            if (!categoryIds.has(c)) problems.push(`${where} "${a.key}" picks from unknown category "${c}"`);
          for (const i of a.items ?? [])
            if (!a.categories.includes(itemsById.get(i)?.category ?? ""))
              problems.push(`${where} "${a.key}" offers "${i}", which is not an item of its categories`);
          if ((a.key === "coverage" || a.key === "goal") && !a.categories.every((c) => COVERAGE_LEVELS.some((l) => l === c)))
            problems.push(`${where} "${a.key}" must pick from ${COVERAGE_LEVELS.join(", ")}`);
        }
        if (a.type === "ref")
          for (const target of a.slots)
            if (!slotIds.has(target)) problems.push(`${where} "${a.key}" refers to unknown slot "${target}"`);
        if (a.type === "record" && slot.attributes.find((x) => x.key === a.of)?.type !== "records")
          problems.push(`${where} "${a.key}" points into "${a.of}", which is not a records attribute of its slot`);
      }
    }
    if (t.layout === "grid") {
      if (!t.rows === !t.groups) problems.push(`${at} must lay out its slots in rows or in groups, not both`);
      const rows = t.groups ? t.groups.flatMap((g) => g.rows) : (t.rows ?? []);
      const placed = [...(t.strip ? [t.strip] : []), ...rows.flat()];
      for (const slot of t.slots)
        if (placed.filter((id) => id === slot.id).length !== 1)
          problems.push(`${at} must place slot "${slot.id}" exactly once`);
      for (const id of placed)
        if (!slotIds.has(id)) problems.push(`${at} places unknown slot "${id}"`);
      if (t.columns && rows.some((row) => row.length !== t.columns!.length))
        problems.push(`${at} must put one slot in each column of every row`);
    }
    const single = t.layout === "ranked-list" || t.layout === "lit-map" || t.layout === "list";
    if (single && t.slots.length !== 1) problems.push(`${at} must have exactly one slot`);
    for (const [category, zoom] of Object.entries(t.zooms)) {
      if (!categoryIds.has(category)) problems.push(`${at} zooms unknown category "${category}"`);
      if (templatesById.get(zoom)?.layout !== "zoom")
        problems.push(`${at} zooms "${category}" into "${zoom}", which is not a zoom board`);
    }
    if (t.layout === "ranked-list")
      for (const board of t.impliedBy)
        if (board === t.id || !templatesById.has(board) || templatesById.get(board)!.layout === "zoom")
          problems.push(`${at} is implied by unknown board "${board}"`);
    if (t.layout === "hub-and-spoke" && t.flows) {
      const slot = t.slots.find((s) => s.id === t.flows);
      const has = (key: string, type: string) => slot?.attributes.some((a) => a.key === key && a.type === type);
      if (!FLOW_FIELDS.every(([key, type]) => has(key, type)))
        problems.push(`${at} keeps flows in "${t.flows}", which must be a slot with ${FLOW_FIELDS.map((f) => f.join(" ")).join(", ")}`);
    }
    if (t.layout === "hub-and-spoke" && t.more) {
      const more = templatesById.get(t.more);
      if (more?.layout !== "zoom" || more.shows !== "folded")
        problems.push(`${at} folds into "${t.more}", which is not a zoom that shows folded groups`);
    }
  }

  ids("architecture", architectures);
  for (const a of architectures) {
    const at = `Architecture "${a.id}"`;
    const board = templatesById.get(a.board);
    if (board?.layout !== "hub-and-spoke") {
      problems.push(`${at} fills "${a.board}", which is not a hub-and-spoke board`);
      continue;
    }
    ids(`node in ${at}`, a.nodes.map((n) => ({ id: n.key })));
    const nodes = new Map(a.nodes.map((n) => [n.key, n]));
    for (const n of a.nodes) {
      const where = `${at} node "${n.key}"`;
      const slot = board.slots.find((s) => s.id === n.slot);
      const item = itemsById.get(n.item);
      if (!slot) problems.push(`${where} is in unknown slot "${n.slot}"`);
      else if (!item || (slot.categories.length && !slot.categories.includes(item.category)))
        problems.push(`${where} is "${n.item}", which is not an item its slot accepts`);
      if (n.group && !nodes.has(n.group)) problems.push(`${where} groups with unknown node "${n.group}"`);
    }
    for (const c of a.connections)
      for (const end of [c.from, c.to ?? c.from])
        if (!nodes.has(end)) problems.push(`${at} connects unknown node "${end}"`);
  }
  return problems;
}
