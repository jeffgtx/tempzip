# dew2

## Run it

1. Install Node.js with `brew install node` in Terminal, or with the installer from https://nodejs.org.
2. Unzip, then in Terminal:

   ```sh
   cd ~/Downloads/dew2
   sh start.command
   ```

   The first run installs packages, which takes a few minutes and needs the internet. Your browser then opens
   http://localhost:3000. The first visit to each page takes a few seconds to compile.

   You can also double-click `start.command` in Finder. If macOS says it can't verify it, open System Settings,
   go to Privacy & Security, and click Open Anyway.
3. To stop, press Ctrl+C in the Terminal window, or close it.

## Your data

It lives in the hidden `.pglite` folder in here and is kept between runs. To back it up, stop the app and copy the
whole folder. To start over, stop the app and run `rm -rf .pglite`. Only one copy can run at a time; a second one
refuses to open the data.

## The room

It pauses after 30 minutes without a change. Click it or press a key to resume.
