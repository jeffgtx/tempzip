#!/bin/sh
# Starts dew2 on this Mac. Ctrl+C, or closing this window, stops it.
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1 ||
  ! node -e 'const [a, b] = process.versions.node.split(".").map(Number); process.exit(a > 20 || (a === 20 && b >= 9) ? 0 : 1)'; then
  echo "dew2 needs a newer Node.js. Run 'brew install node' (or 'brew upgrade node'), or use the installer from https://nodejs.org, then run this again."
  exit 1
fi

# Otherwise the browser would open whatever already answers there.
if curl -s -o /dev/null http://localhost:3000; then
  echo "Something is already running at http://localhost:3000, such as another copy of dew2. Stop it, then run this again."
  exit 1
fi

# npm writes this file last, so an install cut short is run again.
[ -f node_modules/.package-lock.json ] || npm ci || exit 1

export NEXT_TELEMETRY_DISABLED=1

# Open the browser once the app answers, giving up after two minutes.
(
  for _ in $(seq 120); do
    curl -s -o /dev/null http://localhost:3000 && open http://localhost:3000 && exit
    sleep 1
  done
) &

exec npm run dev -- -p 3000
