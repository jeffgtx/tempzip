ALTER TABLE "entries" ADD COLUMN "meeting_id" uuid;--> statement-breakpoint
ALTER TABLE "join_attempts" ADD COLUMN "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL;