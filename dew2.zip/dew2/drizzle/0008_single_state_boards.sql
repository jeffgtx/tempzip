-- App tiers and the Security boards hold one state now. Today stays; what Where you're going added, removed or
-- changed there goes, and so does App tiers' Access row. Notes replay the commits and list neither a later state's
-- entries nor a slot a board lacks, so the commits stay. The migrator runs each statement on its own; each is safe to run again.
DELETE FROM "entry_changes" WHERE "entry_id" IN (SELECT "id" FROM "entries" WHERE "board_id" IN (
  SELECT "id" FROM "boards" WHERE "template_id" IN ('app-tiers', 'security-survey', 'platform-services', 'enforcement-points', 'cloud-posture')));
--> statement-breakpoint
DELETE FROM "entries" WHERE "state" > 0 AND "board_id" IN (
  SELECT "id" FROM "boards" WHERE "template_id" IN ('app-tiers', 'security-survey', 'platform-services', 'enforcement-points', 'cloud-posture'));
--> statement-breakpoint
DELETE FROM "entries" WHERE "slot" = 'access' AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'app-tiers');
