CREATE TYPE "public"."entry_status" AS ENUM('live', 'suggested', 'ghost');--> statement-breakpoint
CREATE TYPE "public"."item_source" AS ENUM('git', 'approved');--> statement-breakpoint
CREATE TYPE "public"."suggestion_status" AS ENUM('pending', 'approved', 'rejected');--> statement-breakpoint
CREATE TABLE "boards" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"customer_id" uuid NOT NULL,
	"owner_id" uuid NOT NULL,
	"template_id" text NOT NULL,
	"entry_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "boards_id_ownerId_unique" UNIQUE("id","owner_id")
);
--> statement-breakpoint
CREATE TABLE "catalog_items" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"aliases" text[] DEFAULT '{}' NOT NULL,
	"category" text NOT NULL,
	"vendor_id" text,
	"use_cases" text[] DEFAULT '{}' NOT NULL,
	"source" "item_source" NOT NULL,
	"retired" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE "commits" (
	"id" uuid PRIMARY KEY NOT NULL,
	"customer_id" uuid NOT NULL,
	"owner_id" uuid NOT NULL,
	"seq" bigint NOT NULL,
	"meeting_id" uuid,
	"board_id" uuid NOT NULL,
	"state" integer NOT NULL,
	"op" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "commits_customerId_seq_unique" UNIQUE("customer_id","seq")
);
--> statement-breakpoint
CREATE TABLE "customers" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"owner_id" uuid NOT NULL,
	"name" text NOT NULL,
	"accent" text,
	"clusters" text[] NOT NULL,
	"seq" bigint DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_active_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "customers_id_ownerId_unique" UNIQUE("id","owner_id")
);
--> statement-breakpoint
CREATE TABLE "entries" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"customer_id" uuid NOT NULL,
	"owner_id" uuid NOT NULL,
	"board_id" uuid NOT NULL,
	"slot" text NOT NULL,
	"state" integer DEFAULT 0 NOT NULL,
	"position" double precision NOT NULL,
	"item_id" text,
	"text" text,
	"attrs" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"note" text,
	"status" "entry_status" DEFAULT 'live' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "entries_id_ownerId_unique" UNIQUE("id","owner_id"),
	CONSTRAINT "entries_item_or_text" CHECK (("entries"."item_id" is null) <> ("entries"."text" is null))
);
--> statement-breakpoint
CREATE TABLE "entry_changes" (
	"entry_id" uuid NOT NULL,
	"owner_id" uuid NOT NULL,
	"state" integer NOT NULL,
	"removed" boolean DEFAULT false NOT NULL,
	"attrs" jsonb DEFAULT '{}'::jsonb NOT NULL,
	CONSTRAINT "entry_changes_entry_id_state_pk" PRIMARY KEY("entry_id","state")
);
--> statement-breakpoint
CREATE TABLE "meetings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"customer_id" uuid NOT NULL,
	"owner_id" uuid NOT NULL,
	"code" text,
	"started_at" timestamp with time zone DEFAULT now() NOT NULL,
	"ended_at" timestamp with time zone,
	"board_id" uuid,
	"state" integer DEFAULT 0 NOT NULL,
	"held" boolean DEFAULT false NOT NULL,
	CONSTRAINT "meetings_id_ownerId_unique" UNIQUE("id","owner_id")
);
--> statement-breakpoint
CREATE TABLE "notes" (
	"meeting_id" uuid PRIMARY KEY NOT NULL,
	"owner_id" uuid NOT NULL,
	"markdown" text NOT NULL,
	"data" jsonb NOT NULL,
	"generated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"token_hash" text PRIMARY KEY NOT NULL,
	"user_id" uuid NOT NULL,
	"expires_at" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE TABLE "suggestions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"customer_id" uuid NOT NULL,
	"owner_id" uuid NOT NULL,
	"entry_id" uuid,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"aliases" text[] DEFAULT '{}' NOT NULL,
	"status" "suggestion_status" DEFAULT 'pending' NOT NULL,
	"item_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"decided_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"phone" text NOT NULL,
	"invited_at" timestamp with time zone DEFAULT now() NOT NULL,
	"removed_at" timestamp with time zone,
	CONSTRAINT "users_phone_unique" UNIQUE("phone")
);
--> statement-breakpoint
CREATE TABLE "vendors" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"aliases" text[] DEFAULT '{}' NOT NULL,
	"retired" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
ALTER TABLE "boards" ADD CONSTRAINT "boards_customer_id_owner_id_customers_id_owner_id_fk" FOREIGN KEY ("customer_id","owner_id") REFERENCES "public"."customers"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "boards" ADD CONSTRAINT "boards_entry_id_owner_id_entries_id_owner_id_fk" FOREIGN KEY ("entry_id","owner_id") REFERENCES "public"."entries"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "catalog_items" ADD CONSTRAINT "catalog_items_vendor_id_vendors_id_fk" FOREIGN KEY ("vendor_id") REFERENCES "public"."vendors"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "commits" ADD CONSTRAINT "commits_customer_id_owner_id_customers_id_owner_id_fk" FOREIGN KEY ("customer_id","owner_id") REFERENCES "public"."customers"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "commits" ADD CONSTRAINT "commits_meeting_id_owner_id_meetings_id_owner_id_fk" FOREIGN KEY ("meeting_id","owner_id") REFERENCES "public"."meetings"("id","owner_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "customers" ADD CONSTRAINT "customers_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "entries" ADD CONSTRAINT "entries_item_id_catalog_items_id_fk" FOREIGN KEY ("item_id") REFERENCES "public"."catalog_items"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "entries" ADD CONSTRAINT "entries_customer_id_owner_id_customers_id_owner_id_fk" FOREIGN KEY ("customer_id","owner_id") REFERENCES "public"."customers"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "entries" ADD CONSTRAINT "entries_board_id_owner_id_boards_id_owner_id_fk" FOREIGN KEY ("board_id","owner_id") REFERENCES "public"."boards"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "entry_changes" ADD CONSTRAINT "entry_changes_entry_id_owner_id_entries_id_owner_id_fk" FOREIGN KEY ("entry_id","owner_id") REFERENCES "public"."entries"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "meetings" ADD CONSTRAINT "meetings_customer_id_owner_id_customers_id_owner_id_fk" FOREIGN KEY ("customer_id","owner_id") REFERENCES "public"."customers"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "meetings" ADD CONSTRAINT "meetings_board_id_owner_id_boards_id_owner_id_fk" FOREIGN KEY ("board_id","owner_id") REFERENCES "public"."boards"("id","owner_id") ON DELETE SET NULL ("board_id") ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notes" ADD CONSTRAINT "notes_meeting_id_owner_id_meetings_id_owner_id_fk" FOREIGN KEY ("meeting_id","owner_id") REFERENCES "public"."meetings"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "suggestions" ADD CONSTRAINT "suggestions_item_id_catalog_items_id_fk" FOREIGN KEY ("item_id") REFERENCES "public"."catalog_items"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "suggestions" ADD CONSTRAINT "suggestions_customer_id_owner_id_customers_id_owner_id_fk" FOREIGN KEY ("customer_id","owner_id") REFERENCES "public"."customers"("id","owner_id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "suggestions" ADD CONSTRAINT "suggestions_entry_id_owner_id_entries_id_owner_id_fk" FOREIGN KEY ("entry_id","owner_id") REFERENCES "public"."entries"("id","owner_id") ON DELETE SET NULL ("entry_id") ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "boards_customer_id_template_id_index" ON "boards" USING btree ("customer_id","template_id") WHERE "boards"."entry_id" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "boards_entry_id_index" ON "boards" USING btree ("entry_id") WHERE "boards"."entry_id" is not null;--> statement-breakpoint
CREATE INDEX "customers_owner_id_last_active_at_index" ON "customers" USING btree ("owner_id","last_active_at");--> statement-breakpoint
CREATE INDEX "entries_board_id_slot_index" ON "entries" USING btree ("board_id","slot");--> statement-breakpoint
CREATE UNIQUE INDEX "meetings_code_index" ON "meetings" USING btree ("code") WHERE "meetings"."ended_at" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "meetings_customer_id_index" ON "meetings" USING btree ("customer_id") WHERE "meetings"."ended_at" is null;