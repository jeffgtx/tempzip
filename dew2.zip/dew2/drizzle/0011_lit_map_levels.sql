-- A capability can no longer be forced off: its level-0 overrides go, ghosts included, and it shows its concerns' level.
-- Notes replay the commits and the lit map reads a level outside 1 to 3 as no override, so the commits stay. Safe to run again.
DELETE FROM "entries" WHERE "attrs"->>'level' = '0' AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'where-we-can-help');
