-- The AI board's Where you're going is three slots of its own: what the future added moves there,
-- and what it removed or changed of Today's is dropped. Notes replay the commits, so their ops move too.
-- The migrator runs each statement on its own, so every step is safe to run again.
UPDATE "entries" SET "slot" = "slot" || '-future', "state" = 0
WHERE "state" = 1 AND "slot" IN ('adoption','apps','security')
  AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'ai-and-ai-security');
--> statement-breakpoint
DELETE FROM "entry_changes" WHERE "entry_id" IN (SELECT e."id" FROM "entries" e JOIN "boards" b ON b."id" = e."board_id" WHERE b."template_id" = 'ai-and-ai-security');
--> statement-breakpoint
-- A put that added an entry in the future lands where the entry now is, or, for one deleted since, in the future slot.
CREATE OR REPLACE FUNCTION ai_future_entry(e jsonb) RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT CASE WHEN e->>'state' = '1' AND e->>'slot' IN ('adoption','apps','security')
    THEN e || jsonb_build_object('state', 0, 'slot', coalesce((SELECT "slot" FROM "entries" WHERE "id"::text = e->>'id'), (e->>'slot') || '-future'))
    ELSE e END $$;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION ai_future_op(op jsonb) RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT CASE
    WHEN op ? 'ops' THEN jsonb_set(op, '{ops}', (SELECT jsonb_agg(ai_future_op(o) ORDER BY i) FROM jsonb_array_elements(op->'ops') WITH ORDINALITY x(o, i)))
    WHEN op ? 'entries' THEN jsonb_set(op, '{entries}', coalesce((SELECT jsonb_agg(ai_future_entry(e) ORDER BY i) FROM jsonb_array_elements(op->'entries') WITH ORDINALITY x(e, i)), '[]'))
    WHEN op ? 'updates' THEN jsonb_set(op, '{updates}', coalesce((SELECT jsonb_agg(u || jsonb_build_object('set', (u->'set') - 'state', 'prev', (u->'prev') - 'state') ORDER BY i) FROM jsonb_array_elements(op->'updates') WITH ORDINALITY x(u, i)), '[]'))
    ELSE op END $$;
--> statement-breakpoint
UPDATE "commits" SET "op" = ai_future_op("op") WHERE "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'ai-and-ai-security');
--> statement-breakpoint
DROP FUNCTION ai_future_op(jsonb);
--> statement-breakpoint
DROP FUNCTION ai_future_entry(jsonb);
