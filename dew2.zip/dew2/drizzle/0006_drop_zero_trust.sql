-- Zero Trust maturity is gone, and its boards with it. Undo can't revert a step on a board that no longer exists,
-- so the board's steps go too. The migrator runs each statement on its own; each is safe to run again.
DELETE FROM "commits" WHERE "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'zero-trust-maturity');
--> statement-breakpoint
DELETE FROM "boards" WHERE "template_id" = 'zero-trust-maturity';
