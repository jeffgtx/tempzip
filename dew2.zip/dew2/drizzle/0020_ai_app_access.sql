-- A bought app's line into it is Access, so the AI Access and AI Browser Control records an SE placed on Prompts move there, keeping
-- their ids and status; AI Runtime Security stays on Prompts. Commits stay as they were, so notes, which replay them, list those
-- records under Prompts until the app's fields next change. Safe to run again.
UPDATE "entries" SET "attrs" = ("attrs" - 'prompts')
  || jsonb_build_object('access',
       (CASE WHEN jsonb_typeof("attrs"->'access') = 'array' THEN "attrs"->'access' ELSE '[]'::jsonb END)
       || (SELECT jsonb_agg(r) FROM jsonb_array_elements("attrs"->'prompts') r WHERE r->>'capability' IN ('ai-access', 'ai-browser-control')))
  || coalesce((SELECT jsonb_build_object('prompts', jsonb_agg(r)) FROM jsonb_array_elements("attrs"->'prompts') r
               WHERE coalesce(r->>'capability', '') NOT IN ('ai-access', 'ai-browser-control') HAVING count(*) > 0), '{}'::jsonb)
WHERE "slot" IN ('apps', 'apps-future')
  AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'ai-and-ai-security')
  AND jsonb_typeof("attrs"->'prompts') = 'array'
  AND EXISTS (SELECT 1 FROM jsonb_array_elements("attrs"->'prompts') r WHERE r->>'capability' IN ('ai-access', 'ai-browser-control'));
