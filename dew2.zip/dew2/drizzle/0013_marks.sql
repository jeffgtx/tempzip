-- A planned grid entry keeps its flag as the first mark. Notes replay the commits, so their ops change as the entries
-- do; a planned flag is only ever the literal true, and a user's text holding the same words is escaped. Safe to run again.
UPDATE "entries" SET "attrs" = ("attrs" - 'planned') || '{"mark": "flag"}'::jsonb
WHERE "attrs" -> 'planned' = 'true'::jsonb;
--> statement-breakpoint
UPDATE "commits" SET "op" = replace("op"::text, '"planned": true', '"mark": "flag"')::jsonb
WHERE "op"::text LIKE '%"planned": true%';
