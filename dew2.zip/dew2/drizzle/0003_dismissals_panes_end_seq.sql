ALTER TABLE "entries" ALTER COLUMN "status" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "entries" ALTER COLUMN "status" SET DEFAULT 'live'::text;--> statement-breakpoint
DROP TYPE "public"."entry_status";--> statement-breakpoint
CREATE TYPE "public"."entry_status" AS ENUM('live', 'ghost', 'dismissed');--> statement-breakpoint
ALTER TABLE "entries" ALTER COLUMN "status" SET DEFAULT 'live'::"public"."entry_status";--> statement-breakpoint
ALTER TABLE "entries" ALTER COLUMN "status" SET DATA TYPE "public"."entry_status" USING "status"::"public"."entry_status";--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "pane" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "end_seq" bigint;