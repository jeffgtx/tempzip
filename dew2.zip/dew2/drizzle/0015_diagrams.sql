-- The summary keeps Today, which becomes its first diagram; Where you're going and every later difference go. Notes replay
-- the commits, so their ops lose states and the entries this drops. The "+N more" zoom is a pane of its diagram now, so
-- its boards go. The migrator runs each statement on its own, and each is safe to run again.
ALTER TABLE "boards" ADD COLUMN IF NOT EXISTS "name" text;--> statement-breakpoint
ALTER TABLE "boards" ADD COLUMN IF NOT EXISTS "position" integer;--> statement-breakpoint
UPDATE "boards" SET "name" = 'Today', "position" = 0 WHERE "template_id" = 'summary' AND "entry_id" IS NULL AND "name" IS NULL;--> statement-breakpoint
DROP INDEX IF EXISTS "boards_customer_id_template_id_index";--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "boards_customer_id_template_id_index" ON "boards" USING btree ("customer_id","template_id") WHERE ("boards"."entry_id" is null and "boards"."name" is null);--> statement-breakpoint
CREATE OR REPLACE FUNCTION stateless_op(op jsonb, dropped text[]) RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
    WHEN op->>'type' IN ('mark', 'differ') THEN '{"type": "update", "updates": []}'::jsonb
    WHEN op ? 'ops' THEN jsonb_set(op, '{ops}', (
      SELECT jsonb_agg(stateless_op(o, dropped) ORDER BY i) FROM jsonb_array_elements(op->'ops') WITH ORDINALITY x(o, i)))
    WHEN op ? 'entries' THEN (op - 'changes') || jsonb_build_object('entries', coalesce((
      SELECT jsonb_agg(e - 'state' ORDER BY i) FROM jsonb_array_elements(op->'entries') WITH ORDINALITY x(e, i)
      WHERE NOT (e->>'id' = ANY(dropped))), '[]'))
    WHEN op ? 'updates' THEN jsonb_set(op, '{updates}', coalesce((
      SELECT jsonb_agg(u || jsonb_build_object('set', (u->'set') - 'state', 'prev', (u->'prev') - 'state') ORDER BY i)
      FROM jsonb_array_elements(op->'updates') WITH ORDINALITY x(u, i) WHERE NOT (u->>'entryId' = ANY(dropped))), '[]'))
    ELSE op END
$$;--> statement-breakpoint
-- Guarded, since a rerun after the column goes must skip it. The entries dropped are those ever put in a later state,
-- except those standing in Today now: an entry the future added and Today took over keeps its history.
DO $$ DECLARE dropped text[]; BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'entries' AND column_name = 'state') THEN
    dropped := array(
      SELECT p #>> '{}' FROM "commits" c, jsonb_path_query(c."op", 'lax $.**.entries[*] ? (@.state > 0).id') p
      EXCEPT SELECT "id"::text FROM "entries" WHERE "state" = 0);
    UPDATE "commits" SET "op" = stateless_op("op", dropped);
    DELETE FROM "entries" WHERE "state" > 0;
  END IF;
END $$;--> statement-breakpoint
DELETE FROM "boards" WHERE "template_id" = 'folded';--> statement-breakpoint
DROP TABLE IF EXISTS "entry_changes" CASCADE;--> statement-breakpoint
ALTER TABLE "entries" DROP COLUMN IF EXISTS "state";--> statement-breakpoint
ALTER TABLE "commits" DROP COLUMN IF EXISTS "state";--> statement-breakpoint
ALTER TABLE "meetings" DROP COLUMN IF EXISTS "state";--> statement-breakpoint
DROP FUNCTION IF EXISTS stateless_op(jsonb, text[]);
