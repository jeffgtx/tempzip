-- Heard and the low, medium and high rating become one level from 0 to 3: a rating its level, an un-mark with no rating
-- 0, a mark alone nothing. Notes replay the commits, so their ops change as the entries do. Safe to run again.
CREATE OR REPLACE FUNCTION concern_level(attrs jsonb) RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
  SELECT (attrs - 'rating' - 'heard') || CASE
    WHEN attrs->>'rating' = 'low' THEN '{"level": 1}'::jsonb
    WHEN attrs->>'rating' = 'medium' THEN '{"level": 2}'::jsonb
    WHEN attrs->>'rating' = 'high' THEN '{"level": 3}'::jsonb
    WHEN attrs->'heard' = 'false'::jsonb THEN '{"level": 0}'::jsonb
    ELSE '{}'::jsonb END
$$;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION concern_level_in(o jsonb) RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE WHEN o ? 'attrs' THEN jsonb_set(o, '{attrs}', concern_level(o->'attrs')) ELSE o END
$$;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION concern_level_op(op jsonb) RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
    WHEN op ? 'ops' THEN jsonb_set(op, '{ops}', (
      SELECT jsonb_agg(concern_level_op(o) ORDER BY i) FROM jsonb_array_elements(op->'ops') WITH ORDINALITY x(o, i)))
    WHEN op ? 'entries' THEN jsonb_set(op, '{entries}', coalesce((
      SELECT jsonb_agg(concern_level_in(e) ORDER BY i) FROM jsonb_array_elements(op->'entries') WITH ORDINALITY x(e, i)), '[]'))
    WHEN op ? 'updates' THEN jsonb_set(op, '{updates}', coalesce((
      SELECT jsonb_agg(u || jsonb_build_object('set', concern_level_in(u->'set'), 'prev', concern_level_in(u->'prev')) ORDER BY i)
      FROM jsonb_array_elements(op->'updates') WITH ORDINALITY x(u, i)), '[]'))
    ELSE op END
$$;
--> statement-breakpoint
UPDATE "commits" SET "op" = concern_level_op("op")
WHERE "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'concerns');
--> statement-breakpoint
UPDATE "entries" SET "attrs" = concern_level("attrs")
WHERE "attrs" ?| array['rating', 'heard'] AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'concerns');
--> statement-breakpoint
DROP FUNCTION concern_level_op(jsonb);
--> statement-breakpoint
DROP FUNCTION concern_level_in(jsonb);
--> statement-breakpoint
DROP FUNCTION concern_level(jsonb);
