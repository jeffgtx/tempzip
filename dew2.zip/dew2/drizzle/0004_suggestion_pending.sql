ALTER TABLE "suggestions" DROP CONSTRAINT "suggestions_entry_id_owner_id_entries_id_owner_id_fk";
--> statement-breakpoint
CREATE UNIQUE INDEX "suggestions_entry_id_index" ON "suggestions" USING btree ("entry_id") WHERE "suggestions"."status" = 'pending';