-- App tiers has no Untagged row. Notes list no slot a board lacks, so the commits stay; entry_changes cascade. Safe to run again.
DELETE FROM "entries" WHERE "slot" = 'untagged' AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'app-tiers');
