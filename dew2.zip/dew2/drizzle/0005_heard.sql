-- Any rating, quiet included, used to mean the customer raised the concern, and the notes
-- listed every concern in the customer's own words: all of those become heard, and quiet
-- stops being a rating. Notes replay the commits, so their ops change as the entries do.
-- The migrator runs each statement on its own, so every step is safe to run again.
CREATE OR REPLACE FUNCTION heard_attrs(attrs jsonb, own_words boolean) RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE WHEN attrs ? 'rating' OR own_words
    THEN (CASE WHEN attrs->>'rating' = 'quiet' THEN attrs - 'rating' ELSE attrs END) || '{"heard": true}'
    ELSE attrs END
$$;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION heard_in(o jsonb, own_words boolean) RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE WHEN o ? 'attrs' THEN jsonb_set(o, '{attrs}', heard_attrs(o->'attrs', own_words)) ELSE o END
$$;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION heard_op(op jsonb, own_words text[]) RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
    WHEN op ? 'ops' THEN jsonb_set(op, '{ops}', (
      SELECT jsonb_agg(heard_op(o, own_words) ORDER BY i) FROM jsonb_array_elements(op->'ops') WITH ORDINALITY x(o, i)))
    WHEN op ? 'entries' THEN jsonb_set(op, '{entries}', coalesce((
      SELECT jsonb_agg(heard_in(e, e->>'id' = ANY(own_words)) ORDER BY i) FROM jsonb_array_elements(op->'entries') WITH ORDINALITY x(e, i)), '[]'))
    WHEN op ? 'updates' THEN jsonb_set(op, '{updates}', coalesce((
      SELECT jsonb_agg(u || jsonb_build_object('set', heard_in(u->'set', u->>'entryId' = ANY(own_words)), 'prev', heard_in(u->'prev', u->>'entryId' = ANY(own_words))) ORDER BY i)
      FROM jsonb_array_elements(op->'updates') WITH ORDINALITY x(u, i)), '[]'))
    ELSE op END
$$;
--> statement-breakpoint
-- The customer's words are the concerns still in free text, and those added in free text and
-- deleted since, which earlier meetings' notes listed.
UPDATE "commits" SET "op" = heard_op("op", array(
  SELECT "id"::text FROM "entries" WHERE "text" IS NOT NULL AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'concerns')
  UNION
  SELECT p #>> '{}' FROM "commits" c, jsonb_path_query(c."op", 'lax $.entries[*] ? (@.text != null).id') p
  WHERE c."board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'concerns') AND NOT EXISTS (SELECT 1 FROM "entries" e WHERE e."id"::text = p #>> '{}')
  UNION
  SELECT p #>> '{}' FROM "commits" c, jsonb_path_query(c."op", 'lax $.ops[*].entries[*] ? (@.text != null).id') p
  WHERE c."board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'concerns') AND NOT EXISTS (SELECT 1 FROM "entries" e WHERE e."id"::text = p #>> '{}')))
WHERE "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'concerns');
--> statement-breakpoint
UPDATE "entries" SET "attrs" = heard_attrs("attrs", "text" IS NOT NULL)
WHERE "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'concerns');
--> statement-breakpoint
DROP FUNCTION heard_op(jsonb, text[]);
--> statement-breakpoint
DROP FUNCTION heard_in(jsonb, boolean);
--> statement-breakpoint
DROP FUNCTION heard_attrs(jsonb, boolean);
