-- An AI app's zoom shows where Palo Alto Networks AI security inserts, from fields of its own. The old fields go, since any
-- change to an entry still holding them wouldn't fit its slot. Notes list only the fields a slot declares, so the commits
-- stay. Safe to run again.
UPDATE "entries"
SET "attrs" = "attrs" - ARRAY['users', 'inbound', 'cloud', 'compute', 'tiers', 'posture', 'outbound', 'models', 'eastwest', 'data', 'services']
WHERE "slot" IN ('apps', 'apps-future')
  AND "attrs" ?| ARRAY['users', 'inbound', 'cloud', 'compute', 'tiers', 'posture', 'outbound', 'models', 'eastwest', 'data', 'services']
  AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'ai-and-ai-security');
