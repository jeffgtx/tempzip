-- AI apps zoom only once the SE adds the zoom, which marks the entry. An app whose zoom fields hold anything keeps its
-- zoom; the others lose it, and their zoom boards go. Notes list stored fields either way, so the commits stay. Safe to run again.
UPDATE "entries" SET "attrs" = "attrs" || '{"zoom": true}'::jsonb
WHERE "slot" IN ('apps', 'apps-future')
  AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'ai-and-ai-security')
  AND EXISTS (SELECT 1 FROM jsonb_each("attrs") f
              WHERE f.key IN ('users', 'tiers', 'models', 'data', 'services', 'cloud', 'compute', 'inbound', 'outbound', 'eastwest', 'posture')
                AND f.value NOT IN ('null'::jsonb, '[]'::jsonb, '""'::jsonb));
--> statement-breakpoint
DELETE FROM "boards" WHERE "template_id" = 'ai-app' AND "entry_id" IN (SELECT "id" FROM "entries" WHERE NOT ("attrs" ? 'zoom'));
