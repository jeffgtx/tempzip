CREATE TABLE "join_attempts" (
	"ip" text NOT NULL,
	"at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "commits" ADD COLUMN "reverts" uuid;--> statement-breakpoint
ALTER TABLE "customers" ADD COLUMN "logo_url" text;--> statement-breakpoint
ALTER TABLE "meetings" ADD COLUMN "visited" uuid[] DEFAULT '{}' NOT NULL;--> statement-breakpoint
CREATE INDEX "join_attempts_ip_at_index" ON "join_attempts" USING btree ("ip","at");