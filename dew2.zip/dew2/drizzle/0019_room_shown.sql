ALTER TABLE "meetings" ADD COLUMN "shown" uuid[] DEFAULT '{}' NOT NULL;--> statement-breakpoint
-- Earlier meetings recorded only what they opened, so their notes and packs keep covering that.
UPDATE "meetings" SET "shown" = "visited";
