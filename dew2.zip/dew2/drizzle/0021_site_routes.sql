-- A site's routes are read from its lines and the diagram's flows. The Internet via and Private apps via fields go, since any
-- change to an entry still holding them wouldn't fit its slot. Notes list only the fields a slot declares, so the commits stay.
-- Safe to run again.
UPDATE "entries"
SET "attrs" = "attrs" - ARRAY['internet', 'apps']
WHERE "slot" = 'sites'
  AND "attrs" ?| ARRAY['internet', 'apps']
  AND "board_id" IN (SELECT "id" FROM "boards" WHERE "template_id" = 'summary');
